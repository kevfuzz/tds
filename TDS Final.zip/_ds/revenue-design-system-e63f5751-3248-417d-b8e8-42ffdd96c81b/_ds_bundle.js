/* @ds-bundle: {"format":3,"namespace":"RevenueDesignSystem_e63f57","components":[{"name":"Card","sourcePath":"components/content/Card.jsx"},{"name":"ServiceTile","sourcePath":"components/content/ServiceTile.jsx"},{"name":"Notice","sourcePath":"components/feedback/Notice.jsx"},{"name":"Tag","sourcePath":"components/feedback/Tag.jsx"},{"name":"Button","sourcePath":"components/forms/Button.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Radio","sourcePath":"components/forms/Radio.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Breadcrumb","sourcePath":"components/navigation/Breadcrumb.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"}],"sourceHashes":{"components/content/Card.jsx":"ec898a1ebb7a","components/content/ServiceTile.jsx":"209a2fb96a36","components/feedback/Notice.jsx":"0002b0bd5db9","components/feedback/Tag.jsx":"898c23d2740f","components/forms/Button.jsx":"c70e9d8182ae","components/forms/Checkbox.jsx":"4ad2986d2466","components/forms/Input.jsx":"59aecec260d1","components/forms/Radio.jsx":"1ba2f6b67506","components/forms/Select.jsx":"9587c970b10c","components/navigation/Breadcrumb.jsx":"deab70585d14","components/navigation/Tabs.jsx":"49cedc460fba","ui_kits/revenue-website/CategoryPage.jsx":"325d8a7cbfac","ui_kits/revenue-website/Chrome.jsx":"ded33526cbd1","ui_kits/revenue-website/HomePage.jsx":"bb501be05ff5","ui_kits/revenue-website/SignInPage.jsx":"1a080b3f26df"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.RevenueDesignSystem_e63f57 = window.RevenueDesignSystem_e63f57 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/content/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Revenue Card — neutral white surface with hairline border. */
function Card({
  children,
  padding = "24px",
  as = "div",
  interactive = false,
  ...rest
}) {
  const Tag = as;
  return /*#__PURE__*/React.createElement(Tag, _extends({
    style: {
      display: "block",
      background: "var(--surface-card)",
      border: "1px solid var(--border-default)",
      borderRadius: "var(--radius-lg)",
      padding,
      fontFamily: "var(--font-sans)",
      color: "var(--text-body)",
      textDecoration: "none",
      boxShadow: "var(--shadow-xs)",
      transition: interactive ? "box-shadow var(--duration-base), border-color var(--duration-base)" : "none",
      cursor: interactive ? "pointer" : "default"
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/Card.jsx", error: String((e && e.message) || e) }); }

// components/content/ServiceTile.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Revenue ServiceTile — the signature homepage category tile.
 * Solid green block, white heading, optional description, chevron affordance.
 */
function ServiceTile({
  title,
  description,
  href = "#",
  tone = "brand",
  ...rest
}) {
  const tones = {
    brand: {
      bg: "var(--green-700)",
      hover: "var(--green-800)"
    },
    dark: {
      bg: "var(--green-900)",
      hover: "var(--black)"
    },
    teal: {
      bg: "var(--teal-700)",
      hover: "#08383d"
    }
  };
  const t = tones[tone] || tones.brand;
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("a", _extends({
    href: href,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: "flex",
      flexDirection: "column",
      justifyContent: "space-between",
      gap: "16px",
      minHeight: "150px",
      padding: "22px 24px",
      background: hover ? t.hover : t.bg,
      color: "var(--white)",
      textDecoration: "none",
      borderRadius: "var(--radius-md)",
      borderBottom: "4px solid var(--gold-500)",
      fontFamily: "var(--font-sans)",
      transition: "background var(--duration-base) var(--ease-standard)"
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "8px"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-xl)",
      fontWeight: "var(--weight-black)",
      lineHeight: "var(--leading-snug)"
    }
  }, title), description && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-sm)",
      color: "rgba(255,255,255,0.85)",
      fontWeight: "var(--weight-regular)",
      lineHeight: "var(--leading-normal)"
    }
  }, description)), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      fontSize: "22px",
      fontWeight: "var(--weight-black)",
      transform: hover ? "translateX(4px)" : "none",
      transition: "transform var(--duration-base) var(--ease-standard)"
    }
  }, "\u2192"));
}
Object.assign(__ds_scope, { ServiceTile });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/ServiceTile.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Notice.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Revenue Notice — government notification banner.
 * Solid coloured header strip over a bordered body. Variants map to status colours.
 */
function Notice({
  variant = "info",
  title,
  children,
  ...rest
}) {
  const map = {
    info: {
      bar: "var(--blue-600)",
      body: "var(--blue-100)",
      label: "Information"
    },
    success: {
      bar: "var(--success-600)",
      body: "var(--success-100)",
      label: "Success"
    },
    warning: {
      bar: "var(--amber-600)",
      body: "var(--amber-100)",
      label: "Important"
    },
    error: {
      bar: "var(--red-600)",
      body: "var(--red-100)",
      label: "There is a problem"
    }
  };
  const c = map[variant] || map.info;
  return /*#__PURE__*/React.createElement("div", _extends({
    role: variant === "error" ? "alert" : "region",
    "aria-label": title || c.label,
    style: {
      fontFamily: "var(--font-sans)",
      border: `2px solid ${c.bar}`,
      borderRadius: "var(--radius-md)",
      overflow: "hidden",
      background: "var(--white)"
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      background: c.bar,
      color: "var(--white)",
      padding: "8px 16px",
      fontWeight: "var(--weight-black)",
      fontSize: "var(--text-sm)",
      letterSpacing: "var(--tracking-wide)",
      textTransform: "uppercase"
    }
  }, title || c.label), /*#__PURE__*/React.createElement("div", {
    style: {
      background: c.body,
      padding: "14px 16px",
      fontSize: "var(--text-base)",
      color: "var(--text-strong)",
      lineHeight: "var(--leading-normal)"
    }
  }, children));
}
Object.assign(__ds_scope, { Notice });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Notice.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Revenue Tag — compact status/category label. */
function Tag({
  children,
  variant = "neutral",
  ...rest
}) {
  const map = {
    neutral: {
      bg: "var(--grey-200)",
      fg: "var(--grey-800)"
    },
    brand: {
      bg: "var(--green-100)",
      fg: "var(--green-800)"
    },
    success: {
      bg: "var(--success-100)",
      fg: "var(--success-600)"
    },
    warning: {
      bg: "var(--amber-100)",
      fg: "var(--amber-600)"
    },
    error: {
      bg: "var(--red-100)",
      fg: "var(--red-600)"
    },
    info: {
      bg: "var(--blue-100)",
      fg: "var(--blue-600)"
    }
  };
  const c = map[variant] || map.neutral;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: "inline-flex",
      alignItems: "center",
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-2xs)",
      fontWeight: "var(--weight-black)",
      letterSpacing: "var(--tracking-caps)",
      textTransform: "uppercase",
      padding: "3px 9px",
      borderRadius: "var(--radius-sm)",
      background: c.bg,
      color: c.fg
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Tag.jsx", error: String((e && e.message) || e) }); }

// components/forms/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Revenue Button — primary action control.
 * Solid green by default; square, confident, accessible (GDS-style yellow focus).
 */
function Button({
  children,
  variant = "primary",
  size = "md",
  fullWidth = false,
  disabled = false,
  iconBefore = null,
  iconAfter = null,
  as = "button",
  ...rest
}) {
  const pad = {
    sm: "8px 14px",
    md: "12px 20px",
    lg: "15px 26px"
  }[size];
  const fontSize = {
    sm: "var(--text-sm)",
    md: "var(--text-base)",
    lg: "var(--text-lg)"
  }[size];
  const palettes = {
    primary: {
      background: "var(--green-700)",
      color: "var(--white)",
      border: "2px solid var(--green-700)"
    },
    secondary: {
      background: "var(--white)",
      color: "var(--green-800)",
      border: "2px solid var(--green-700)"
    },
    ghost: {
      background: "transparent",
      color: "var(--green-800)",
      border: "2px solid transparent"
    },
    danger: {
      background: "var(--red-600)",
      color: "var(--white)",
      border: "2px solid var(--red-600)"
    }
  };
  const p = palettes[variant] || palettes.primary;
  const style = {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: "10px",
    fontFamily: "var(--font-sans)",
    fontWeight: "var(--weight-bold)",
    fontSize,
    lineHeight: 1.1,
    padding: pad,
    width: fullWidth ? "100%" : "auto",
    borderRadius: "var(--radius-md)",
    cursor: disabled ? "not-allowed" : "pointer",
    opacity: disabled ? 0.5 : 1,
    textDecoration: "none",
    transition: "background var(--duration-fast) var(--ease-standard), box-shadow var(--duration-fast)",
    ...p
  };
  const Tag = as;
  return /*#__PURE__*/React.createElement(Tag, _extends({
    className: `rev-btn rev-btn--${variant}`,
    style: style,
    disabled: Tag === "button" ? disabled : undefined,
    "aria-disabled": disabled || undefined
  }, rest), iconBefore, /*#__PURE__*/React.createElement("span", null, children), iconAfter);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Button.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Revenue checkbox — large gov-style hit target, square check. */
function Checkbox({
  label,
  hint,
  id,
  checked,
  defaultChecked,
  ...rest
}) {
  const fieldId = id || `rev-cb-${Math.random().toString(36).slice(2, 8)}`;
  return /*#__PURE__*/React.createElement("label", {
    htmlFor: fieldId,
    style: {
      display: "flex",
      gap: "12px",
      alignItems: "flex-start",
      cursor: "pointer",
      fontFamily: "var(--font-sans)",
      padding: "8px 0"
    }
  }, /*#__PURE__*/React.createElement("input", _extends({
    id: fieldId,
    type: "checkbox",
    checked: checked,
    defaultChecked: defaultChecked,
    style: {
      width: "26px",
      height: "26px",
      accentColor: "var(--green-700)",
      flex: "0 0 auto",
      marginTop: "1px",
      cursor: "pointer"
    }
  }, rest)), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "2px"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-base)",
      color: "var(--text-strong)",
      fontWeight: "var(--weight-bold)"
    }
  }, label), hint && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-sm)",
      color: "var(--text-muted)",
      fontWeight: "var(--weight-regular)"
    }
  }, hint)));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Revenue text field with label, optional hint and error.
 * Gov-grade: visible label, thick border, yellow focus.
 */
function Input({
  label,
  hint,
  error,
  id,
  type = "text",
  required = false,
  prefix = null,
  ...rest
}) {
  const fieldId = id || `rev-input-${Math.random().toString(36).slice(2, 8)}`;
  const hintId = hint ? `${fieldId}-hint` : undefined;
  const errId = error ? `${fieldId}-err` : undefined;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "6px",
      fontFamily: "var(--font-sans)"
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: fieldId,
    style: {
      fontWeight: "var(--weight-bold)",
      fontSize: "var(--text-base)",
      color: "var(--text-strong)"
    }
  }, label, required && /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--red-600)"
    },
    "aria-hidden": "true"
  }, " *")), hint && /*#__PURE__*/React.createElement("span", {
    id: hintId,
    style: {
      fontSize: "var(--text-sm)",
      color: "var(--text-muted)"
    }
  }, hint), error && /*#__PURE__*/React.createElement("span", {
    id: errId,
    style: {
      fontSize: "var(--text-sm)",
      fontWeight: "var(--weight-bold)",
      color: "var(--red-600)"
    }
  }, error), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "stretch"
    }
  }, prefix && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      padding: "0 12px",
      background: "var(--grey-100)",
      border: `2px solid ${error ? "var(--red-600)" : "var(--grey-700)"}`,
      borderRight: "none",
      borderRadius: "var(--radius-md) 0 0 var(--radius-md)",
      color: "var(--text-muted)",
      fontWeight: "var(--weight-bold)"
    }
  }, prefix), /*#__PURE__*/React.createElement("input", _extends({
    id: fieldId,
    type: type,
    required: required,
    "aria-describedby": [hintId, errId].filter(Boolean).join(" ") || undefined,
    "aria-invalid": error ? true : undefined,
    style: {
      flex: 1,
      width: "100%",
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-base)",
      padding: "11px 12px",
      color: "var(--text-strong)",
      background: "var(--white)",
      border: `2px solid ${error ? "var(--red-600)" : "var(--grey-700)"}`,
      borderRadius: prefix ? "0 var(--radius-md) var(--radius-md) 0" : "var(--radius-md)",
      outline: "none"
    }
  }, rest))));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Radio.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Revenue radio button — large gov-style hit target. */
function Radio({
  label,
  hint,
  id,
  name,
  ...rest
}) {
  const fieldId = id || `rev-radio-${Math.random().toString(36).slice(2, 8)}`;
  return /*#__PURE__*/React.createElement("label", {
    htmlFor: fieldId,
    style: {
      display: "flex",
      gap: "12px",
      alignItems: "flex-start",
      cursor: "pointer",
      fontFamily: "var(--font-sans)",
      padding: "8px 0"
    }
  }, /*#__PURE__*/React.createElement("input", _extends({
    id: fieldId,
    type: "radio",
    name: name,
    style: {
      width: "26px",
      height: "26px",
      accentColor: "var(--green-700)",
      flex: "0 0 auto",
      marginTop: "1px",
      cursor: "pointer"
    }
  }, rest)), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "2px"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-base)",
      color: "var(--text-strong)",
      fontWeight: "var(--weight-bold)"
    }
  }, label), hint && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-sm)",
      color: "var(--text-muted)",
      fontWeight: "var(--weight-regular)"
    }
  }, hint)));
}
Object.assign(__ds_scope, { Radio });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Radio.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Revenue select / dropdown with label + hint + error. */
function Select({
  label,
  hint,
  error,
  id,
  required = false,
  children,
  ...rest
}) {
  const fieldId = id || `rev-select-${Math.random().toString(36).slice(2, 8)}`;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "6px",
      fontFamily: "var(--font-sans)"
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: fieldId,
    style: {
      fontWeight: "var(--weight-bold)",
      fontSize: "var(--text-base)",
      color: "var(--text-strong)"
    }
  }, label, required && /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--red-600)"
    },
    "aria-hidden": "true"
  }, " *")), hint && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-sm)",
      color: "var(--text-muted)"
    }
  }, hint), error && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-sm)",
      fontWeight: "var(--weight-bold)",
      color: "var(--red-600)"
    }
  }, error), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      display: "flex"
    }
  }, /*#__PURE__*/React.createElement("select", _extends({
    id: fieldId,
    required: required,
    "aria-invalid": error ? true : undefined,
    style: {
      appearance: "none",
      width: "100%",
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-base)",
      padding: "11px 40px 11px 12px",
      color: "var(--text-strong)",
      background: "var(--white)",
      border: `2px solid ${error ? "var(--red-600)" : "var(--grey-700)"}`,
      borderRadius: "var(--radius-md)",
      outline: "none",
      cursor: "pointer"
    }
  }, rest), children), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      position: "absolute",
      right: "14px",
      top: "50%",
      transform: "translateY(-50%)",
      pointerEvents: "none",
      color: "var(--grey-700)",
      fontSize: "12px"
    }
  }, "\u25BC")));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Breadcrumb.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Revenue breadcrumb trail. */
function Breadcrumb({
  items = [],
  ...rest
}) {
  return /*#__PURE__*/React.createElement("nav", _extends({
    "aria-label": "Breadcrumb",
    style: {
      fontFamily: "var(--font-sans)"
    }
  }, rest), /*#__PURE__*/React.createElement("ol", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      alignItems: "center",
      gap: "8px",
      listStyle: "none",
      margin: 0,
      padding: 0,
      fontSize: "var(--text-sm)"
    }
  }, items.map((it, i) => {
    const last = i === items.length - 1;
    return /*#__PURE__*/React.createElement("li", {
      key: i,
      style: {
        display: "flex",
        alignItems: "center",
        gap: "8px"
      }
    }, last || !it.href ? /*#__PURE__*/React.createElement("span", {
      "aria-current": last ? "page" : undefined,
      style: {
        color: last ? "var(--text-muted)" : "var(--text-strong)",
        fontWeight: last ? "var(--weight-regular)" : "var(--weight-bold)"
      }
    }, it.label) : /*#__PURE__*/React.createElement("a", {
      href: it.href,
      style: {
        color: "var(--text-link)",
        fontWeight: "var(--weight-bold)"
      }
    }, it.label), !last && /*#__PURE__*/React.createElement("span", {
      "aria-hidden": "true",
      style: {
        color: "var(--grey-400)"
      }
    }, "\u203A"));
  })));
}
Object.assign(__ds_scope, { Breadcrumb });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Breadcrumb.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Revenue tabs — underlined, brand-green active state. */
function Tabs({
  tabs = [],
  value,
  defaultValue,
  onChange,
  ...rest
}) {
  const [internal, setInternal] = React.useState(defaultValue ?? (tabs[0] && tabs[0].id));
  const active = value !== undefined ? value : internal;
  const select = id => {
    if (value === undefined) setInternal(id);
    onChange && onChange(id);
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "tablist",
    style: {
      display: "flex",
      gap: "4px",
      borderBottom: "1px solid var(--border-default)",
      fontFamily: "var(--font-sans)",
      flexWrap: "wrap"
    }
  }, rest), tabs.map(t => {
    const on = t.id === active;
    return /*#__PURE__*/React.createElement("button", {
      key: t.id,
      role: "tab",
      "aria-selected": on,
      onClick: () => select(t.id),
      style: {
        appearance: "none",
        background: "transparent",
        border: "none",
        cursor: "pointer",
        padding: "12px 16px",
        fontFamily: "var(--font-sans)",
        fontSize: "var(--text-base)",
        fontWeight: on ? "var(--weight-black)" : "var(--weight-bold)",
        color: on ? "var(--green-800)" : "var(--text-muted)",
        borderBottom: `4px solid ${on ? "var(--green-700)" : "transparent"}`,
        marginBottom: "-1px"
      }
    }, t.label);
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// ui_kits/revenue-website/CategoryPage.jsx
try { (() => {
// Revenue website — Category / landing page recreation.
const {
  Breadcrumb,
  Notice,
  Tag,
  Button
} = window.RevenueDesignSystem_e63f57;
function CategoryPage({
  go
}) {
  const side = ["Overview", "How to register", "Rates and bands", "Filing a return", "Paying your tax", "Forms and guides"];
  const [active, setActive] = React.useState("Overview");
  return /*#__PURE__*/React.createElement("main", {
    style: {
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: "28px 24px 56px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement(Breadcrumb, {
    items: [{
      label: "Home",
      href: "#"
    }, {
      label: "Businesses & self-assessed",
      href: "#"
    }, {
      label: "Value-Added Tax (VAT)"
    }]
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "260px 1fr",
      gap: 40,
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement("nav", {
    "aria-label": "Section",
    style: {
      borderTop: "4px solid var(--green-700)"
    }
  }, /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: "none",
      margin: 0,
      padding: 0
    }
  }, side.map(s => /*#__PURE__*/React.createElement("li", {
    key: s,
    style: {
      borderBottom: "1px solid var(--border-subtle)"
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      setActive(s);
    },
    style: {
      display: "block",
      padding: "12px 14px",
      textDecoration: "none",
      fontWeight: active === s ? 900 : 700,
      color: active === s ? "var(--green-800)" : "var(--text-body)",
      background: active === s ? "var(--green-050)" : "transparent",
      borderLeft: `4px solid ${active === s ? "var(--green-700)" : "transparent"}`
    }
  }, s))))), /*#__PURE__*/React.createElement("article", {
    style: {
      maxWidth: 720
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "rev-eyebrow",
    style: {
      marginBottom: 10
    }
  }, "Value-Added Tax"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: "var(--text-3xl)",
      marginBottom: 16
    }
  }, active), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: "var(--text-lg)",
      color: "var(--text-strong)",
      marginTop: 0
    }
  }, "VAT is a tax on consumer spending. Most goods and services supplied in Ireland are subject to VAT, which is collected by VAT-registered traders on their supplies."), /*#__PURE__*/React.createElement("p", {
    style: {
      color: "var(--text-body)"
    }
  }, "If your turnover exceeds, or is likely to exceed, the VAT thresholds in any continuous 12-month period, you must register for VAT. You can register through ROS using the eRegistration service."), /*#__PURE__*/React.createElement("div", {
    style: {
      margin: "24px 0"
    }
  }, /*#__PURE__*/React.createElement(Notice, {
    variant: "info",
    title: "Thresholds from 2026"
  }, "\u20AC85,000 for the supply of goods and \u20AC42,500 for the supply of services.")), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: "var(--text-2xl)",
      margin: "28px 0 12px"
    }
  }, "Before you start"), /*#__PURE__*/React.createElement("ul", {
    style: {
      paddingLeft: 20,
      lineHeight: "var(--leading-loose)",
      color: "var(--text-body)"
    }
  }, /*#__PURE__*/React.createElement("li", null, "You will need your business tax registration number."), /*#__PURE__*/React.createElement("li", null, "Have your bank details ready for repayments."), /*#__PURE__*/React.createElement("li", null, "Know your accounting basis \u2014 invoice or cash receipts.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 12,
      marginTop: 24,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    onClick: () => go("signin")
  }, "Register for VAT"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary"
  }, "Download VAT guide (PDF)")), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 28,
      display: "flex",
      gap: 8,
      alignItems: "center",
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-sm)",
      color: "var(--text-muted)",
      fontWeight: 700
    }
  }, "Related:"), /*#__PURE__*/React.createElement(Tag, {
    variant: "neutral"
  }, "VAT3 return"), /*#__PURE__*/React.createElement(Tag, {
    variant: "neutral"
  }, "RTD"), /*#__PURE__*/React.createElement(Tag, {
    variant: "neutral"
  }, "VAT rates"), /*#__PURE__*/React.createElement(Tag, {
    variant: "neutral"
  }, "eRegistration")))));
}
window.CategoryPage = CategoryPage;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/revenue-website/CategoryPage.jsx", error: String((e && e.message) || e) }); }

// ui_kits/revenue-website/Chrome.jsx
try { (() => {
// Shared site chrome for the Revenue website UI kit.
// Exposes: UtilityBar, Masthead, MainNav, SiteFooter, Icon
const {
  Button
} = window.RevenueDesignSystem_e63f57;

// Material Symbols glyph helper (loaded via CDN in index.html)
function Icon({
  name,
  size = 22,
  fill = false,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: "material-symbols-rounded",
    style: {
      fontSize: size,
      lineHeight: 1,
      fontVariationSettings: `'FILL' ${fill ? 1 : 0}, 'wght' 500`,
      ...style
    }
  }, name);
}
function Wordmark({
  onClick
}) {
  return /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: onClick,
    style: {
      display: "flex",
      alignItems: "center",
      gap: "12px",
      textDecoration: "none"
    }
  }, /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      width: 44,
      height: 44,
      borderRadius: 2,
      background: "var(--green-700)",
      color: "#fff",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontWeight: 900,
      fontSize: 22
    }
  }, "R"), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "block",
      fontSize: 25,
      fontWeight: 900,
      color: "var(--green-800)",
      lineHeight: 1
    }
  }, "Revenue"), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "block",
      fontSize: 11,
      fontWeight: 700,
      color: "var(--text-muted)",
      marginTop: 2
    }
  }, "C\xE1in agus Custaim na h\xC9ireann \xB7 Irish Tax and Customs")));
}
function UtilityBar() {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--green-900)",
      color: "rgba(255,255,255,0.92)",
      fontSize: "var(--text-sm)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: "8px 24px",
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "public",
    size: 16
  }), /*#__PURE__*/React.createElement("span", null, "gov.ie")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 18,
      fontWeight: 700
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      color: "#fff",
      textDecoration: "none"
    }
  }, "English"), /*#__PURE__*/React.createElement("span", {
    style: {
      opacity: 0.4
    }
  }, "|"), /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      color: "rgba(255,255,255,0.7)",
      textDecoration: "none"
    }
  }, "Gaeilge"))));
}
function Masthead({
  go,
  query,
  setQuery
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: "#fff",
      borderBottom: "1px solid var(--border-subtle)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: "18px 24px",
      display: "flex",
      alignItems: "center",
      gap: 24,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement(Wordmark, {
    onClick: e => {
      e.preventDefault();
      go("home");
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 260,
      display: "flex",
      maxWidth: 440,
      marginLeft: "auto"
    }
  }, /*#__PURE__*/React.createElement("input", {
    value: query,
    onChange: e => setQuery(e.target.value),
    placeholder: "Search revenue.ie",
    "aria-label": "Search",
    style: {
      flex: 1,
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-base)",
      padding: "11px 14px",
      border: "2px solid var(--grey-700)",
      borderRight: "none",
      borderRadius: "var(--radius-md) 0 0 var(--radius-md)",
      outline: "none"
    }
  }), /*#__PURE__*/React.createElement("button", {
    "aria-label": "Search",
    style: {
      border: "none",
      background: "var(--green-700)",
      color: "#fff",
      padding: "0 18px",
      borderRadius: "0 var(--radius-md) var(--radius-md) 0",
      cursor: "pointer",
      display: "flex",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "search",
    size: 22
  })))));
}
function MainNav({
  go,
  active = "home"
}) {
  const items = [{
    id: "personal",
    label: "Individuals"
  }, {
    id: "business",
    label: "Businesses & self-assessed"
  }, {
    id: "employing",
    label: "Employing people"
  }, {
    id: "property",
    label: "Property"
  }, {
    id: "customs",
    label: "Importing & exporting"
  }];
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      background: "var(--green-700)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: "0 12px",
      display: "flex",
      flexWrap: "wrap"
    }
  }, items.map(it => /*#__PURE__*/React.createElement("a", {
    key: it.id,
    href: "#",
    onClick: e => {
      e.preventDefault();
      go("category");
    },
    style: {
      color: "#fff",
      textDecoration: "none",
      fontWeight: 700,
      fontSize: "var(--text-sm)",
      padding: "14px 16px",
      borderBottom: `4px solid ${active === it.id ? "var(--gold-500)" : "transparent"}`
    }
  }, it.label)), /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      go("signin");
    },
    style: {
      marginLeft: "auto",
      color: "#fff",
      textDecoration: "none",
      fontWeight: 900,
      fontSize: "var(--text-sm)",
      padding: "14px 16px",
      display: "flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "lock",
    size: 18,
    fill: true
  }), " Sign in")));
}
function SiteFooter() {
  const cols = [{
    h: "Sign in",
    links: ["myAccount", "ROS", "LPT online", "Customs (AEP)"]
  }, {
    h: "Popular topics",
    links: ["Jobs and pensions", "VAT", "Local Property Tax", "Customs"]
  }, {
    h: "About Revenue",
    links: ["Corporate information", "Statistics", "Careers", "Press office"]
  }, {
    h: "Help",
    links: ["Contact us", "Accessibility", "Cookies", "Privacy"]
  }];
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      background: "var(--green-900)",
      color: "rgba(255,255,255,0.85)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: "40px 24px",
      display: "grid",
      gridTemplateColumns: "repeat(4, 1fr)",
      gap: 28
    }
  }, cols.map(c => /*#__PURE__*/React.createElement("div", {
    key: c.h
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 900,
      color: "#fff",
      fontSize: "var(--text-sm)",
      textTransform: "uppercase",
      letterSpacing: "0.05em",
      marginBottom: 12
    }
  }, c.h), /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: "none",
      margin: 0,
      padding: 0,
      display: "flex",
      flexDirection: "column",
      gap: 9
    }
  }, c.links.map(l => /*#__PURE__*/React.createElement("li", {
    key: l
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      color: "rgba(255,255,255,0.85)",
      textDecoration: "none",
      fontSize: "var(--text-sm)"
    }
  }, l))))))), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: "1px solid rgba(255,255,255,0.15)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: "16px 24px",
      fontSize: "var(--text-xs)",
      color: "rgba(255,255,255,0.6)"
    }
  }, "\xA9 ", new Date().getFullYear(), " Office of the Revenue Commissioners. Built with the Revenue Design System.")));
}
Object.assign(window, {
  Icon,
  Wordmark,
  UtilityBar,
  Masthead,
  MainNav,
  SiteFooter
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/revenue-website/Chrome.jsx", error: String((e && e.message) || e) }); }

// ui_kits/revenue-website/HomePage.jsx
try { (() => {
// Revenue website — Home page recreation.
const {
  ServiceTile,
  Card,
  Notice,
  Button,
  Tag
} = window.RevenueDesignSystem_e63f57;
function HomePage({
  go
}) {
  const tiles = [{
    t: "Jobs and pensions",
    d: "Manage your tax if you are an employee or getting a pension.",
    tone: "brand"
  }, {
    t: "Starting a business",
    d: "Register for tax, get a tax number and file your first return.",
    tone: "teal"
  }, {
    t: "Local Property Tax",
    d: "Pay or set up payment for your residential property.",
    tone: "brand"
  }, {
    t: "Importing & exporting",
    d: "Customs, duties and trade with countries outside the EU.",
    tone: "teal"
  }, {
    t: "Vehicle registration tax",
    d: "Register a vehicle and calculate the VRT due.",
    tone: "brand"
  }, {
    t: "Tax clearance",
    d: "Apply for or verify a Tax Clearance Certificate.",
    tone: "teal"
  }];
  const news = [{
    tag: "Update",
    title: "Pay & File deadline for 2025 returns is 31 October 2026",
    date: "24 Jun 2026"
  }, {
    tag: "Guidance",
    title: "Changes to VAT rates for the hospitality sector",
    date: "18 Jun 2026"
  }, {
    tag: "Service",
    title: "ROS scheduled maintenance this weekend",
    date: "12 Jun 2026"
  }];
  return /*#__PURE__*/React.createElement("main", null, /*#__PURE__*/React.createElement("section", {
    style: {
      background: "var(--green-800)",
      color: "#fff"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: "48px 24px",
      display: "grid",
      gridTemplateColumns: "1.3fr 1fr",
      gap: 40,
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: "var(--text-xs)",
      fontWeight: 700,
      letterSpacing: "0.06em",
      textTransform: "uppercase",
      color: "var(--gold-500)",
      marginBottom: 12
    }
  }, "Pay & File 2026"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: "var(--text-4xl)",
      color: "#fff",
      marginBottom: 14
    }
  }, "Manage your tax and customs online"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: "var(--text-lg)",
      color: "rgba(255,255,255,0.88)",
      margin: "0 0 24px",
      maxWidth: 520
    }
  }, "Sign in to myAccount or ROS to file returns, make payments and view your records."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 12,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    onClick: () => go("signin"),
    style: {
      background: "var(--white)",
      color: "var(--green-800)",
      border: "2px solid var(--white)"
    }
  }, "Sign in to myAccount"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "lg",
    onClick: () => go("signin"),
    style: {
      background: "transparent",
      color: "#fff",
      border: "2px solid rgba(255,255,255,0.6)"
    }
  }, "Register for ROS"))), /*#__PURE__*/React.createElement(Card, {
    padding: "0",
    style: {
      overflow: "hidden",
      border: "none"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--gold-500)",
      height: 8
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 900,
      color: "var(--text-strong)",
      fontSize: "var(--text-lg)",
      marginBottom: 6
    }
  }, "Quick links"), /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: "none",
      margin: 0,
      padding: 0,
      display: "flex",
      flexDirection: "column"
    }
  }, ["File an Income Tax return", "Pay Local Property Tax", "Claim a tax refund", "Get a Tax Clearance Certificate"].map(l => /*#__PURE__*/React.createElement("li", {
    key: l,
    style: {
      borderTop: "1px solid var(--border-subtle)"
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      go("category");
    },
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      padding: "12px 0",
      color: "var(--text-link)",
      textDecoration: "none",
      fontWeight: 700
    }
  }, l, /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true"
  }, "\u2192"))))))))), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: "36px 24px"
    }
  }, /*#__PURE__*/React.createElement(Notice, {
    variant: "warning",
    title: "Important"
  }, "The deadline to pay and file your 2025 Income Tax return through ROS is ", /*#__PURE__*/React.createElement("strong", null, "13 November 2026"), ".")), /*#__PURE__*/React.createElement("section", {
    style: {
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: "8px 24px 44px"
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: "var(--text-2xl)",
      marginBottom: 20
    }
  }, "Popular topics"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(3, 1fr)",
      gap: 16
    }
  }, tiles.map(t => /*#__PURE__*/React.createElement(ServiceTile, {
    key: t.t,
    title: t.t,
    description: t.d,
    tone: t.tone,
    onClick: e => {
      e.preventDefault();
      go("category");
    }
  })))), /*#__PURE__*/React.createElement("section", {
    style: {
      background: "var(--surface-inset)",
      borderTop: "1px solid var(--border-subtle)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: "40px 24px"
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: "var(--text-2xl)",
      marginBottom: 20
    }
  }, "News & updates"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(3, 1fr)",
      gap: 16
    }
  }, news.map(n => /*#__PURE__*/React.createElement(Card, {
    key: n.title,
    as: "a",
    href: "#",
    interactive: true,
    padding: "20px",
    onClick: e => {
      e.preventDefault();
      go("category");
    }
  }, /*#__PURE__*/React.createElement(Tag, {
    variant: "brand"
  }, n.tag), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 900,
      color: "var(--text-strong)",
      fontSize: "var(--text-lg)",
      margin: "12px 0 10px",
      lineHeight: 1.3
    }
  }, n.title), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: "var(--text-sm)",
      color: "var(--text-muted)"
    }
  }, n.date)))))));
}
window.HomePage = HomePage;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/revenue-website/HomePage.jsx", error: String((e && e.message) || e) }); }

// ui_kits/revenue-website/SignInPage.jsx
try { (() => {
// Revenue website — Sign in chooser + myAccount login form.
const {
  Card,
  Input,
  Button,
  Notice,
  Breadcrumb
} = window.RevenueDesignSystem_e63f57;
function SignInPage({
  go
}) {
  const [picked, setPicked] = React.useState(null);
  const services = [{
    id: "myaccount",
    name: "myAccount",
    desc: "PAYE taxpayers — manage tax, claim refunds, update details."
  }, {
    id: "ros",
    name: "ROS",
    desc: "Revenue Online Service — for businesses and the self-assessed."
  }, {
    id: "lpt",
    name: "LPT online",
    desc: "Pay or manage your Local Property Tax."
  }];
  return /*#__PURE__*/React.createElement("main", {
    style: {
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: "28px 24px 56px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement(Breadcrumb, {
    items: [{
      label: "Home",
      href: "#"
    }, {
      label: "Sign in"
    }]
  })), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: "var(--text-3xl)",
      marginBottom: 8
    }
  }, "Sign in to Revenue services"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: "var(--text-lg)",
      color: "var(--text-muted)",
      marginTop: 0,
      marginBottom: 28,
      maxWidth: 640
    }
  }, "Choose the service you want to use. You can also sign in with your verified MyGovID account."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: picked ? "1fr 1.2fr" : "repeat(3,1fr)",
      gap: 20,
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 14
    }
  }, services.map(s => /*#__PURE__*/React.createElement(Card, {
    key: s.id,
    as: "button",
    interactive: true,
    padding: "18px 20px",
    onClick: () => setPicked(s.id),
    style: {
      textAlign: "left",
      cursor: "pointer",
      width: "100%",
      borderColor: picked === s.id ? "var(--green-700)" : "var(--border-default)",
      borderWidth: picked === s.id ? 2 : 1,
      background: picked === s.id ? "var(--green-050)" : "#fff"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 900,
      color: "var(--green-800)",
      fontSize: "var(--text-lg)"
    }
  }, s.name), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      color: "var(--green-700)"
    }
  }, "\u2192")), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: "6px 0 0",
      color: "var(--text-muted)",
      fontSize: "var(--text-sm)"
    }
  }, s.desc)))), picked && /*#__PURE__*/React.createElement(Card, {
    padding: "28px"
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: "var(--text-xl)",
      marginBottom: 16
    }
  }, "Sign in to ", services.find(s => s.id === picked).name), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: picked === "ros" ? "Certificate" : "Email or PPS number",
    hint: picked === "ros" ? "Select your ROS digital certificate" : undefined
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Password",
    type: "password"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 12,
      alignItems: "center",
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    onClick: () => go("home")
  }, "Sign in"), /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      fontWeight: 700
    }
  }, "Forgot password?")), /*#__PURE__*/React.createElement(Notice, {
    variant: "info",
    title: "MyGovID"
  }, "You can also sign in using your verified MyGovID account.")))));
}
window.SignInPage = SignInPage;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/revenue-website/SignInPage.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Card = __ds_scope.Card;

__ds_ns.ServiceTile = __ds_scope.ServiceTile;

__ds_ns.Notice = __ds_scope.Notice;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Radio = __ds_scope.Radio;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Breadcrumb = __ds_scope.Breadcrumb;

__ds_ns.Tabs = __ds_scope.Tabs;

})();

# Revenue Design System

A design system for **Revenue — Irish Tax and Customs** (Office of the Revenue
Commissioners), the Irish government body responsible for assessing and collecting
taxes and duties and administering customs. It is modelled on the public website
**[revenue.ie](https://www.revenue.ie/en/home.aspx)**.

This system gives design agents the colours, typography, components and full-screen
recreations needed to produce on-brand Revenue interfaces, prototypes and assets.

> **Source & accuracy.** Built from visual inspection of the live revenue.ie site.
> Revenue's source code and official brand guidelines were not available, so colour
> hex values, the typeface and iconography are **best-match approximations** — see
> the flagged substitutions below. Swap in official values when supplied.

---

## Product context

Revenue serves two broad audiences through one public site and several signed-in services:

- **Individuals** — PAYE taxpayers using **myAccount** to manage tax, claim refunds, and update details.
- **Businesses & the self-assessed** — using **ROS** (Revenue Online Service) to register, file returns (e.g. VAT3, Form 11) and pay.
- Plus **LPT online** (Local Property Tax), **Customs (AEP)**, and corporate/statistics content.

The public website is informational + transactional: deep navigation into tax
topics, prominent "sign in" routing, and strong deadline/notice messaging.

### Sources used
- Live website: `https://www.revenue.ie/en/home.aspx` (visual reference).
- No Figma, codebase or brand-guideline files were provided.

---

## CONTENT FUNDAMENTALS

How Revenue writes:

- **Voice:** plain, authoritative, public-service. Clear instructions over marketing
  flourish. It reads like official guidance because it is.
- **Person:** addresses the reader as **"you"** ("you must register", "your records",
  "if your turnover exceeds…"); refers to itself as **"Revenue"**, not "we" in most
  guidance.
- **Casing:** **Sentence case** for headings and buttons ("Sign in to myAccount",
  "Manage your tax"). Proper nouns and product names keep their casing: **myAccount**,
  **ROS**, **LPT**, **Pay & File**, **Form 11**, **VAT3**, **PPS number**,
  **Tax Clearance Certificate**.
- **Tone:** precise and obligation-led. Uses "must", "should", "you need to", and
  states thresholds, dates and amounts exactly (e.g. "31 October", "€85,000").
- **Bilingual:** Irish (Gaeilge) is a first-class option — the masthead carries the
  Irish form "Cáin agus Custaim na hÉireann" and an English ⇄ Gaeilge toggle.
- **Numbers & references:** formatted exactly — `€1,450.00`, PPS numbers like
  `1234567T`, dates as `31 October 2026`.
- **No emoji.** Ever. No exclamatory marketing copy. No slang.
- **Examples:**
  - "Sign in to myAccount or ROS to file returns, make payments and view your records."
  - "If your turnover exceeds the VAT thresholds in any continuous 12-month period, you must register for VAT."
  - "The deadline to pay and file your 2025 Income Tax return through ROS is 13 November 2026."

---

## VISUAL FOUNDATIONS

- **Colour vibe:** a confident **brand green** (`--green-700` `#0b5c3f`) is the
  identity colour — used for the main navigation band, service tiles, primary
  buttons and footer. A darker green (`--green-900`) anchors the hero and footer; a
  petrol **teal** supports it. The palette is sober and trustworthy, not vibrant.
- **Accent:** a single **gold** (`#ffbf47`) is used sparingly — bottom rules on
  tiles, hero eyebrows, and as the focus-ring colour. It is the only warm note.
- **Type:** humanist sans (**Lato** as a best-match substitute), set large for
  readability — 17px body, generous 1.55 line-height. Headings are **heavy (900)**
  and set in **sentence case**. Reference numbers use a mono (Roboto Mono).
- **Backgrounds:** flat colour fields, no photography-heavy hero, **no gradients**.
  Sections alternate white / very-light-grey (`--grey-100`) / inset (`--grey-050`),
  with solid green for hero and footer. Full-bleed coloured bands divide the page.
- **Layout:** centred `1200px` max container with a `24px` gutter; reading content
  capped near `720–760px`. Strong use of a left section side-nav on content pages.
- **Cards:** two distinct treatments —
  1. **ServiceTile** — solid green block, white text, a **gold bottom rule**, and an
     arrow that nudges right on hover. The signature Revenue motif.
  2. **Card** — neutral white surface, `1px` hairline border, `8px` radius, very
     subtle shadow (`--shadow-xs`). Borders do more work than shadows.
- **Corner radii:** square-leaning and utilitarian — `4px` on controls, `8px` on
  cards, `2px` on tags. Nothing is heavily rounded.
- **Borders:** prominent. Form controls use a **2px** dark border; dividers are 1px
  hairlines; accent rules are 4px (gold tile rules, green side-nav markers).
- **Shadows:** minimal and restrained — depth is signalled with borders and colour,
  not heavy elevation. The largest shadow (`--shadow-lg`) is reserved for overlays.
- **Hover states:** links darken green and thicken their underline; primary buttons
  darken (`green-700 → green-800`); tiles darken and nudge their arrow. No scale.
- **Focus states:** **GDS-style** — a thick **yellow** background/ring with an ink
  underline (`--shadow-focus`). Highly visible, accessibility-first.
- **Press states:** colour darkening only — no shrink/scale animations.
- **Motion:** quick and functional — `120–260ms`, standard easing. Fades and small
  translations only; **no bounces, no decorative loops**.
- **Transparency / blur:** essentially none. Surfaces are opaque; the system favours
  solid colour and clear contrast over glass effects.

---

## ICONOGRAPHY

- Revenue's public site uses simple, single-weight **line/solid SVG icons** —
  utilitarian, not decorative, paired with clear text labels. Icons rarely appear
  without an adjacent label.
- **The official icon set could not be copied** (the build sandbox cannot fetch
  cross-origin assets from revenue.ie). As a best-match substitute this system uses
  **Material Symbols Rounded** (Google Fonts CDN, weight 500), which matches the
  clean, single-weight, gov-appropriate feel. **Flagged substitution** — replace
  with the official icon set if/when provided.
- Usage: load `Material Symbols Rounded` via CDN and use the `Icon` helper in
  `ui_kits/revenue-website/Chrome.jsx` (`<Icon name="search" />`, `lock`, `public`).
- **No emoji** is used anywhere. Arrows use the Unicode `→` / `›` characters as
  simple directional affordances on tiles, links and breadcrumbs.
- **Logo / emblem:** the official Revenue lockup includes the **State harp emblem**,
  which must **not** be redrawn. A neutral placeholder "R" wordmark stands in until
  the official asset is dropped into `assets/` (see `assets/README.md`).

---

## Index / manifest

Root:
- `styles.css` — global entry point (import this). `@import`s everything below.
- `tokens/` — `fonts.css`, `colors.css`, `typography.css`, `spacing.css`,
  `elevation.css`, `base.css`.
- `assets/` — brand assets (currently placeholders; see its README).
- `SKILL.md` — Agent-Skill manifest for downloadable use.

Components (`window.RevenueDesignSystem_e63f57.*`):
- **forms/** — `Button`, `Input`, `Select`, `Checkbox`, `Radio`
- **feedback/** — `Notice`, `Tag`
- **navigation/** — `Breadcrumb`, `Tabs`
- **content/** — `Card`, `ServiceTile`

Foundation cards (Design System tab): `guidelines/` — colours, type, spacing, brand.

UI kit:
- `ui_kits/revenue-website/` — interactive recreation of revenue.ie
  (home, sign in, category). Open `index.html`.

---

## Flagged substitutions (please confirm)
1. **Colours** — hex values approximated from the live site; confirm against brand guidelines.
2. **Typeface** — **Lato** substituted for Revenue's official sans.
3. **Icons** — **Material Symbols Rounded** substituted for the official icon set.
4. **Logo** — placeholder wordmark; official harp-emblem lockup needed in `assets/`.

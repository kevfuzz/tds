/* @ds-bundle: {"format":3,"namespace":"WinMgtDesignSystem_032a03","components":[{"name":"CommandRow","sourcePath":"components/chrome/CommandRow.jsx"},{"name":"StatusBar","sourcePath":"components/chrome/StatusBar.jsx"},{"name":"Tab","sourcePath":"components/chrome/Tab.jsx"},{"name":"TreeItem","sourcePath":"components/chrome/TreeItem.jsx"},{"name":"Avatar","sourcePath":"components/core/Avatar.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"Checkbox","sourcePath":"components/core/Checkbox.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Input","sourcePath":"components/core/Input.jsx"},{"name":"Select","sourcePath":"components/core/Select.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"}],"sourceHashes":{"components/chrome/CommandRow.jsx":"2fcffc42c1bc","components/chrome/StatusBar.jsx":"28c25d788ac5","components/chrome/Tab.jsx":"1ab49948a09a","components/chrome/TreeItem.jsx":"79702b3392bc","components/core/Avatar.jsx":"f59314d591ce","components/core/Badge.jsx":"e7d0165042cc","components/core/Button.jsx":"6ba5a5bcbaa9","components/core/Card.jsx":"3f8b1aa153e1","components/core/Checkbox.jsx":"23d1fc572bf4","components/core/IconButton.jsx":"0da009713abd","components/core/Input.jsx":"6487e008f8a5","components/core/Select.jsx":"74cd3a7e57b6","components/core/Tag.jsx":"2bb3ddcf6e92","ui_kits/workbench/app.jsx":"ba921930468d","ui_kits/workbench/data.js":"7b9a4e0fa285","ui_kits/workbench/screens.jsx":"8f41d82e1951","ui_kits/workbench/shell.jsx":"403cfb27a08d"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.WinMgtDesignSystem_032a03 = window.WinMgtDesignSystem_032a03 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/chrome/CommandRow.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Command-center result row — one item in the command/customer search overlay.
 * Leading glyph, label, optional muted detail/shortcut on the right. The
 * highlighted (active) row uses the emerald highlight tint.
 */
function CommandRow({
  icon = 'pi pi-angle-right',
  label,
  detail,
  active = false,
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const hot = active || hover;
  return /*#__PURE__*/React.createElement("div", _extends({
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '9px',
      padding: '7px 10px',
      borderRadius: 'var(--radius-sm)',
      cursor: 'pointer',
      fontFamily: 'var(--font-sans)',
      fontSize: '13px',
      color: hot ? 'var(--p-highlight-color)' : 'var(--p-text-color)',
      background: hot ? 'var(--p-highlight-background)' : 'transparent',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("i", {
    className: icon,
    style: {
      fontSize: 13,
      width: 16,
      textAlign: 'center',
      opacity: 0.85
    },
    "aria-hidden": "true"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, label), detail && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      opacity: 0.7
    }
  }, detail));
}
Object.assign(__ds_scope, { CommandRow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/chrome/CommandRow.jsx", error: String((e && e.message) || e) }); }

// components/chrome/StatusBar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Bottom status bar — the emerald band at the foot of the workbench. A flex row
 * of segments; the first (brand) is bold, a spacer pushes the rest right. Each
 * segment is `{ icon?, text, accent? }`. Painted in primary + contrast color.
 */
function StatusBar({
  left = [],
  right = [],
  style
}) {
  const Seg = ({
    icon,
    text,
    accent
  }) => /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '5px',
      padding: '0 8px',
      height: '100%',
      fontWeight: accent ? 600 : 400
    }
  }, icon && /*#__PURE__*/React.createElement("i", {
    className: icon,
    style: {
      fontSize: 12
    },
    "aria-hidden": "true"
  }), text);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '2px',
      height: 24,
      padding: '0 6px',
      background: 'var(--p-primary-color)',
      color: 'var(--p-primary-contrast-color)',
      fontFamily: 'var(--font-sans)',
      fontSize: '12px',
      fontVariantNumeric: 'tabular-nums',
      ...style
    }
  }, left.map((s, i) => /*#__PURE__*/React.createElement(Seg, _extends({
    key: `l${i}`
  }, s))), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }), right.map((s, i) => /*#__PURE__*/React.createElement(Seg, _extends({
    key: `r${i}`
  }, s))));
}
Object.assign(__ds_scope, { StatusBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/chrome/StatusBar.jsx", error: String((e && e.message) || e) }); }

// components/chrome/Tab.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Editor tab — one cell of the custom VSCode-style tab strip. PrimeIcons glyph
 * + label, optional dirty dot, optional close button (appears on hover/active).
 * The active tab in the focused group shows a 2px emerald top indicator.
 */
function Tab({
  label,
  icon = 'pi pi-file',
  active = false,
  dirty = false,
  closeable = true,
  onClick,
  onClose,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", _extends({
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      position: 'relative',
      display: 'inline-flex',
      alignItems: 'center',
      gap: '8px',
      height: 36,
      padding: '0 10px 0 14px',
      minWidth: 120,
      maxWidth: 220,
      borderRight: '1px solid var(--p-content-border-color)',
      background: active ? 'var(--p-content-background)' : 'color-mix(in srgb, var(--p-content-background) 88%, #000)',
      color: active || hover ? 'var(--p-text-color)' : 'var(--p-text-muted-color)',
      fontFamily: 'var(--font-sans)',
      fontSize: '13px',
      cursor: 'pointer',
      userSelect: 'none',
      whiteSpace: 'nowrap',
      ...style
    }
  }, rest), active && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      inset: '0 0 auto 0',
      height: 2,
      background: 'var(--p-primary-color)'
    }
  }), /*#__PURE__*/React.createElement("i", {
    className: icon,
    style: {
      fontSize: 13,
      opacity: 0.85
    },
    "aria-hidden": "true"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      flex: 1
    }
  }, label), dirty && !hover && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--p-primary-color)',
      fontSize: 12
    }
  }, "\u25CF"), closeable && (hover || active) && /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": "Close tab",
    onClick: e => {
      e.stopPropagation();
      onClose && onClose();
    },
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: 18,
      height: 18,
      border: 'none',
      borderRadius: 'var(--radius-sm)',
      background: 'transparent',
      color: 'inherit',
      cursor: 'pointer'
    },
    onMouseEnter: e => e.currentTarget.style.background = 'var(--p-content-hover-background)',
    onMouseLeave: e => e.currentTarget.style.background = 'transparent'
  }, /*#__PURE__*/React.createElement("i", {
    className: "pi pi-times",
    style: {
      fontSize: 11
    },
    "aria-hidden": "true"
  })));
}
Object.assign(__ds_scope, { Tab });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/chrome/Tab.jsx", error: String((e && e.message) || e) }); }

// components/chrome/TreeItem.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Explorer tree item — one row of the sidebar p-tree. Indented by `level`,
 * optional expand chevron for folders, PrimeIcons leading glyph, label. The
 * selected row uses the emerald highlight tint; hover uses the content wash.
 */
function TreeItem({
  label,
  icon = 'pi pi-file',
  level = 0,
  expandable = false,
  expanded = false,
  selected = false,
  onToggle,
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", _extends({
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '6px',
      height: 26,
      paddingLeft: 8 + level * 16,
      paddingRight: 8,
      borderRadius: 'var(--radius-sm)',
      cursor: 'pointer',
      fontFamily: 'var(--font-sans)',
      fontSize: '13px',
      color: selected ? 'var(--p-highlight-color)' : 'var(--p-text-color)',
      background: selected ? 'var(--p-highlight-background)' : hover ? 'var(--p-content-hover-background)' : 'transparent',
      userSelect: 'none',
      ...style
    }
  }, rest), expandable ? /*#__PURE__*/React.createElement("i", {
    className: `pi ${expanded ? 'pi-chevron-down' : 'pi-chevron-right'}`,
    onClick: e => {
      e.stopPropagation();
      onToggle && onToggle();
    },
    style: {
      fontSize: 10,
      width: 12,
      color: 'var(--p-text-muted-color)'
    },
    "aria-hidden": "true"
  }) : /*#__PURE__*/React.createElement("span", {
    style: {
      width: 12,
      flex: '0 0 auto'
    }
  }), /*#__PURE__*/React.createElement("i", {
    className: icon,
    style: {
      fontSize: 13,
      opacity: 0.9
    },
    "aria-hidden": "true"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, label));
}
Object.assign(__ds_scope, { TreeItem });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/chrome/TreeItem.jsx", error: String((e && e.message) || e) }); }

// components/core/Avatar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Avatar — PrimeNG Aura `p-avatar`. A circular (or rounded) monogram chip used
 * for customers/users. Defaults to initials on a neutral surface; pass `icon`
 * for a glyph avatar. Numbers/initials use the sans stack.
 */
function Avatar({
  label,
  icon,
  image,
  shape = 'circle',
  size = 'md',
  style,
  ...rest
}) {
  const sizes = {
    sm: {
      box: 26,
      font: 11
    },
    md: {
      box: 32,
      font: 13
    },
    lg: {
      box: 44,
      font: 17
    }
  };
  const sz = sizes[size] || sizes.md;
  const radius = shape === 'circle' ? '50%' : 'var(--radius-md)';
  const initials = typeof label === 'string' ? label.split(/\s+/).filter(Boolean).slice(0, 2).map(w => w[0]).join('').toUpperCase() : label;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      width: sz.box,
      height: sz.box,
      flex: '0 0 auto',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      borderRadius: radius,
      background: image ? `center/cover url(${image})` : 'var(--p-surface-700)',
      color: 'var(--p-surface-0)',
      fontFamily: 'var(--font-sans)',
      fontSize: sz.font,
      fontWeight: 600,
      overflow: 'hidden',
      ...style
    }
  }, rest), !image && (icon ? /*#__PURE__*/React.createElement("i", {
    className: icon,
    "aria-hidden": "true"
  }) : initials));
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Numeric / count badge — small, bold, high-contrast. Used for queue counts in
 * the sidebar ("My queue (12)") and notification counters. Mirrors PrimeNG
 * `p-badge`. For record *state*, use Tag instead.
 */
function Badge({
  value,
  children,
  severity = 'primary',
  dot = false,
  style,
  ...rest
}) {
  const tones = {
    primary: {
      bg: 'var(--p-primary-color)',
      fg: 'var(--p-primary-contrast-color)'
    },
    secondary: {
      bg: 'var(--p-surface-800)',
      fg: 'var(--p-surface-300)'
    },
    success: {
      bg: 'var(--p-success-color)',
      fg: 'var(--p-success-contrast)'
    },
    info: {
      bg: 'var(--p-info-color)',
      fg: 'var(--p-info-contrast)'
    },
    warn: {
      bg: 'var(--p-warn-color)',
      fg: 'var(--p-warn-contrast)'
    },
    danger: {
      bg: 'var(--p-danger-color)',
      fg: 'var(--p-danger-contrast)'
    }
  };
  const tone = tones[severity] || tones.primary;
  if (dot) {
    return /*#__PURE__*/React.createElement("span", _extends({
      style: {
        display: 'inline-block',
        width: 8,
        height: 8,
        borderRadius: '50%',
        background: tone.bg,
        ...style
      }
    }, rest));
  }
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      minWidth: 20,
      height: 20,
      padding: '0 6px',
      borderRadius: 'var(--radius-md)',
      background: tone.bg,
      color: tone.fg,
      fontFamily: 'var(--font-sans)',
      fontSize: '11px',
      fontWeight: 700,
      fontVariantNumeric: 'tabular-nums',
      lineHeight: 1,
      ...style
    }
  }, rest), value ?? children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * win-mgt primary action button. Mirrors the PrimeNG Aura `p-button` used
 * throughout the workbench (Welcome quick-actions, customer detail, modals).
 * Sentence-case labels, optional leading PrimeIcons glyph, flat fill with a
 * one-step darken on hover/press (no scale).
 */
function Button({
  children,
  icon,
  severity = 'primary',
  variant = 'filled',
  size = 'md',
  disabled = false,
  onClick,
  type = 'button',
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const [active, setActive] = React.useState(false);
  const tones = {
    primary: {
      base: 'var(--p-primary-color)',
      hover: 'var(--p-primary-hover-color)',
      active: 'var(--p-primary-active-color)',
      on: 'var(--p-primary-contrast-color)'
    },
    secondary: {
      base: 'var(--p-surface-800)',
      hover: 'var(--p-surface-700)',
      active: 'var(--p-surface-600)',
      on: 'var(--p-surface-300)'
    },
    success: {
      base: 'var(--p-success-color)',
      hover: 'var(--p-success-color)',
      active: 'var(--p-success-color)',
      on: 'var(--p-success-contrast)'
    },
    info: {
      base: 'var(--p-info-color)',
      hover: 'var(--p-info-color)',
      active: 'var(--p-info-color)',
      on: 'var(--p-info-contrast)'
    },
    warn: {
      base: 'var(--p-warn-color)',
      hover: 'var(--p-warn-color)',
      active: 'var(--p-warn-color)',
      on: 'var(--p-warn-contrast)'
    },
    danger: {
      base: 'var(--p-danger-color)',
      hover: 'var(--p-danger-color)',
      active: 'var(--p-danger-color)',
      on: 'var(--p-danger-contrast)'
    }
  };
  const tone = tones[severity] || tones.primary;
  const sizes = {
    sm: {
      padX: '10px',
      padY: '5px',
      font: '12px',
      gap: '6px'
    },
    md: {
      padX: '14px',
      padY: '8px',
      font: '13px',
      gap: '8px'
    },
    lg: {
      padX: '18px',
      padY: '10px',
      font: '15px',
      gap: '8px'
    }
  };
  const sz = sizes[size] || sizes.md;
  const fill = active ? tone.active : hover ? tone.hover : tone.base;
  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: sz.gap,
    fontFamily: 'var(--font-sans)',
    fontSize: sz.font,
    fontWeight: 500,
    lineHeight: 1.2,
    padding: `${sz.padY} ${sz.padX}`,
    borderRadius: 'var(--radius-md)',
    cursor: disabled ? 'not-allowed' : 'pointer',
    opacity: disabled ? 0.6 : 1,
    transition: 'background 0.2s, color 0.2s, border-color 0.2s',
    userSelect: 'none',
    whiteSpace: 'nowrap'
  };
  let visual;
  if (variant === 'outlined') {
    visual = {
      background: hover ? `color-mix(in srgb, ${tone.base}, transparent 90%)` : 'transparent',
      color: tone.base,
      border: `1px solid ${tone.base}`
    };
  } else if (variant === 'text') {
    visual = {
      background: hover ? `color-mix(in srgb, ${tone.base}, transparent 90%)` : 'transparent',
      color: tone.base,
      border: '1px solid transparent'
    };
  } else {
    visual = {
      background: fill,
      color: tone.on,
      border: `1px solid ${fill}`
    };
  }
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    disabled: disabled,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setActive(false);
    },
    onMouseDown: () => setActive(true),
    onMouseUp: () => setActive(false),
    style: {
      ...base,
      ...visual,
      ...style
    }
  }, rest), icon && /*#__PURE__*/React.createElement("i", {
    className: icon,
    style: {
      fontSize: '0.95em'
    },
    "aria-hidden": "true"
  }), children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Content card — the PrimeNG `p-card` surface used on the Welcome screen and
 * customer detail. Flat content background, hairline border, 12px radius and a
 * faint single-layer lift. Optional header string + footer node.
 */
function Card({
  header,
  subtitle,
  children,
  footer,
  style,
  bodyStyle,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      background: 'var(--p-content-background)',
      border: '1px solid var(--p-content-border-color)',
      borderRadius: 'var(--radius-xl)',
      boxShadow: 'var(--shadow-card)',
      color: 'var(--p-content-color)',
      fontFamily: 'var(--font-sans)',
      overflow: 'hidden',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '20px',
      display: 'flex',
      flexDirection: 'column',
      gap: '8px',
      ...bodyStyle
    }
  }, header && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '2px'
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0,
      fontSize: '15px',
      fontWeight: 600,
      color: 'var(--p-text-color)'
    }
  }, header), subtitle && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '12px',
      color: 'var(--p-text-muted-color)'
    }
  }, subtitle)), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '13px',
      lineHeight: 1.5,
      color: 'var(--p-text-color)'
    }
  }, children), footer && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: '4px'
    }
  }, footer)));
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Checkbox — PrimeNG Aura `p-checkbox`. 20px square, 4px radius, emerald fill +
 * contrast check when on. Optional trailing label.
 */
function Checkbox({
  checked = false,
  label,
  disabled = false,
  onChange,
  id,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const box = {
    width: 20,
    height: 20,
    flex: '0 0 auto',
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 'var(--radius-sm)',
    border: `1px solid ${checked ? 'var(--p-primary-color)' : hover ? 'var(--p-form-field-hover-border-color)' : 'var(--p-form-field-border-color)'}`,
    background: checked ? 'var(--p-primary-color)' : 'var(--p-form-field-background)',
    color: 'var(--p-primary-contrast-color)',
    transition: 'background 0.2s, border-color 0.2s'
  };
  return /*#__PURE__*/React.createElement("label", {
    htmlFor: id,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '8px',
      fontFamily: 'var(--font-sans)',
      fontSize: '13px',
      color: 'var(--p-text-color)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.6 : 1,
      userSelect: 'none',
      ...style
    }
  }, /*#__PURE__*/React.createElement("input", _extends({
    id: id,
    type: "checkbox",
    checked: checked,
    disabled: disabled,
    onChange: e => onChange && onChange(e.target.checked),
    style: {
      position: 'absolute',
      opacity: 0,
      width: 0,
      height: 0
    }
  }, rest)), /*#__PURE__*/React.createElement("span", {
    style: box,
    "aria-hidden": "true"
  }, checked && /*#__PURE__*/React.createElement("i", {
    className: "pi pi-check",
    style: {
      fontSize: 12
    }
  })), label && /*#__PURE__*/React.createElement("span", null, label));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Square, transparent icon button — the workhorse of win-mgt chrome (menu-bar
 * icons, tab close, toolbar actions). Muted by default, brightens with a faint
 * white wash on hover. PrimeIcons glyph only.
 */
function IconButton({
  icon,
  label,
  size = 'md',
  active = false,
  disabled = false,
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const sizes = {
    sm: {
      box: 22,
      font: 12,
      radius: 'var(--radius-sm)'
    },
    md: {
      box: 28,
      font: 13,
      radius: 'var(--radius-sm)'
    },
    lg: {
      box: 34,
      font: 16,
      radius: 'var(--radius-md)'
    }
  };
  const sz = sizes[size] || sizes.md;
  const color = active || hover ? 'var(--p-text-color)' : 'var(--p-text-muted-color)';
  const bg = hover && !disabled ? 'var(--p-content-hover-background)' : 'transparent';
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    "aria-label": label,
    title: label,
    disabled: disabled,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      width: sz.box,
      height: sz.box,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      border: 'none',
      background: bg,
      color,
      borderRadius: sz.radius,
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1,
      transition: 'background 0.2s, color 0.2s',
      fontSize: sz.font,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("i", {
    className: icon,
    "aria-hidden": "true"
  }));
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Text input — PrimeNG Aura `pInputText`. Dark field background, hairline
 * border that turns emerald on focus, optional leading PrimeIcons glyph and an
 * optional label above. Used in the OS modal customer editor and forms.
 */
function Input({
  label,
  icon,
  value,
  defaultValue,
  placeholder,
  type = 'text',
  size = 'md',
  disabled = false,
  invalid = false,
  onChange,
  style,
  id,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const sizes = {
    sm: {
      padY: '6px',
      font: '12px'
    },
    md: {
      padY: '8px',
      font: '14px'
    },
    lg: {
      padY: '10px',
      font: '15px'
    }
  };
  const sz = sizes[size] || sizes.md;
  const borderColor = invalid ? 'var(--p-danger-color)' : focus ? 'var(--p-primary-color)' : 'var(--p-form-field-border-color)';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '4px',
      fontFamily: 'var(--font-sans)',
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: id,
    style: {
      fontSize: '12px',
      fontWeight: 600,
      color: 'var(--p-text-color)'
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      display: 'flex',
      alignItems: 'center'
    }
  }, icon && /*#__PURE__*/React.createElement("i", {
    className: icon,
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      left: 10,
      fontSize: 13,
      color: 'var(--p-text-muted-color)',
      pointerEvents: 'none'
    }
  }), /*#__PURE__*/React.createElement("input", _extends({
    id: id,
    type: type,
    value: value,
    defaultValue: defaultValue,
    placeholder: placeholder,
    disabled: disabled,
    onChange: onChange,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      width: '100%',
      boxSizing: 'border-box',
      padding: `${sz.padY} 12px ${sz.padY} ${icon ? '32px' : '12px'}`,
      fontFamily: 'var(--font-sans)',
      fontSize: sz.font,
      color: 'var(--p-form-field-color)',
      background: 'var(--p-form-field-background)',
      border: `1px solid ${borderColor}`,
      borderRadius: 'var(--radius-md)',
      outline: 'none',
      opacity: disabled ? 0.6 : 1,
      transition: 'border-color 0.2s'
    }
  }, rest))));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Input.jsx", error: String((e && e.message) || e) }); }

// components/core/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Select / dropdown — PrimeNG Aura `p-select`. A button-like field showing the
 * current value with a chevron; clicking opens an overlay list of options.
 * Used for account-tier pickers in the customer editor.
 */
function Select({
  options = [],
  value,
  placeholder = 'Select',
  label,
  size = 'md',
  disabled = false,
  onChange,
  style,
  ...rest
}) {
  const [open, setOpen] = React.useState(false);
  const [hover, setHover] = React.useState(false);
  const ref = React.useRef(null);
  React.useEffect(() => {
    const onDoc = e => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener('mousedown', onDoc);
    return () => document.removeEventListener('mousedown', onDoc);
  }, []);
  const norm = options.map(o => typeof o === 'string' ? {
    label: o,
    value: o
  } : o);
  const current = norm.find(o => o.value === value);
  const sizes = {
    sm: '6px 10px',
    md: '8px 12px',
    lg: '10px 14px'
  };
  const pick = o => {
    setOpen(false);
    onChange && onChange(o.value);
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '4px',
      fontFamily: 'var(--font-sans)',
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    style: {
      fontSize: '12px',
      fontWeight: 600,
      color: 'var(--p-text-color)'
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    ref: ref,
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    disabled: disabled,
    onClick: () => setOpen(v => !v),
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      width: '100%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: '8px',
      padding: sizes[size] || sizes.md,
      fontFamily: 'var(--font-sans)',
      fontSize: '14px',
      textAlign: 'left',
      color: current ? 'var(--p-form-field-color)' : 'var(--p-form-field-placeholder-color)',
      background: 'var(--p-form-field-background)',
      border: `1px solid ${open ? 'var(--p-primary-color)' : hover ? 'var(--p-form-field-hover-border-color)' : 'var(--p-form-field-border-color)'}`,
      borderRadius: 'var(--radius-md)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.6 : 1,
      transition: 'border-color 0.2s'
    }
  }, rest), /*#__PURE__*/React.createElement("span", null, current ? current.label : placeholder), /*#__PURE__*/React.createElement("i", {
    className: "pi pi-chevron-down",
    style: {
      fontSize: 12,
      color: 'var(--p-text-muted-color)'
    },
    "aria-hidden": "true"
  })), open && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 'calc(100% + 4px)',
      left: 0,
      right: 0,
      zIndex: 1000,
      background: 'var(--p-overlay-popover-background)',
      border: '1px solid var(--p-content-border-color)',
      borderRadius: 'var(--radius-md)',
      boxShadow: 'var(--shadow-select)',
      padding: '4px',
      maxHeight: 240,
      overflowY: 'auto'
    }
  }, norm.map(o => {
    const sel = o.value === value;
    return /*#__PURE__*/React.createElement("div", {
      key: o.value,
      onClick: () => pick(o),
      style: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '7px 10px',
        borderRadius: 'var(--radius-sm)',
        fontSize: '13px',
        cursor: 'pointer',
        color: sel ? 'var(--p-highlight-color)' : 'var(--p-text-color)',
        background: sel ? 'var(--p-highlight-background)' : 'transparent'
      },
      onMouseEnter: e => {
        if (!sel) e.currentTarget.style.background = 'var(--p-content-hover-background)';
      },
      onMouseLeave: e => {
        if (!sel) e.currentTarget.style.background = 'transparent';
      }
    }, o.label, sel && /*#__PURE__*/React.createElement("i", {
      className: "pi pi-check",
      style: {
        fontSize: 12
      },
      "aria-hidden": "true"
    }));
  }))));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Select.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Status tag — the primary way win-mgt shows record state (active / pending /
 * closed) in tables and detail headers. Mirrors PrimeNG `p-tag`: a pill with a
 * tinted background and saturated text in the matching semantic hue.
 */
function Tag({
  value,
  children,
  severity = 'info',
  icon,
  style,
  ...rest
}) {
  const tones = {
    success: 'var(--p-success-color)',
    info: 'var(--p-info-color)',
    warn: 'var(--p-warn-color)',
    danger: 'var(--p-danger-color)',
    primary: 'var(--p-primary-color)',
    neutral: 'var(--p-text-muted-color)'
  };
  const c = tones[severity] || tones.info;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '5px',
      padding: '3px 10px',
      borderRadius: 'var(--radius-pill)',
      background: `color-mix(in srgb, ${c}, transparent 84%)`,
      color: c,
      fontFamily: 'var(--font-sans)',
      fontSize: '12px',
      fontWeight: 500,
      lineHeight: 1.4,
      whiteSpace: 'nowrap',
      ...style
    }
  }, rest), icon && /*#__PURE__*/React.createElement("i", {
    className: icon,
    style: {
      fontSize: '0.9em'
    },
    "aria-hidden": "true"
  }), value ?? children);
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// ui_kits/workbench/app.jsx
try { (() => {
// Root interactive App for the win-mgt workbench kit. Owns theme, activity view,
// tab state, command-center search and the OS-modal overlay.
(function () {
  const {
    customers,
    severityFor
  } = window.WinMgtData;
  let tabSeq = 1;
  const makeTab = (key, label, icon, customer) => ({
    id: 'tab' + tabSeq++,
    key,
    label,
    icon,
    customer: customer || null
  });
  function App() {
    const [dark, setDark] = React.useState(true);
    const [view, setView] = React.useState('explorer');
    const [sidebar, setSidebar] = React.useState(true);
    const [tabs, setTabs] = React.useState(() => [makeTab('welcome', 'Welcome', 'pi pi-home')]);
    const [activeId, setActiveId] = React.useState(null);
    const [modal, setModal] = React.useState(null); // {customer} | null
    // command center
    const [query, setQuery] = React.useState('');
    const [ccOpen, setCcOpen] = React.useState(false);
    const [highlight, setHighlight] = React.useState(0);
    React.useEffect(() => {
      setActiveId(id => id || tabs[0].id);
    }, []);
    React.useEffect(() => {
      document.documentElement.classList.toggle('light', !dark);
    }, [dark]);
    const active = tabs.find(t => t.id === activeId) || null;
    const openTab = (key, label, icon, customer) => {
      setTabs(prev => {
        const existing = prev.find(t => t.key === key && (!customer || t.customer && t.customer.id === customer.id));
        if (existing) {
          setActiveId(existing.id);
          return prev;
        }
        const t = makeTab(key, label, icon, customer);
        setActiveId(t.id);
        return [...prev, t];
      });
    };
    const openActions = {
      welcome: () => openTab('welcome', 'Welcome', 'pi pi-home'),
      queue: () => openTab('queue', 'Customer queue', 'pi pi-table'),
      embed: () => openTab('embed', 'Customer record (JSP)', 'pi pi-globe'),
      modal: () => setModal({
        customer: customers[0]
      })
    };
    const openCustomer = c => openTab('cust' + c.id, c.name, 'pi pi-user', c);
    const openByKey = key => openActions[key] ? openActions[key]() : openActions.welcome();
    const closeTab = id => {
      setTabs(prev => {
        const idx = prev.findIndex(t => t.id === id);
        const next = prev.filter(t => t.id !== id);
        if (id === activeId) {
          const fallback = next[idx] || next[idx - 1] || next[0] || null;
          setActiveId(fallback ? fallback.id : null);
        }
        return next;
      });
    };

    // Commands available in the command center
    const commands = [{
      id: 'view.welcome',
      title: 'View: Open Welcome',
      icon: 'pi pi-home',
      run: openActions.welcome
    }, {
      id: 'view.queue',
      title: 'View: Open Customer Queue',
      icon: 'pi pi-table',
      run: openActions.queue
    }, {
      id: 'view.legacy',
      title: 'Legacy: Open JSP Panel',
      icon: 'pi pi-globe',
      run: openActions.embed
    }, {
      id: 'view.toggleSidebar',
      title: 'View: Toggle Sidebar',
      icon: 'pi pi-bars',
      shortcut: 'Ctrl+B',
      run: () => setSidebar(v => !v)
    }, {
      id: 'pref.theme',
      title: 'Preferences: Toggle Light/Dark Theme',
      icon: 'pi pi-sun',
      run: () => setDark(v => !v)
    }, {
      id: 'modal.demo',
      title: 'Window: Open OS Modal (over JSP)',
      icon: 'pi pi-window-maximize',
      run: openActions.modal
    }];
    const results = React.useMemo(() => {
      const q = query.trim();
      const cmd = f => commands.filter(c => !f || c.title.toLowerCase().includes(f.toLowerCase())).map(c => ({
        key: 'c:' + c.id,
        group: 'Commands',
        icon: c.icon,
        label: c.title,
        detail: c.shortcut,
        run: c.run
      }));
      const cust = t => window.WinMgtData.search(t).map(c => ({
        key: 'u:' + c.id,
        group: 'Customers',
        icon: 'pi pi-user',
        label: `#${c.id} · ${c.name}`,
        detail: `${c.account} · ${c.status}`,
        run: () => openCustomer(c)
      }));
      if (q.startsWith('>')) return cmd(q.slice(1).trim());
      if (!q) return cmd('');
      return [...cust(q), ...cmd(q)];
    }, [query, tabs]);
    const pick = r => {
      r.run();
      setQuery('');
      setHighlight(0);
      setCcOpen(false);
    };
    const selectActivity = v => {
      if (v === view) setSidebar(s => !s);else {
        setView(v);
        setSidebar(true);
      }
    };
    const groupCount = 1;
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        height: '100%',
        overflow: 'hidden',
        background: 'var(--p-content-background)',
        color: 'var(--p-text-color)'
      }
    }, /*#__PURE__*/React.createElement(window.MenuBar, {
      query: query,
      setQuery: setQuery,
      results: results,
      onPick: pick,
      open: ccOpen,
      setOpen: setCcOpen,
      highlight: highlight,
      setHighlight: setHighlight
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minHeight: 0,
        display: 'flex'
      }
    }, /*#__PURE__*/React.createElement(window.ActivityBar, {
      active: view,
      onSelect: selectActivity,
      dark: dark,
      onToggleTheme: () => setDark(v => !v)
    }), sidebar && /*#__PURE__*/React.createElement(window.Sidebar, {
      view: view,
      activeKey: active ? active.key : null,
      onOpen: openByKey
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0,
        display: 'flex',
        flexDirection: 'column',
        position: 'relative'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        height: 36,
        background: 'var(--p-content-background)',
        borderBottom: '1px solid var(--p-content-border-color)',
        overflowX: 'auto'
      }
    }, tabs.map(t => /*#__PURE__*/React.createElement(window.WMTab, {
      key: t.id,
      tab: t,
      active: t.id === activeId,
      onClick: () => setActiveId(t.id),
      onClose: () => closeTab(t.id)
    }))), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minHeight: 0,
        position: 'relative',
        overflow: 'hidden'
      }
    }, !active && /*#__PURE__*/React.createElement(Empty, null), active && active.key === 'welcome' && /*#__PURE__*/React.createElement(window.WelcomeScreen, {
      open: k => openByKey(k)
    }), active && active.key === 'queue' && /*#__PURE__*/React.createElement(window.CustomerQueue, {
      openCustomer: openCustomer,
      openModal: () => setModal({
        customer: customers[0]
      })
    }), active && active.key === 'embed' && /*#__PURE__*/React.createElement(window.LegacyPanel, null), active && active.key.startsWith('cust') && /*#__PURE__*/React.createElement(window.CustomerDetail, {
      customer: active.customer,
      openModal: c => setModal({
        customer: c
      })
    })), modal && /*#__PURE__*/React.createElement(window.ModalEditor, {
      customer: modal.customer,
      onClose: () => setModal(null)
    }))), /*#__PURE__*/React.createElement(window.StatusBar, {
      left: [{
        icon: 'pi pi-bolt',
        text: 'win-mgt POC',
        accent: true
      }, {
        text: 'Browser'
      }],
      right: [{
        text: `${groupCount} group`
      }, {
        text: `${tabs.length} tab${tabs.length === 1 ? '' : 's'}`
      }, {
        icon: 'pi pi-check-circle',
        text: 'Ready'
      }]
    }));
  }
  function Empty() {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 8,
        color: 'var(--p-text-muted-color)'
      }
    }, /*#__PURE__*/React.createElement("i", {
      className: "pi pi-window-maximize",
      style: {
        fontSize: 32,
        opacity: 0.5
      }
    }), /*#__PURE__*/React.createElement("p", null, "No open editors in this group"));
  }

  // Wrapper so the design-system Tab gets the tab's fields.
  function WMTab({
    tab,
    active,
    onClick,
    onClose
  }) {
    const {
      Tab
    } = window.WinMgtDesignSystem_032a03;
    return /*#__PURE__*/React.createElement(Tab, {
      label: tab.label,
      icon: tab.icon,
      active: active,
      dirty: tab.key === 'embed',
      onClick: onClick,
      onClose: onClose
    });
  }
  Object.assign(window, {
    WinMgtApp: App,
    WMTab
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/workbench/app.jsx", error: String((e && e.message) || e) }); }

// ui_kits/workbench/data.js
try { (() => {
// Shared customer dataset — mirrors win-mgt's CustomerService seed (40 rows,
// deterministic pseudo-balance) so the kit matches the real app's data shape.
(function () {
  const names = ['Acme Co', 'Globex', 'Initech', 'Umbrella', 'Soylent', 'Hooli'];
  const accounts = ['Standard', 'Premium', 'Enterprise'];
  const statuses = ['active', 'pending', 'closed'];
  const customers = Array.from({
    length: 40
  }, (_, i) => ({
    id: 1000 + i,
    name: `${names[i % names.length]} #${i}`,
    account: accounts[i % accounts.length],
    status: statuses[i % statuses.length],
    balance: Math.round((i * 37 % 100 + 1) * 137.45 * 100) / 100
  }));
  const severityFor = s => s === 'active' ? 'success' : s === 'pending' ? 'warn' : 'danger';
  const fmtCurrency = n => n.toLocaleString('en-US', {
    style: 'currency',
    currency: 'USD'
  });
  const search = (q, limit = 8) => {
    const t = String(q).trim().toLowerCase();
    if (!t) return [];
    return customers.filter(c => String(c.id).includes(t) || c.name.toLowerCase().includes(t)).slice(0, limit);
  };
  window.WinMgtData = {
    customers,
    severityFor,
    fmtCurrency,
    search
  };
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/workbench/data.js", error: String((e && e.message) || e) }); }

// ui_kits/workbench/screens.jsx
try { (() => {
// Content screens for the win-mgt workbench kit. These render inside an editor
// group. They compose design-system primitives from window.WinMgtDesignSystem_032a03.
(function () {
  const DS = window.WinMgtDesignSystem_032a03;
  const {
    Button,
    Tag,
    Card,
    Avatar,
    Input,
    Select
  } = DS;
  const {
    customers,
    severityFor,
    fmtCurrency
  } = window.WinMgtData;

  // ---- Welcome -------------------------------------------------------------
  function WelcomeScreen({
    open
  }) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        padding: '28px 32px',
        height: '100%',
        overflow: 'auto'
      }
    }, /*#__PURE__*/React.createElement("h1", {
      style: {
        margin: 0,
        fontSize: 28,
        fontWeight: 700
      }
    }, "win-mgt"), /*#__PURE__*/React.createElement("p", {
      style: {
        color: 'var(--p-text-muted-color)',
        margin: '4px 0 24px',
        fontSize: 13
      }
    }, "VSCode-style shell \xB7 Electron + Angular + PrimeNG \xB7 embedded legacy panels"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))',
        gap: 16,
        maxWidth: 980
      }
    }, /*#__PURE__*/React.createElement(Card, {
      header: "Embedded legacy app",
      footer: /*#__PURE__*/React.createElement(Button, {
        icon: "pi pi-globe",
        size: "sm",
        onClick: () => open('embed')
      }, "Open legacy panel")
    }, "Open the JSP stand-in in a WebContentsView. Type into it, then switch tabs or split the editor \u2014 its state survives."), /*#__PURE__*/React.createElement(Card, {
      header: "Angular content + PrimeNG",
      footer: /*#__PURE__*/React.createElement(Button, {
        icon: "pi pi-table",
        size: "sm",
        onClick: () => open('queue')
      }, "Open customer queue")
    }, "A PrimeNG data table rendered in the Angular DOM layer."), /*#__PURE__*/React.createElement(Card, {
      header: "Modal over the JSP",
      footer: /*#__PURE__*/React.createElement(Button, {
        icon: "pi pi-window-maximize",
        size: "sm",
        onClick: () => open('modal')
      }, "Open OS modal")
    }, "PrimeNG dialogs can't paint over a WebContentsView. App-level modals open as an OS BrowserWindow instead.")));
  }

  // ---- Customer queue (data table) ----------------------------------------
  function CustomerQueue({
    openCustomer,
    openModal
  }) {
    const [hoverRow, setHoverRow] = React.useState(null);
    return /*#__PURE__*/React.createElement("div", {
      style: {
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        padding: '12px 16px',
        overflow: 'hidden'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginBottom: 10
      }
    }, /*#__PURE__*/React.createElement("h2", {
      style: {
        fontSize: 15,
        margin: 0,
        fontWeight: 600
      }
    }, "Customer queue"), /*#__PURE__*/React.createElement(Button, {
      icon: "pi pi-external-link",
      size: "sm",
      onClick: openModal
    }, "Open record (modal over JSP)")), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minHeight: 0,
        overflow: 'auto',
        border: '1px solid var(--p-content-border-color)',
        borderRadius: 'var(--radius-md)'
      }
    }, /*#__PURE__*/React.createElement("table", {
      style: {
        width: '100%',
        borderCollapse: 'collapse',
        fontSize: 13
      }
    }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", {
      style: {
        position: 'sticky',
        top: 0,
        background: 'var(--p-content-background)'
      }
    }, ['ID', 'Name', 'Account', 'Status', 'Balance'].map(h => /*#__PURE__*/React.createElement("th", {
      key: h,
      style: {
        textAlign: h === 'Balance' ? 'right' : 'left',
        padding: '10px 14px',
        fontWeight: 600,
        color: 'var(--p-text-color)',
        borderBottom: '1px solid var(--p-content-border-color)'
      }
    }, h)))), /*#__PURE__*/React.createElement("tbody", null, customers.map(c => /*#__PURE__*/React.createElement("tr", {
      key: c.id,
      onClick: () => openCustomer(c),
      onMouseEnter: () => setHoverRow(c.id),
      onMouseLeave: () => setHoverRow(null),
      style: {
        cursor: 'pointer',
        background: hoverRow === c.id ? 'var(--p-content-hover-background)' : 'transparent'
      }
    }, /*#__PURE__*/React.createElement("td", {
      style: {
        padding: '8px 14px',
        fontVariantNumeric: 'tabular-nums',
        color: 'var(--p-text-muted-color)',
        borderBottom: '1px solid color-mix(in srgb, var(--p-content-border-color), transparent 55%)'
      }
    }, c.id), /*#__PURE__*/React.createElement("td", {
      style: {
        padding: '8px 14px',
        borderBottom: '1px solid color-mix(in srgb, var(--p-content-border-color), transparent 55%)'
      }
    }, c.name), /*#__PURE__*/React.createElement("td", {
      style: {
        padding: '8px 14px',
        color: 'var(--p-text-muted-color)',
        borderBottom: '1px solid color-mix(in srgb, var(--p-content-border-color), transparent 55%)'
      }
    }, c.account), /*#__PURE__*/React.createElement("td", {
      style: {
        padding: '8px 14px',
        borderBottom: '1px solid color-mix(in srgb, var(--p-content-border-color), transparent 55%)'
      }
    }, /*#__PURE__*/React.createElement(Tag, {
      value: c.status,
      severity: severityFor(c.status)
    })), /*#__PURE__*/React.createElement("td", {
      style: {
        padding: '8px 14px',
        textAlign: 'right',
        fontVariantNumeric: 'tabular-nums',
        borderBottom: '1px solid color-mix(in srgb, var(--p-content-border-color), transparent 55%)'
      }
    }, fmtCurrency(c.balance))))))));
  }

  // ---- Customer detail -----------------------------------------------------
  function CustomerDetail({
    customer,
    openModal
  }) {
    if (!customer) return /*#__PURE__*/React.createElement("div", {
      style: {
        padding: 32,
        color: 'var(--p-text-muted-color)'
      }
    }, "Customer not found.");
    const c = customer;
    const fields = [['Account type', c.account], ['Status', c.status], ['Balance', fmtCurrency(c.balance)], ['Customer number', c.id]];
    return /*#__PURE__*/React.createElement("div", {
      style: {
        padding: '28px 32px',
        height: '100%',
        overflow: 'auto'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'flex-start',
        justifyContent: 'space-between',
        marginBottom: 18
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 14,
        alignItems: 'center'
      }
    }, /*#__PURE__*/React.createElement(Avatar, {
      label: c.name,
      size: "lg"
    }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
      style: {
        margin: 0,
        fontSize: 24,
        fontWeight: 600
      }
    }, c.name), /*#__PURE__*/React.createElement("span", {
      style: {
        color: 'var(--p-text-muted-color)',
        fontSize: 13,
        fontVariantNumeric: 'tabular-nums'
      }
    }, "Customer #", c.id))), /*#__PURE__*/React.createElement(Tag, {
      value: c.status,
      severity: severityFor(c.status)
    })), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gridTemplateColumns: 'repeat(2, minmax(160px, 1fr))',
        gap: 18,
        maxWidth: 560
      }
    }, fields.map(([k, v]) => /*#__PURE__*/React.createElement("div", {
      key: k
    }, /*#__PURE__*/React.createElement("label", {
      style: {
        display: 'block',
        fontSize: 12,
        color: 'var(--p-text-muted-color)',
        marginBottom: 2
      }
    }, k), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 15,
        fontWeight: 600,
        fontVariantNumeric: 'tabular-nums'
      }
    }, v))))), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 18
      }
    }, /*#__PURE__*/React.createElement(Button, {
      icon: "pi pi-pencil",
      onClick: () => openModal(c)
    }, "Edit record (modal over JSP)")));
  }

  // ---- Legacy embed panel (the JSP stand-in, rendered as an iframe) --------
  function LegacyPanel() {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        height: '100%',
        position: 'relative',
        background: 'var(--p-content-background)'
      }
    }, /*#__PURE__*/React.createElement("iframe", {
      src: "../../assets/reference/legacy-form.html",
      title: "Customer record (JSP)",
      style: {
        width: '100%',
        height: '100%',
        border: 'none',
        display: 'block'
      }
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        top: 8,
        right: 12,
        fontSize: 10,
        letterSpacing: '.04em',
        textTransform: 'uppercase',
        background: 'var(--legacy-accent)',
        color: '#fff',
        padding: '2px 8px',
        borderRadius: 10
      }
    }, "Legacy \xB7 WebContentsView"));
  }

  // ---- OS modal editor (overlay) ------------------------------------------
  function ModalEditor({
    customer,
    onClose
  }) {
    const [name, setName] = React.useState(customer ? customer.name : 'Acme Co');
    const [tier, setTier] = React.useState(customer ? customer.account : 'Premium');
    return /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        inset: 0,
        background: 'var(--p-mask-background)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 2000
      },
      onClick: onClose
    }, /*#__PURE__*/React.createElement("div", {
      onClick: e => e.stopPropagation(),
      style: {
        width: 420,
        background: 'var(--p-overlay-modal-background)',
        border: '1px solid var(--p-content-border-color)',
        borderRadius: 'var(--radius-xl)',
        boxShadow: 'var(--shadow-modal)',
        overflow: 'hidden'
      }
    }, /*#__PURE__*/React.createElement("header", {
      style: {
        padding: '14px 18px',
        fontSize: 15,
        fontWeight: 600,
        borderBottom: '1px solid var(--p-content-border-color)',
        display: 'flex',
        gap: 8,
        alignItems: 'center'
      }
    }, /*#__PURE__*/React.createElement("i", {
      className: "pi pi-id-card"
    }), " Edit customer #", customer ? customer.id : 1000), /*#__PURE__*/React.createElement("div", {
      style: {
        padding: 18,
        display: 'flex',
        flexDirection: 'column',
        gap: 14
      }
    }, /*#__PURE__*/React.createElement(Input, {
      label: "Name",
      value: name,
      onChange: e => setName(e.target.value)
    }), /*#__PURE__*/React.createElement(Select, {
      label: "Account tier",
      options: ['Standard', 'Premium', 'Enterprise'],
      value: tier,
      onChange: setTier
    }), /*#__PURE__*/React.createElement("p", {
      style: {
        margin: '4px 0 0',
        fontSize: 12,
        color: 'var(--p-text-muted-color)'
      }
    }, /*#__PURE__*/React.createElement("i", {
      className: "pi pi-info-circle"
    }), " This dialog is a separate OS window \u2014 it paints cleanly over the JSP panel, which PrimeNG dialogs cannot do.")), /*#__PURE__*/React.createElement("footer", {
      style: {
        padding: '12px 18px',
        display: 'flex',
        justifyContent: 'flex-end',
        gap: 8,
        borderTop: '1px solid var(--p-content-border-color)'
      }
    }, /*#__PURE__*/React.createElement(Button, {
      severity: "secondary",
      variant: "text",
      onClick: onClose
    }, "Cancel"), /*#__PURE__*/React.createElement(Button, {
      icon: "pi pi-check",
      onClick: onClose
    }, "Save"))));
  }
  Object.assign(window, {
    WelcomeScreen,
    CustomerQueue,
    CustomerDetail,
    LegacyPanel,
    ModalEditor
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/workbench/screens.jsx", error: String((e && e.message) || e) }); }

// ui_kits/workbench/shell.jsx
try { (() => {
// Workbench shell chrome + the interactive App that wires tabs, command center,
// sidebar and screens together. Composes design-system primitives + screens.
(function () {
  const DS = window.WinMgtDesignSystem_032a03;
  const {
    IconButton,
    Tab,
    StatusBar,
    CommandRow,
    TreeItem
  } = DS;
  const {
    customers,
    severityFor,
    search
  } = window.WinMgtData;

  // ---- Menu bar (brand · File/View · command center) ----------------------
  function MenuBar({
    onFocusSearch,
    query,
    setQuery,
    results,
    onPick,
    open,
    setOpen,
    highlight,
    setHighlight
  }) {
    const inputRef = React.useRef(null);
    React.useEffect(() => {
      if (onFocusSearch) onFocusSearch(() => inputRef.current && inputRef.current.focus());
    }, [onFocusSearch]);
    const onKey = e => {
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setHighlight(h => Math.min(h + 1, results.length - 1));
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        setHighlight(h => Math.max(h - 1, 0));
      } else if (e.key === 'Enter') {
        e.preventDefault();
        const r = results[highlight];
        if (r) onPick(r);
      } else if (e.key === 'Escape') {
        setOpen(false);
        inputRef.current && inputRef.current.blur();
      }
    };
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        height: 36,
        padding: '0 10px',
        background: 'color-mix(in srgb, var(--p-content-background) 78%, #000)',
        borderBottom: '1px solid var(--p-content-border-color)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 4
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 6,
        fontWeight: 600,
        fontSize: 13,
        padding: '0 10px 0 4px'
      }
    }, /*#__PURE__*/React.createElement("i", {
      className: "pi pi-bolt",
      style: {
        color: 'var(--p-primary-color)'
      }
    }), " win-mgt"), /*#__PURE__*/React.createElement(MenuButton, {
      label: "File"
    }), /*#__PURE__*/React.createElement(MenuButton, {
      label: "View"
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        display: 'flex',
        justifyContent: 'center'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'relative',
        width: '100%',
        maxWidth: 560
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        height: 26,
        padding: '0 6px',
        border: `1px solid ${open ? 'var(--p-primary-color)' : 'var(--p-content-border-color)'}`,
        borderRadius: 'var(--radius-md)',
        background: 'color-mix(in srgb, var(--p-content-background) 80%, #000)'
      }
    }, /*#__PURE__*/React.createElement("i", {
      className: "pi pi-search",
      style: {
        fontSize: 12,
        color: 'var(--p-text-muted-color)',
        margin: '0 6px'
      }
    }), /*#__PURE__*/React.createElement("input", {
      ref: inputRef,
      value: query,
      placeholder: "Search customers by number/name, or type > for commands",
      onFocus: () => setOpen(true),
      onBlur: () => setTimeout(() => setOpen(false), 120),
      onChange: e => {
        setQuery(e.target.value);
        setHighlight(0);
      },
      onKeyDown: onKey,
      style: {
        flex: 1,
        border: 'none',
        outline: 'none',
        background: 'transparent',
        color: 'var(--p-text-color)',
        fontSize: 12.5,
        fontFamily: 'var(--font-sans)'
      }
    }), query && /*#__PURE__*/React.createElement(IconButton, {
      icon: "pi pi-times",
      size: "sm",
      label: "Clear",
      onMouseDown: e => e.preventDefault(),
      onClick: () => setQuery('')
    })), open && /*#__PURE__*/React.createElement("div", {
      onMouseDown: e => e.preventDefault(),
      style: {
        position: 'absolute',
        top: 'calc(100% + 4px)',
        left: 0,
        right: 0,
        zIndex: 1000,
        background: 'var(--p-overlay-popover-background)',
        border: '1px solid var(--p-content-border-color)',
        borderRadius: 'var(--radius-md)',
        boxShadow: 'var(--shadow-popover)',
        maxHeight: 360,
        overflow: 'auto',
        padding: 4
      }
    }, results.length === 0 && /*#__PURE__*/React.createElement("div", {
      style: {
        padding: '12px',
        textAlign: 'center',
        fontSize: 13,
        color: 'var(--p-text-muted-color)'
      }
    }, "No results for \u201C", query, "\u201D"), results.map((r, i) => /*#__PURE__*/React.createElement(React.Fragment, {
      key: r.key
    }, (i === 0 || results[i - 1].group !== r.group) && /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 10,
        letterSpacing: '.08em',
        textTransform: 'uppercase',
        color: 'var(--p-text-muted-color)',
        padding: '8px 10px 4px'
      }
    }, r.group), /*#__PURE__*/React.createElement(CommandRow, {
      icon: r.icon,
      label: r.label,
      detail: r.detail,
      active: i === highlight,
      onClick: () => onPick(r),
      onMouseEnter: () => setHighlight(i)
    })))))), /*#__PURE__*/React.createElement("div", {
      style: {
        width: 120
      }
    }));
  }
  function MenuButton({
    label
  }) {
    const [hover, setHover] = React.useState(false);
    return /*#__PURE__*/React.createElement("button", {
      onMouseEnter: () => setHover(true),
      onMouseLeave: () => setHover(false),
      style: {
        border: 'none',
        background: hover ? 'var(--p-content-hover-background)' : 'transparent',
        color: 'var(--p-text-color)',
        fontSize: 13,
        padding: '4px 8px',
        borderRadius: 'var(--radius-sm)',
        cursor: 'pointer',
        fontFamily: 'var(--font-sans)'
      }
    }, label);
  }

  // ---- Activity bar --------------------------------------------------------
  function ActivityBar({
    active,
    onSelect,
    dark,
    onToggleTheme
  }) {
    const items = [{
      view: 'explorer',
      icon: 'pi pi-folder',
      label: 'Explorer'
    }, {
      view: 'search',
      icon: 'pi pi-search',
      label: 'Search'
    }, {
      view: 'queues',
      icon: 'pi pi-list',
      label: 'Task queues'
    }, {
      view: 'settings',
      icon: 'pi pi-cog',
      label: 'Settings'
    }];
    return /*#__PURE__*/React.createElement("div", {
      style: {
        width: 48,
        height: '100%',
        background: 'color-mix(in srgb, var(--p-content-background) 80%, #000)',
        borderRight: '1px solid var(--p-content-border-color)',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-between',
        padding: '6px 0'
      }
    }, /*#__PURE__*/React.createElement("div", null, items.map(it => /*#__PURE__*/React.createElement("button", {
      key: it.view,
      title: it.label,
      onClick: () => onSelect(it.view),
      style: {
        width: 48,
        height: 44,
        border: 'none',
        background: 'transparent',
        color: active === it.view ? 'var(--p-text-color)' : 'var(--p-text-muted-color)',
        cursor: 'pointer',
        fontSize: 20,
        position: 'relative',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
      }
    }, active === it.view && /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        left: 0,
        top: 8,
        bottom: 8,
        width: 2,
        background: 'var(--p-primary-color)'
      }
    }), /*#__PURE__*/React.createElement("i", {
      className: it.icon
    })))), /*#__PURE__*/React.createElement("button", {
      title: "Toggle theme",
      onClick: onToggleTheme,
      style: {
        width: 48,
        height: 44,
        border: 'none',
        background: 'transparent',
        color: 'var(--p-text-muted-color)',
        cursor: 'pointer',
        fontSize: 20,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
      }
    }, /*#__PURE__*/React.createElement("i", {
      className: dark ? 'pi pi-sun' : 'pi pi-moon'
    })));
  }

  // ---- Sidebar (explorer / queues) ----------------------------------------
  function Sidebar({
    view,
    activeKey,
    onOpen
  }) {
    const title = {
      explorer: 'Explorer',
      search: 'Search',
      queues: 'Task queues',
      settings: 'Settings'
    }[view];
    return /*#__PURE__*/React.createElement("div", {
      style: {
        width: 260,
        height: '100%',
        background: 'color-mix(in srgb, var(--p-content-background) 92%, #000)',
        borderRight: '1px solid var(--p-content-border-color)',
        display: 'flex',
        flexDirection: 'column'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        height: 35,
        display: 'flex',
        alignItems: 'center',
        padding: '0 16px',
        fontSize: 11,
        letterSpacing: '.08em',
        textTransform: 'uppercase',
        color: 'var(--p-text-muted-color)'
      }
    }, title), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minHeight: 0,
        overflow: 'auto',
        padding: 4
      }
    }, view === 'explorer' && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(TreeItem, {
      label: "win-mgt",
      icon: "pi pi-folder-open",
      expandable: true,
      expanded: true,
      level: 0
    }), /*#__PURE__*/React.createElement(TreeItem, {
      label: "Welcome",
      icon: "pi pi-home",
      level: 1,
      selected: activeKey === 'welcome',
      onClick: () => onOpen('welcome')
    }), /*#__PURE__*/React.createElement(TreeItem, {
      label: "Customer queue",
      icon: "pi pi-table",
      level: 1,
      selected: activeKey === 'queue',
      onClick: () => onOpen('queue')
    }), /*#__PURE__*/React.createElement(TreeItem, {
      label: "Customer record (JSP)",
      icon: "pi pi-globe",
      level: 1,
      selected: activeKey === 'embed',
      onClick: () => onOpen('embed')
    })), view === 'queues' && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(TreeItem, {
      label: "My queue (12)",
      icon: "pi pi-inbox",
      level: 0,
      onClick: () => onOpen('queue')
    }), /*#__PURE__*/React.createElement(TreeItem, {
      label: "Escalations (3)",
      icon: "pi pi-flag",
      level: 0,
      onClick: () => onOpen('queue')
    })), (view === 'search' || view === 'settings') && /*#__PURE__*/React.createElement("p", {
      style: {
        padding: 16,
        color: 'var(--p-text-muted-color)',
        fontSize: 13
      }
    }, "\u201C", title, "\u201D panel")));
  }
  Object.assign(window, {
    MenuBar,
    ActivityBar,
    Sidebar,
    buildResults
  });

  // Build the command-center result list (customers then commands).
  function buildResults(query, commands) {
    const raw = String(query);
    const q = raw.trim();
    const cmd = filter => commands.filter(c => !filter || c.title.toLowerCase().includes(filter.toLowerCase())).map(c => ({
      key: 'c:' + c.id,
      group: 'Commands',
      icon: c.icon,
      label: c.title,
      detail: c.shortcut,
      run: c.run
    }));
    const cust = t => search(t).map(c => ({
      key: 'u:' + c.id,
      group: 'Customers',
      icon: 'pi pi-user',
      label: `#${c.id} · ${c.name}`,
      detail: `${c.account} · ${c.status}`,
      run: () => commands.openCustomer && commands.openCustomer(c),
      customer: c
    }));
    if (q.startsWith('>')) return cmd(q.slice(1).trim());
    if (!q) return cmd('');
    return [...cust(q), ...cmd(q)];
  }
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/workbench/shell.jsx", error: String((e && e.message) || e) }); }

__ds_ns.CommandRow = __ds_scope.CommandRow;

__ds_ns.StatusBar = __ds_scope.StatusBar;

__ds_ns.Tab = __ds_scope.Tab;

__ds_ns.TreeItem = __ds_scope.TreeItem;

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Tag = __ds_scope.Tag;

})();

# win-mgt Design System

The design system for **win-mgt** — a VSCode-style **enterprise desktop application** for
customer-operations work. Users view and update customer records and work task queues across
a workbench that must scale to **500+ screens** and embed a legacy JSP web app.

This system captures win-mgt's visual language so any new screen, dialog, slide, or prototype
looks like it belongs in the product.

---

## What win-mgt is

A **desktop shell** (Electron) hosting an **Angular** renderer, themed with **PrimeNG**'s
**Aura** preset and arranged as a **VSCode-style workbench**:

- A **top menu bar** — brand mark, native File/View menus, and a centered **command center**
  search box (search customers by number/name, or type `>` for commands).
- A left **activity bar** (Explorer · Search · Task queues · Settings) + collapsible **sidebar**
  (a PrimeNG tree explorer).
- A custom **tab bar** (drag-to-reorder, detach, split) over **multi-split editor groups**.
- A bottom **status bar** painted in the brand emerald.
- An embedded **legacy JSP panel** rendered in a native Electron `WebContentsView` that floats
  above the Angular DOM (the app's defining technical constraint).

It is **dark by default**, information-dense, flat, and keyboard-driven — built for operators
who live in it all day, not for marketing.

### Surfaces represented in this system

1. **Workbench shell** — the VSCode-style chrome (menu/activity/sidebar/tabs/status). See the
   `Shell` UI kit.
2. **Content screens** — Welcome, Customer queue (data table), Customer detail. These render
   inside editor groups. See the `Workbench` UI kit.
3. **Overlays** — OS-modal customer editor, command palette, native context menus.

---

## Sources

This system was reverse-engineered from a single attached codebase. The reader is **not assumed
to have access**; details are recorded here in case they do.

- **Codebase:** `win-mgt/` (mounted, read-only) — an Angular 20 + Electron 42 + PrimeNG 20 POC.
  - `src/app/shell/` — all workbench chrome + content components (the source of truth for visuals).
  - `src/app/shell/components/content/` — Welcome, customer-table, customer-detail screens.
  - `public/legacy/form.html` — the legacy JSP stand-in (copied to `assets/reference/legacy-form.html`).
  - `src/app/app.config.ts` — pins the **PrimeNG Aura** preset, dark via `.app-dark`.
  - `node_modules/@primeuix/themes/umd/aura.js` — exact Aura token values (extracted into `tokens/`).
  - `CLAUDE.md`, `README.md`, `docs/` — architecture, layout, windowing, a11y notes.
- **Theme:** PrimeNG **Aura** preset — primary = **Emerald**, dark neutral ramp = **Zinc**,
  light neutral ramp = **Slate**, status = Green/Sky/Orange/Red. No customizations beyond the
  preset; this system reproduces the preset's resolved tokens.
- **Icon font:** **PrimeIcons 7** (copied into `assets/icons/`).

> No Figma file, brand book, slide deck, or marketing site was provided — this is an internal
> tool, so there is no marketing surface to represent.

---

## Content fundamentals

How win-mgt writes copy. It is a terse, functional, developer-adjacent internal tool — the voice
is closer to VSCode and dev tooling than to consumer SaaS.

- **Tone:** plain, technical, unceremonious. Labels state the thing and stop. No encouragement,
  no exclamation, no personality. The product trusts the operator to know their job.
- **Casing:** **Sentence case everywhere** — buttons, menus, headers, titles. e.g. "Open legacy
  panel", "Customer queue", "Split editor right", "Edit record (modal over JSP)". UPPERCASE is
  reserved for tiny tracked-out section eyebrows (sidebar header "EXPLORER", command-center group
  labels "COMMANDS" / "CUSTOMERS").
- **Person:** **impersonal / imperative.** Commands are verb-first ("Open…", "Toggle…", "Split…",
  "Detach to window"). Almost no "you", never "we". Microcopy describes the system in third person
  ("This dialog is a separate OS window…").
- **Command grammar:** the command center mirrors VSCode — `Category: Action` ("View: Toggle
  Sidebar", "Window: Open OS Modal", "Preferences: Toggle Light/Dark Theme"). Keep this format
  for any new command.
- **Identifiers:** customers are referenced by **number** with a `#` prefix ("Customer #1000",
  "#1003 · Globex"). Numbers are first-class — searchable, shown in tabular figures.
- **Status vocabulary:** lowercase enum words — `active`, `pending`, `closed`; account tiers are
  Title Case nouns — `Standard`, `Premium`, `Enterprise`.
- **Emoji:** **never.** Not in UI, not in copy. Iconography is the PrimeIcons glyph set only.
- **Parentheticals** carry the technical caveat that defines this app: "(modal over JSP)",
  "(JSP)", "(JSP stand-in)". This is house style — the embedding constraint is surfaced in the UI.
- **Vibe:** a precise internal ops tool. If a word isn't load-bearing, cut it.

Examples (verbatim from the product):
- `"VSCode-style shell · Electron + Angular + PrimeNG · embedded legacy panels"`
- `"Open the JSP stand-in in a WebContentsView. Type into it, then switch tabs… its state survives."`
- `"No open editors in this group"` · `"“Customer record (JSP)” is open in a separate window."`

---

## Visual foundations

The look is **VSCode-via-PrimeNG-Aura**: dark, flat, dense, grid-locked, emerald-accented.

**Color & theme.** Dark is the default. The neutral ramp is **Zinc** in dark (editor background
`#18181b`, borders `#3f3f46`, muted text `#a1a1aa`) and **Slate** in light. The one brand hue is
**Emerald** — `#34d399` in dark (`primary.400`), `#10b981` in light (`primary.500`). Accent is used
sparingly and with intent: the **status bar is a full emerald band**, the active-tab + active-rail
indicator is a 2px emerald line, the dirty-dot and focused command-center border are emerald.
Status colors map to Green/Sky/Orange/Red, shown almost exclusively as PrimeNG **tags** (active =
success/green, pending = warn/orange, closed = danger/red). The embedded legacy panel has its own
loud orange-red marker (`#e8462e`) — quarantined to the "Legacy · WebContentsView" tag, never used
for app chrome.

**Typography.** Native OS UI stack, **'Segoe UI' first** — there is no display webfont. The scale is
compact (13px base; chrome text 11–13px; H1s only 24–28px). Weights stay in 400/500/600; 700 is rare
(status-bar brand, JSP counter). Tiny **uppercase tracked labels** (10–11px, `0.08em`) mark sections.
**Tabular numerals** for IDs, balances, counters, clocks.

**Layout.** Fixed-height chrome bands stacked vertically: menu bar 36px · tab bar 36px · status bar
24px · sidebar header 35px · activity rail 48px wide · sidebar 260px. **The shell never scrolls** —
only inner panels do (a hard rule: shell-level scroll misaligns the native embed view). Everything is
flush, full-bleed, edge-to-edge; content sits in the editor area with generous interior padding
(welcome/detail use 28–32px) while chrome stays tight.

**Surfaces & depth.** Mostly **flat**. Chrome layers are distinguished by subtly mixing the content
background toward black (`color-mix(in srgb, var(--p-content-background) 80%, #000)` for the activity
rail/menu bar) rather than by shadow. Borders are 1px hairlines in `--p-content-border-color`.
**Shadow is reserved for true overlays** — the command-center dropdown (`0 12px 40px rgba(0,0,0,.5)`),
popovers/menus (`0 4px 6px…`), modals (`0 20px 25px…`), and the CDK tab drag preview
(`0 4px 14px rgba(0,0,0,.4)`). Cards carry only a faint `0 1px 3px` lift.

**Radius.** From the Aura ramp: 4px (sm — list rows, checkboxes, tab close), **6px (md — buttons,
inputs, command center, content surfaces; the workhorse)**, 12px (xl — cards, modals), 16px (pill —
tags/chips). Nothing is fully rounded except avatars and a few icon buttons.

**Borders.** Hairline 1px, low-contrast (`#3f3f46` dark / `#e2e8f0` light). The accent line under the
active tab and beside the active activity item is 2px emerald. Inputs get a 1px border that turns
emerald on focus. No colored left-border "accent card" tropes.

**Motion.** Minimal and functional. Global transition duration **0.2s**; masks 0.3s. Hovers are
instant color/background shifts, not animated. CDK tab reordering uses a 150ms ease transform. **No
bounces, no decorative loops, no entrance animations** — this is a tool, and the embed view's bounds
tracking actively discourages anything that moves layout unpredictably.

**Interaction states.**
- *Hover:* muted text → full text color; transparent chrome → faint white wash
  (`rgba(255,255,255,0.08)`); list/tree rows → `--p-content-hover-background`.
- *Active/selected:* emerald 2px indicator + brightened background; selected rows use the
  emerald-tinted `--p-highlight-background` (`color-mix(emerald, transparent 84%)`).
- *Focus:* 1px emerald focus ring, 2px offset; inputs swap border to emerald.
- *Press:* color deepens one step (Aura's `active` step) — no scale/shrink transforms.

**Imagery.** Effectively none — this is a data tool. No photography, illustration, gradients, grain,
or textures. The only non-text visuals are PrimeIcons glyphs and a diagonal hatch placeholder shown
behind the embed panel before the native view paints.

---

## Iconography

- **System:** **PrimeIcons 7** — the PrimeNG icon font. This is the *only* icon system in win-mgt.
  Glyphs are referenced by class: `<i class="pi pi-bolt"></i>`, `pi pi-folder`, `pi pi-table`,
  `pi pi-search`, `pi pi-globe`, `pi pi-times`, `pi pi-window-maximize`, `pi pi-external-link`,
  `pi pi-check-circle`, etc. Copied into `assets/icons/` (font + full glyph CSS); the `@font-face`
  ships via `styles.css`.
- **Style:** single-weight line icons, ~13px in chrome (matching body text), 20px in the activity
  rail, 32px for empty-state glyphs. Monochrome — they inherit `currentColor` (muted by default,
  full color on hover/active). Never multi-color, never filled-and-outlined mixed.
- **Brand mark:** win-mgt has **no logo image**. Its identity is the wordmark **"win-mgt"** preceded
  by the `pi pi-bolt` glyph (⚡), in emerald-adjacent text — used in the menu-bar brand and the
  status bar. Recreate the brand mark this way; do not invent a logo.
- **Emoji / unicode:** never used as icons. The only non-PrimeIcons glyph in the product is the `●`
  dirty-dot on modified tabs (emerald) and the `−`/`+` on the legacy counter.
- **Adding icons:** pick from PrimeIcons first (`assets/icons/primeicons.css` lists every class). Do
  not hand-draw SVGs or import a second icon set — it would break the visual unity.

See `guidelines/iconography.card.html` for a live glyph specimen.

---

## Index / manifest

Root files:
- `styles.css` — global entry point (import-only). Link this one file.
- `tokens/palette.css` — raw color ramps (Emerald, Zinc, Slate, Green, Sky, Orange, Red).
- `tokens/colors.css` — semantic `--p-*` tokens (dark default + `.light` scope).
- `tokens/typography.css` — font stacks, type scale, weights, tracking.
- `tokens/spacing.css` — spacing scale, fixed chrome heights, radii, shadows.
- `assets/icons/` — PrimeIcons font + glyph CSS.
- `assets/reference/legacy-form.html` — the embedded JSP stand-in (reference only).
- `SKILL.md` — Agent-Skills-compatible entry point.

Specimen cards (Design System tab): see `guidelines/` (Colors, Type, Spacing, Brand).

Components (`components/`): see each directory's `.prompt.md`. Built so far:
- `core/Button`, `core/IconButton`, `core/Tag`, `core/Badge`, `core/Card`,
  `core/Input`, `core/Select`, `core/Checkbox`, `core/Avatar`
- `chrome/StatusBar`, `chrome/Tab`, `chrome/CommandRow`, `chrome/TreeItem`

UI kits (`ui_kits/`):
- `workbench/` — the full interactive VSCode-style workbench: menu bar + command center,
  activity bar, sidebar tree, multi-tab editor, Welcome / Customer queue / Customer detail
  screens, the embedded legacy JSP panel, and the OS-modal customer editor.

(Manifest is filled in as components/kits are authored — see directories for the live set.)

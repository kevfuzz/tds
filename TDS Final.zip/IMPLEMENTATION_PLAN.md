# RWP2 — Tax Caseworker Workbench
## Implementation plan: Angular + Electron + Tailwind (+ PrimeNG)

**Audience:** an AI coding agent (or junior developer) implementing this from scratch.
**Source of truth for visuals & copy:** the design prototype `Tax Management System.dc.html` in this project. Where this plan and the prototype disagree, **the prototype wins**. Take screenshots of it at each milestone and compare.

The product is **RWP2**, a VSCode-style desktop workbench for Irish Revenue caseworkers: customer records, taxhead ledgers, forms, work queues — dark by default, dense, keyboard-driven, styled on PrimeNG **Aura** (Emerald primary, Zinc dark neutrals, Slate light neutrals). Embedded Revenue-branded forms use a second, scoped visual language (green/gold, Lato) replicating revenue.ie.

---

## 0. Ground rules (read first, apply everywhere)

1. **The shell never scrolls.** Only inner panels scroll (`overflow:auto` on sidebar body, editor content, dropdown lists). The window layout is a fixed column: menu bar 36px · tab bar 36px · content (flex) · status bar 24px. Never let the document body scroll.
2. **Dark is default.** Light theme is opt-in via a preference.
3. **Sentence case everywhere** (buttons, menus, titles). UPPERCASE only for tiny tracked section labels (11px, letter-spacing .08em).
4. **No emoji. Ever.** Icons are PrimeIcons glyphs only (`pi pi-*`).
5. **Tabular numerals** (`font-variant-numeric: tabular-nums`) for every TRN, amount, date, count.
6. **Motion:** 0.2s color/background transitions only. No scale, bounce, or entrance animations.
7. **Borders over shadows.** 1px hairlines (`--p-content-border-color`). Shadow only on true overlays (menus, dialogs, floating windows).
8. **Currency:** `€` + `toLocaleString('en-IE', {minimumFractionDigits:2, maximumFractionDigits:2})`. Dates as `19 Jul 2026`. TRNs like `3287645T` with `#` prefix when referenced ("Customer #3287645T").
9. **"Today" for overdue logic is fixed at `03 Jul 2026`** (prototype parity — keep it in one constant `TODAY`).
10. All persisted preferences use the **exact localStorage keys** in §7.3 so behavior matches the prototype.

---

## 1. Tech stack

| Concern | Choice | Notes |
|---|---|---|
| Framework | **Angular 20**, standalone components, signals | No NgModules. `ChangeDetectionStrategy.OnPush` everywhere. |
| Desktop | **Electron ≥ 30** | Main + preload in TypeScript. `contextIsolation: true`, `nodeIntegration: false`, `sandbox: true`. |
| Styling | **Tailwind CSS v4** | Utility classes mapped to CSS-variable tokens (§5). No SCSS. |
| Component lib | **PrimeNG 20** + `@primeuix/themes` (Aura) + **primeicons** | Use PrimeNG for: Dialog, Select, Checkbox, ToggleSwitch, Tooltip. Everything chrome-like (menu bar, tabs, rail, tree) is hand-built — PrimeNG's defaults don't match VSCode-style chrome. |
| State | Plain injectable stores using Angular **signals** | No NgRx. |
| Build | Angular CLI + `electron-builder` | Dev: `ng serve` + Electron pointing at `http://localhost:4200`. |
| Tests | Vitest (or Karma default) for store logic; the tab engine (§8) MUST have unit tests | |

Do not add other dependencies without need (no lodash, no moment — use native).

---

## 2. Repository layout

```
rwp2/
  package.json
  angular.json
  tsconfig.json
  electron/
    main.ts              # BrowserWindow creation, IPC handlers (main-process side)
    preload.ts           # contextBridge API (minimal, typed by shared/ipc.ts)
    tsconfig.json        # own config, outDir: ../electron-out — NEVER imports from src/
  shared/
    ipc.ts               # the ONLY code both sides import: IPC channel names + payload types (no runtime deps)
  src/
    index.html
    main.ts
    styles.css           # Tailwind entry + token imports (§5)
    theme/
      tokens.css         # --p-* semantic tokens, dark + .light scope
      rev-scope.css      # scoped Revenue form styles (§11.13)
    app/
      app.component.ts   # shell layout (fixed bands)
      app.config.ts      # providePrimeNG(Aura preset), provideZonelessChangeDetection optional
      data/
        seed.ts          # copy of plan-seed-data.ts (see Appendix A)
        types.ts         # interfaces (§6)
        derive.ts        # hash(), eur(), refNo(), balances, txs(), profileData(), regData(), paymentsFor()
        customer.repository.ts  # injectable façade over seed data — the ONLY module screens query for domain data (swappable for a real API later)
      core/
        tab-key.ts           # ParsedKey discriminated union + parseTabKey()/buildKey() — ALL key string logic lives here
        tab-engine.ts        # pure reducer functions (openTab, closeTab, back, forward, split, detach, dock) — no Angular imports
        screen-registry.ts   # Record<kind, () => import('...')> — lazy component loader per tab-key kind
        navigation.service.ts # façade: openTab/openForm/openHead/openWorkItem/back/split/detach — components call THIS, never stores directly
      stores/
        tabs.store.ts        # tabs, active, windows, winZ, standalone, collapsedGroups, lru, drill — thin signal wrapper around tab-engine reducers
        ui.store.ts          # transient chrome state: menuOpen, cmdOpen/cmdQuery, prefsOpen, tabListOpen, workFilterOpen, sidebarHidden, activity, expanded, treeFilter
        screen-state.store.ts # per-tab-key screen state: dirty, submitted, payFilter, ibanShown, searchForm/searchApplied, workFilter — entries deleted when their tab closes
        prefs.store.ts       # theme, density, uiMode, groupTabs, alwaysNewTab, persona (§7.3)
        customer.store.ts    # favs, recents, savedSearches
        intents.store.ts     # intentFavs, intentRecents, intentSel, intentQuery
      shell/
        menu-bar/            # brand, menus, command box, mode segment, bell
        command-center/      # ⌘K overlay
        activity-rail/
        sidebar/
          explorer-panel/    # tree + filter + "I want to…"
          search-panel/      # saved searches
          favs-panel/
          forms-panel/
        tab-strip/
        nav-bar/             # breadcrumbs + back + pop-out buttons
        editor-area/         # resolves active tab key → component via core/screen-registry.ts (lazy import per kind, keyed ngComponentOutlet — NOT a giant ngSwitch)
        status-bar/          # + persona popover
        floating-window/
        prefs-dialog/
        work-filter-dialog/
      screens/
        work-queue/          # 'work'
        work-item/           # 'wi:trn:idx'
        customer-overview/   # 'cust:trn'
        taxheads-all/        # 'heads:trn'
        taxhead-detail/      # 'head:trn:CODE'
        bank-details/        # 'bank:trn'
        payments/            # 'pay:trn'
        profile/             # 'profile:trn:type'
        registration/        # 'reg:trn:type'
        external/            # 'ext:trn:id'
        advanced-search/     # 'search'
        apps/                # 'apps'
        revenue-form/        # 'form:trn:CODE'
```

---

## 3. Bootstrap (Milestone M0)

1. `ng new rwp2 --style=css --ssr=false`, add strict TS.
2. Tailwind v4: `npm i tailwindcss @tailwindcss/postcss postcss`; postcss config with `@tailwindcss/postcss`; `styles.css` starts with `@import "tailwindcss";`.
3. PrimeNG: `npm i primeng @primeuix/themes primeicons`. In `app.config.ts`:

```ts
providePrimeNG({
  theme: {
    preset: definePreset(Aura, { semantic: { primary: {/* emerald ramp */ 50:'{emerald.50}', ..., 500:'{emerald.500}', ..., 950:'{emerald.950}' } } }),
    options: { darkModeSelector: '.app-dark' }
  }
})
```

4. Import `primeicons/primeicons.css` in `styles.css`.
5. Electron: `electron/main.ts` creates a 1440×900 `BrowserWindow` (`minWidth 1100, minHeight 640`, `backgroundColor '#18181b'`, `autoHideMenuBar: true`). Dev loads `process.env.ELECTRON_START_URL ?? file://dist/...`. Preload exposes nothing yet (empty `contextBridge`). Wiring rules:
   - `package.json` → `"main": "electron-out/main.js"`; `electron/tsconfig.json` → `outDir: "../electron-out"`, `module: commonjs`.
   - `electron/**` may import from `shared/**` only — never from `src/**` (and `src/**` never from `electron/**`). Enforce with an ESLint `no-restricted-imports` rule from day one.
   - IPC channels + payload types are declared once in `shared/ipc.ts`; `preload.ts` implements them, the renderer consumes them via a typed `window.rwp2`.
   - `mainWindow.webContents.setWindowOpenHandler(() => ({action: 'deny'}))`; add a CSP meta tag to `index.html`.
6. npm scripts:
   - `dev`: concurrently `ng serve` and `wait-on http://localhost:4200 && electron ./electron-out/main.js`
   - `build`: `ng build && tsc -p electron && electron-builder`
7. **Acceptance:** Electron opens showing the Angular default page in dark background; `npm run build` produces an installer.

---

## 4. App shell skeleton (M1)

`app.component.html` (conceptually):

```html
<div class="app-root" [class.app-dark]="prefs.theme()==='dark'" [class.light]="prefs.theme()==='light'" [class.simple]="prefs.simple()">
  <rwp-menu-bar    *ngIf="showChrome()"/>
  <div class="flex flex-1 min-h-0">
    <rwp-activity-rail *ngIf="showChrome()"/>
    <rwp-sidebar       *ngIf="showSidebar()"/>
    <main class="flex-1 min-w-0 flex flex-col">
      <rwp-tab-strip *ngIf="showChrome() && !prefs.simple()"/>
      <rwp-nav-bar/>
      <rwp-editor-area class="flex-1 min-h-0 overflow-auto"/>
    </main>
  </div>
  <rwp-status-bar *ngIf="showChrome()"/>
  <rwp-floating-window *ngFor="win of ws.windows()" [win]="win"/>
  <!-- overlays: command center, prefs dialog, work filter dialog -->
</div>
```

- Root: `height:100vh; display:flex; flex-direction:column; overflow:hidden; background:var(--p-content-background); color:var(--p-text-color)`.
- `showChrome()` is false in **standalone window mode** (§12.3).
- `.simple` applies `zoom: 1.08` (and `height: calc(100vh / 1.08)`).

**Fixed chrome dimensions (do not deviate):**

| Band | Size | Background |
|---|---|---|
| Menu bar | h 36px | `color-mix(in srgb, var(--p-content-background) 78%, #000)` |
| Tab strip | h 36px | 86% mix |
| Activity rail | w 48px (compact) / 76px (comfortable) | 80% mix |
| Sidebar | w 264px; header row h 35px | 92% mix |
| Nav bar (breadcrumbs) | h ~34px | transparent, hairline bottom |
| Status bar | h 24px | `var(--p-primary-color)`, text `var(--p-primary-contrast-color)` |

**Acceptance:** static shell with all bands, correct sizes, no window scrollbar at any viewport size.

---

## 5. Design tokens & Tailwind mapping (M1)

Create `src/theme/tokens.css`. Port values from the prototype's design-system stylesheets (`_ds/win-mgt-ds-.../tokens/*.css` in the design project). Semantic tokens (dark defaults / `.light` overrides):

| Token | Dark | Light |
|---|---|---|
| `--p-content-background` | `#18181b` (zinc-900) | `#ffffff` |
| `--p-content-border-color` | `#3f3f46` (zinc-700) | `#e2e8f0` (slate-200) |
| `--p-content-hover-background` | `#27272a` | `#f1f5f9` |
| `--p-text-color` | `#fafafa` | `#0f172a` |
| `--p-text-muted-color` | `#a1a1aa` | `#64748b` |
| `--p-primary-color` | `#34d399` (emerald-400) | `#10b981` (emerald-500) |
| `--p-primary-contrast-color` | `#052e1f`-ish (near-black) | `#ffffff` |
| `--p-highlight-background` | `color-mix(in srgb, var(--p-primary-color) 16%, transparent)` | same |
| `--p-form-field-background` | `#09090b`-ish (darker than content) | `#ffffff` |
| `--p-form-field-border-color` | `#3f3f46` | `#cbd5e1` |
| `--p-warn-color` | `#fdba74`/orange-300 range | orange-500 |
| `--p-danger-color` | red-400 | red-500 |
| `--p-info-color` | sky-400 | sky-500 |

Radii: `--radius-sm: 4px; --radius-md: 6px; --radius-lg: 12px; --radius-pill: 16px`. Font: `--font-sans: 'Segoe UI', system-ui, -apple-system, sans-serif`; base size 13px.

Tailwind `@theme` block so utilities exist:

```css
@theme inline {
  --color-surface: var(--p-content-background);
  --color-line: var(--p-content-border-color);
  --color-hoverbg: var(--p-content-hover-background);
  --color-ink: var(--p-text-color);
  --color-muted: var(--p-text-muted-color);
  --color-accent: var(--p-primary-color);
  --color-accent-contrast: var(--p-primary-contrast-color);
  --color-highlight: var(--p-highlight-background);
  --radius-md: 6px; /* etc */
}
```

Use `bg-surface text-ink border-line text-muted bg-highlight text-accent` etc. For the mixed chrome backgrounds use arbitrary values: `bg-[color-mix(in_srgb,var(--p-content-background)_78%,#000)]`.

Status severities map to PrimeNG-style tags: success=green (filed/active), warn=orange (outstanding/pending), danger=red (overdue/closed), info=sky, neutral=zinc.

---

## 6. Data model (`data/types.ts`, M2)

```ts
export type HeadCode = 'IT' | 'VAT' | 'CGT';
export type RetStatus = 'filed' | 'outstanding' | 'overdue';
export type PersonaKey = 'csa' | 'compliance';

export interface Period { label: string; due: string; retStatus: RetStatus; charge: number; paid: number; payDate?: string; method?: string; }
export interface Mandate { ref: string; head: HeadCode; iban: string; signed: string; status: 'active' | 'paused'; }
export interface Bank { acctName: string; iban: string; bic: string; added: string; mandates: Mandate[]; }
export interface Customer {
  trn: string; name: string; short: string; type: 'Individual' | 'Company';
  status: 'active' | 'pending'; addr: string; agent: string; bank: Bank;
  heads: Partial<Record<HeadCode, { since: string; periods: Period[] }>>;
}
export interface WorkItem { pri: 'high'|'med'|'low'; title: string; desc: string; trn: string; head: HeadCode; due: string; status: 'open'|'in progress'; team: string; user: string; type: string; personas: PersonaKey[]; }
export interface AppDef { id: string; name: string; icon: string; desc: string; roles: PersonaKey[]; }
export interface Persona { key: PersonaKey; label: string; short: string; icon: string; desc: string; cats: string[]; chipCodes: string[]; }
export interface IntentStep { view?: 'bank'|'cust'|'pay'|'heads'; form?: string; label: string; sub: string; }
export interface Intent { id: string; icon: string; label: string; kw: string; steps: IntentStep[]; }
export type FormEntry = [code: string, name: string];
export type CatalogCat = [name: string, icon: string, forms: FormEntry[]];
```

`data/seed.ts` — copy **Appendix A verbatim**. `data/derive.ts` — pure functions:

- `hash(s)`: `let h=7; for (const ch of String(s)) h=(h*31+ch.charCodeAt(0))>>>0; return h;` — drives ALL synthetic data (profile/registration numbers) so values are stable.
- `eur(n)`, `refNo(prefix, s) = prefix + (100000 + hash(s)%900000)`, `initials(name)`, `custIcon(c)` (`pi pi-building` for Company else `pi pi-user`), `maskIban(iban) = iban.slice(0,9)+'•••• •••• ••'+iban.slice(-5)`, `retSev(st)` (filed→success, overdue→danger, else warn), `past(d) = new Date(d) < TODAY`.
- `headBalance(head) = Σ(charge−paid)`; `custBalance(c) = Σ heads`.
- `paymentsFor(c)`: flatten every period with `paid>0` into `{date: payDate, head, period: label, method: method ?? 'ROS Debit Instruction', ref: refNo('PAY-', trn+head+label), amount: paid}` sorted newest first.
- `txs(c, head)`: ledger rows per period — debit (charge on due-date-ish), credit (payment), running balance; balance > 0 renders in warn color.
- `profileData(c, type)` and `regData(c, type)`: return `{subtitle, tag, tagSev, sections: [{title, rows: [k, v][]}]}` — port the row content from the prototype (search `profileData(` and `regData(` in the DC file; the registration variant is fully specified in §11.9).
- `findForm(code)` scans CATALOG; `formsTotal()`.

---

## 7. Stores (M2)

**Architecture rules:**
- Components never mutate stores directly — navigation goes through `NavigationService`, domain reads through `CustomerRepository`, everything else through store methods.
- `tab-engine.ts` is a module of **pure reducer functions** (`(state, action) → state`, no Angular, no signals). `TabsStore` is a thin wrapper that holds signals and applies reducers. This is what makes the §8 unit tests trivial (plain Vitest, no TestBed).
- All tab-key string parsing lives in `core/tab-key.ts` (`parseTabKey(key): ParsedKey` discriminated union). No `key.split(':')` anywhere else.
- Screen-scoped state that must survive tab switches (screens are destroyed/recreated when the active tab changes) lives in `ScreenStateStore`, keyed by tab key; `closeTab` deletes that key's entries.

### 7.1 Store contents

```ts
// TabsStore (wraps tab-engine reducers)
tabs: Tab[]                    // {key, hist: string[], fwd: string[]}; initial [{key:'work',hist:[],fwd:[]}]
active: string                 // initial 'work'
windows: FloatWin[]            // {id,view,x,y,w,h,z}
winZ: number; standalone: string|null
collapsedGroups: Record<trn,bool>; lru: Record<trn,number>
drill: Record<string,string|null>   // selected period per 'head:*' key

// UiStore (transient chrome — never persisted)
activity: 'explorer'|'search'|'work'|'favs'|'forms'|'apps'   // initial 'explorer'
sidebarHidden, menuOpen, cmdOpen, cmdQuery, prefsOpen, tabListOpen, workFilterOpen
expanded: Record<string,bool>  // tree groups
treeFilter: string

// ScreenStateStore (keyed by tab key or trn; cleaned up on close)
dirty / submitted: Record<tabKey,bool>      // form lifecycle
payFilter, ibanShown, searchForm, searchApplied, workFilter
```

### 7.2 `PrefsStore` + `CustomerStore` + `IntentsStore`
theme (`dark|light`), uiMode (`power|simple`), density (`compact|comfortable`), groupTabs, alwaysNewTab, persona; favs (trn[]), recents (trn[] max 6), savedSearches (max 12); intentFavs, intentRecents (max 6).

### 7.3 Persistence — exact localStorage keys

| Key | Value |
|---|---|
| `tms-theme` | `'dark'` / `'light'` |
| `tms-uimode` | `'power'` / `'simple'` |
| `tms-density` | `'compact'` / `'comfortable'` |
| `tms-grouptabs` | `'1'` / `'0'` |
| `tms-alwaysnewtab` | `'1'` / `'0'` |
| `tms-persona` | `'csa'` / `'compliance'` |
| `tms-favs`, `tms-recents` | JSON string[] of TRNs (validate against CUSTOMERS on load) |
| `tms-appfavs-v2` | JSON `{csa: string[], compliance: string[]}` (validate ids + role) |
| `tms-saved-searches` | JSON array (max 12) |
| `tms-iw-favs`, `tms-iw-recents` | JSON intent-id arrays (validate) |

Load all on startup inside try/catch; ignore corrupt values.

---

## 8. Tab engine (M3) — the heart of the app. Port EXACTLY.

Implement §8.3–8.5 as pure functions in `core/tab-engine.ts` operating on a plain `TabsState` object; `TabsStore` applies them to signals. Every rule below gets a Vitest case against the pure functions.

### 8.1 Tab key scheme

| Key | Screen | Label (full) | Label (short, used under group chip) |
|---|---|---|---|
| `work` | My work | My work · icon `pi pi-inbox` · **not closeable** | — |
| `apps` | Apps | Apps · `pi pi-th-large` | — |
| `search` | Advanced search | Advanced search · `pi pi-search` | — |
| `cust:<trn>` | Customer overview | *full name* | `Overview` |
| `heads:<trn>` | All taxheads | `Taxheads · <short>` | `Taxheads` |
| `head:<trn>:<CODE>` | Taxhead drill | `<CODE> · <short>` | `<CODE>` |
| `bank:<trn>` | Bank details | `Bank · <short>` | `Bank` |
| `pay:<trn>` | Payments | `Payments · <short>` | `Payments` |
| `profile:<trn>:<type>` | Profile | `<TypeLabel> · <short>` | `<TypeLabel>` |
| `reg:<trn>:<type>` | Registration | `<TypeLabel> · <short>` | `<TypeLabel>` |
| `ext:<trn>:<id>` | External stub | `<Label> · <short>` | `<Label>` |
| `form:<trn>:<CODE>` | Revenue form | `<CODE> · <short>` · `pi pi-file-edit` | `<CODE>` |
| `wi:<trn>:<idx>` | Work item | `Work item · <short>` | `Work item` |

### 8.2 Ctrl/⌘-click capture
Global capture-phase listeners on `mousedown` **and** `click` store `mod = {ctrl: e.ctrlKey || e.metaKey}`. `openTab` reads and clears it. (This lets ANY click-to-navigate in the app honor ctrl-click → new tab without threading the event everywhere.)

### 8.3 `openTab(key, forceNew=false)` decision table (in order)

```
force = forceNew || prefs.alwaysNewTab || mod.ctrl        // then clear mod
side-effects (always): if key's trn is a real customer and not standalone:
    recents = [trn, ...recents−trn].slice(0,6)  → persist
    lru[trn] = ++lruCounter;  collapsedGroups[trn] = false
close menus/command palette/tab list.

1. standalone mode → single surface: if same key, focus; else replace the one tab
   {key, hist: [...hist, oldKey], fwd: []}.
2. a tab with this key already exists → just activate it.
3. simple mode → navigate the CURRENT tab in place (push old key to hist, clear fwd).
4. in-place within same customer: if key has a trn && key isn't a form && !force
   && active tab isn't 'work' && active tab isn't a form && active tab's trn === trn
   → replace active tab's key (push hist, clear fwd).
5. else append new tab {key, hist:[], fwd:[]} and activate.
6. crowding: if tabs.length > 9 → find other-customer groups with ≥2 tabs, not already
   collapsed; collapse the one with the lowest lru value.
```

Forms **always** get their own tab. `openForm(trn, code)` → `openTab('form:trn:code')`. `openWorkItem(idx)` opens `cust:` then `wi:trn:idx` (two tabs). `openHead(trn, code, period)` sets `drill['head:trn:code']=period` then opens the key.

### 8.4 History & split
- `goBack()/goForward()` operate on the active tab's `hist`/`fwd` stacks (per-tab browser-style history).
- `popOutTab()` ("split"): only when active tab has history — revert the tab to its previous key and append the current key as a NEW tab (active). Tooltip: *"Split this screen into its own tab · Ctrl/⌘+click any link does this too"*.
- `closeTab(key)`: in standalone, or simple-mode closing the active screen → behave as Back (or reset to `work`). Otherwise remove the tab; if it was active, activate the tab at `idx−1` (fallback `work`); clear its dirty flag.

### 8.5 Floating windows
- `popOutWindow()` (not for `work`): `view = key` (+ `'|'+drill[key]` for head keys). Push `{id:'w'+Date.now(), x:120+n*32, y:80+n*28, w:980, h:640, z:++winZ}`. Then revert the source tab to its previous history entry, or remove it (fallback: activate neighbor / `work`).
- Window chrome: 32px drag header (emerald dot, title = full tabMeta label + customer, dock button `pi pi-window-minimize` "Dock as tab", close `pi pi-times`); body is an **`<iframe src="?standalone=<view>">`** of the same app. Drag clamps `x≥0, y≥40`; click brings to front (z). `dockWindow` removes it, restores `drill` if the view carried one, and `openTab(baseKey, forceNew=true)`.
- **Standalone mode** (§12.3) renders chrome-less.
- Electron note: keep this in-DOM iframe approach (search `?standalone=` on boot). A native `BrowserWindow` variant is a later enhancement — behavior must stay identical.

### 8.6 Tab strip UI
- 36px row, horizontally scrollable (hidden scrollbar), after the tabs a `+`-style overflow: a **tab-list button** (`pi pi-list` + count) opening a dropdown listing all tabs (icon, full label, dirty dot, close ×).
- **Grouping ON (default):** consecutive-by-customer clusters, each preceded by a **customer chip**: short surname, white text on a deterministic color — `groupColor(trn)`: pick from a fixed 8-color muted palette by `hash(trn) % 8` (port palette from prototype; e.g. the Brennan chip is a dusty purple `#7c6f9c`). Chip click = toggle collapse of that cluster (collapsed chip shows count badge). Tabs inside a visible chip cluster show the **short** label; ungrouped/overflow/windows always show the full label.
- Tab anatomy: icon 11px, label 12.5px, dirty dot `●` emerald when `dirty[key] && !submitted[key]`, close × on hover (not on `work`). Active tab: 2px emerald top border + content background; inactive: muted text.
- Label truncation: max chars 30 (≤7 tabs), 14 (8–10), 10 (>10), ellipsis `…`.
- Drag-to-reorder within the strip (Angular CDK DragDrop, 150ms ease transform).

### 8.7 Nav bar (breadcrumb row under the strip)
- Hidden for `work` in power mode (shown for everything else); in simple mode also shows a **Back** pill (`pi pi-arrow-left` + "Back") when history exists.
- Breadcrumbs: `Customer name › Section › Screen` — each ancestor clickable (navigates in place). Right side: split-to-tab and detach-to-window icon buttons (hidden in simple/standalone).

**M3 acceptance:** unit tests green for: reuse-focus, in-place same-customer nav, ctrl-click new tab, alwaysNewTab, forms new tab, simple in-place, back/forward, split, window pop/dock, LRU auto-collapse at >9 tabs.

---

## 9. Chrome components (M4/M8)

### 9.1 Menu bar (36px)
Left→right: brand `⚡ RWP2` (bolt icon emerald, 13px semibold) · menus `File View Customer Forms Help` (power mode only) · centered command box (absolute center, `min(520px, 36vw)`, 24px tall, reads `⌘K` hint chip; placeholder: *"Search customers by name or number"*, or with a customer open: *"Search customers · #<trn> open · › forms & commands"*) · mode segment (pill, `Standard | Simple`) · bell icon.

Menus are custom dropdowns (250px, radius 6, shadow `0 4px 12px rgba(0,0,0,.4)`, 30px command rows: icon, label, right-aligned detail/shortcut). Hover moves between open menus. Contents:

- **File:** New advanced search tab · Close tab (`⌘W` label only) · sep · Exit.
- **View:** Toggle sidebar `⌘B` · Light/Dark mode · Comfortable density (toggle) · Group tabs by customer (toggle) · sep · Standard layout / Simple layout.
- **Customer:** Search customers `⌘K` · Advanced search · sep · submenu **Recent** (last 6) · submenu **Favourites**.
- **Forms:** the two-pane forms browser (§9.5) when a customer is open; otherwise a 290px disabled panel: *"Open a customer to start forms. Search with ⌘K or the search box above."*
- **Help:** About RWP2 · Keyboard shortcuts.

### 9.2 Command center (⌘K)
Fixed overlay, dim `rgba(0,0,0,.25)`; panel 580px at top 44px; input row + group label + rows (icon/label/detail, 30px) + footer hint. Two modes:
- Default → **CUSTOMERS**: match name/TRN/address, rows show `name` + `#trn · type`; Enter opens first (`cust:` tab).
- Query starts with `›` → **COMMANDS & FORMS**: app commands (Toggle sidebar, Light/dark, Standard/Simple, Preferences, Advanced search) + full forms catalog filtered by code/name; forms open against the **context customer** (`ctxTrn()` = active tab's customer, else most recent customer tab). Footer: `↵ open first result · › forms & commands · esc to close` (simplified copy in simple mode).
Keyboard: `⌘K`/`Ctrl+K` toggle, `Esc` closes, `Enter` runs first row. `⌘B` toggles sidebar. Register handlers on `window` keydown.

### 9.3 Activity rail
Items (top→bottom): Explorer `pi pi-folder` · Search `pi pi-search` (opens the `search` tab AND selects search panel) · Task queues `pi pi-inbox` (badge dot when any high-priority open item for current persona) · Favourites `pi pi-star` · Forms `pi pi-file-edit` · Apps `pi pi-th-large` (opens `apps` tab) · spacer · Settings cog (opens Preferences dialog). Active item: 3px emerald left bar + full-color icon. Compact: 48px wide, 44px items, 20px icons. Comfortable (or simple mode): 76px wide, 58px items, 10.5px labels under icons.

### 9.4 Sidebar (264px)
Header: 35px uppercase tracked title (EXPLORER / SEARCH / TASK QUEUES / FAVOURITES / FORMS). Body scrolls. Panels:

- **Explorer, customer open:** filter box row (§10.2) + tree (§10.1) + **"I want to…"** section pinned at bottom (§10.3). Below tree: RECENT section (last customers, icon + name).
- **Explorer, no customer:** hint text (*"No customer open. Search with ⌘K or pick a recent customer."*) + recents list.
- **Search:** "New search" button → opens `search` tab; SAVED SEARCHES list (label, result count, × to remove) — clicking re-applies criteria and opens the tab.
- **Favourites:** starred customers (star-fill toggle, name, TRN, balance).
- **Forms:** search input + accordion of the 9 catalog categories (persona-relevant ones first with emerald dot, counts); form rows open against context customer; disabled hint when none.

### 9.5 Forms menu (two-pane browser)
560px: left 210px category list (icon, name, relevance dot, count), right form rows (name + code), footer: `<total> forms · opens against <customer / 'no customer open'>`. Category order: persona's `cats` first (in persona order), then the rest.

### 9.6 Status bar (24px emerald)
Left: `⚡ RWP2` bold · caseworker name (prop; default **Sinéad Kelly**, id 4471) · **persona switcher**: `pi pi-<icon> <persona short> ▲` — opens a 320px "Working as" popover UPWARD listing both personas (icon, label, desc, check on active). Switching persona resets work filters and re-orders forms categories, persists `tms-persona`. Right: active customer (`pi pi-user <name>` or "No customer") · queue count (`pi pi-inbox N in queue`) · `pi pi-check-circle Ready`.

### 9.7 Preferences dialog
440px centered modal, header `pi pi-user` + caseworker name + "Preferences", toggle rows (36×20 track, animated knob):
1. **Light mode** — "Switch the workbench between the dark and light theme."
2. **Group tabs by customer** — "Show a collapsible customer chip before each cluster of tabs."
3. **Always open screens in a new tab** — "On: every drill-down opens its own tab. Off: screens navigate in place in the current customer tab (Ctrl/⌘+click still opens a new tab)."
4. **Comfortable density** — "Widen the left rail and show a text label under each icon."

---

## 10. Explorer tree, filter, guided actions (M4)

### 10.1 Tree (customer context `ctx`)
Rows are 26px: chevron (if expandable), icon 13px, label 12.5px; selected row = `--p-highlight-background`; indent 14px/level. Structure & default expansion:

```
<Customer name>  (root:ctx — default EXPANDED)
├─ Registrations (reg:ctx — collapsed): Name & Address · Taxheads · Relationships · Stops · Properties · Sites  → reg:ctx:<type>
├─ Profiles (prof:ctx — collapsed): PAYE · Business · Customs · VAT · Compliance → profile:ctx:<type>
├─ Financials (fin:ctx — EXPANDED)
│  ├─ Taxheads (th:ctx — EXPANDED): "Taxheads — all" → heads:ctx · one per registered head → head:ctx:CODE
│  ├─ Bank details → bank:ctx
│  └─ Payments → pay:ctx
├─ External (ext:ctx — collapsed): Case Management · Debt Management · Registrations · Notes · Events → ext:ctx:<id>
└─ Open forms (f:ctx — EXPANDED): one row per open form:ctx:* tab (code + dirty/submitted suffix)
```

### 10.2 Filter box + expand/collapse-all
Row above the tree: input (placeholder **"Filter screens"**, `pi pi-filter` prefix, × clear when active) + a bordered icon button (`pi pi-angle-double-down` when any group closed → "Expand all"; `pi pi-angle-double-up` when all open → "Collapse all"; operates on the six group keys, forces root open).
When the query is non-empty the tree is REPLACED by a flat result list. Build the destination index: Overview, 6 registrations, 5 profiles, "Taxheads — all", each registered head, Bank, Payments, 5 external, every open form tab. Each row: icon, label, secondary line = location (`Registrations`, `Financials › Taxheads`, `Open forms`, customer name for Overview). Substring match on label+path (case-insensitive). Active screen row highlighted. `Enter` opens the first match; `Esc` clears. Empty state: *No screens match "q".*

### 10.3 "I want to…" guided actions (bottom of explorer)
Section pinned at sidebar bottom (max-height 46%, own scroll, top hairline, darker bg 86% mix). Header: `pi pi-compass` + `I WANT TO…`. Search input (placeholder **"Search actions"**). Content:
- No query: **Pinned** (starred intents) then **Recent** (last used, excluding pinned, max 4); if neither, hint copy: *"Search for a task — e.g. "change bank details". Each action lists its steps and opens the right screens. Pinned and recently used actions appear here."*
- Query: substring match against `label + kw`; rows: icon, label, `N steps`, star toggle (`pi pi-star`/`-fill`, warn color when on). Enter selects first.
- Selecting an intent (records to recents, persists) swaps the section to the **steps view**: back arrow + intent label + star; numbered step rows (18px circle numeral; emerald outline when current/done; check icon when the step's form was submitted; "· draft open"/"· submitted" suffixes) — clicking a step opens its `view` (bank/cust/pay/heads → `<view>:ctx`) or `form:ctx:<code>`. Footer: *"Steps open against <name> (#trn)."* All 11 intents in Appendix A.

---

## 11. Screens (M5–M7)

General: each screen is a standalone component receiving its parsed tab key. Content padding ~`22–26px 32px 40px`, max-widths per screen below. H1 22–24px/600. Screens must work at any width ≥ ~700px.

### 11.1 My work (`work`) — max-w 1120
Header: "My work" + sub *"<Persona label> queue · <N> open items"*; right: **Filter** button (badge with active-filter count). Active filter chips row (removable). Items filtered by `personas.includes(persona)` + workFilter, grouped **High / Medium / Low priority** with tracked group labels. Row: priority dot (danger/warn/muted), title (500), desc muted, right meta: customer chip `#trn short` (click → cust tab), head Tag, due date (`past(due)` → danger text "due 01 Jul 2026"), status Tag (open=warn outline, in progress=info), assignee ("me" → "You"). Row click → `openWorkItem(idx)`.
**Filter dialog** (560px): chip groups Team/Assigned to/Type/Priority with per-option counts, multi-select; footer "N of M items" + Clear all + Show results.

### 11.2 Work item (`wi:trn:idx`) — max-w 880
Title + Tag row (priority, status, head). Meta card grid: Customer (link), TRN, Team, Assigned to, Due, Type. Description paragraph. Related-action chips: Open customer overview · Open <head> taxhead · relevant form (e.g. final demand → CE-DEM1).

### 11.3 Customer overview (`cust:trn`) — max-w 1120
Header: 40px initials avatar (highlight bg, emerald text) · name H1 · status Tag · fav star toggle · TRN mono muted. Meta strip: type icon+label, address, agent line. Balance summary cards per registered head: head icon+code, name, outstanding balance (warn when >0), next due period, return status Tag; click → head drill. Quick-link chips: Taxheads, Bank details, Payments, + persona `chipCodes` forms. (Match prototype layout.)

### 11.4 All taxheads (`heads:trn`) — max-w 1120
Breadcrumb `Customer › Taxheads`. Table/cards per head: code+name, registered since, cycle, latest period + due, return status Tag, balance. Row click → drill.

### 11.5 Taxhead drill (`head:trn:CODE`) — max-w 1120
H1 `<CODE> — <name>`, sub `<Customer> · registered since <date> · <cycle>`. **Period selector** chips (drill state; default latest). Periods table: label, due (danger if past & not filed), return status Tag, charge, paid, balance. **Transactions ledger** for selected period(s): date, description, ref (mono), debit, credit, running balance (warn when >0). Action buttons: `File <ret form>` (Form 11/VAT3/CG1 → form tab), `Record payment` (PAY-1), `Issue demand` (CE-DEM1, compliance persona).

### 11.6 Bank details (`bank:trn`) — max-w 820
Card 1 "Refund account": account name, IBAN masked + eye toggle (`ibanShown[trn]`), BIC, added date. Card 2 "SEPA direct debit mandates": table ref (mono), taxhead, IBAN (masked), signed, status Tag (active=success, paused=warn); empty state *"No mandates on record."* Action chips: Amend bank account (CM-BA1), New mandate (SEPA-DD1), Amend mandate (SEPA-DD2).

### 11.7 Payments (`pay:trn`) — max-w 1020
H1 + head filter chips (`payFilter`). Table: date, description (`<head> <period>`), method, ref (mono), amount right-aligned; footer total. Action chips: Record payment PAY-1 · Refund REF-1 · Reallocate PAY-2.

### 11.8 Profile (`profile:trn:type`) — max-w 900
Header: 36px icon square (highlight bg) + H1 type label + Tag; subtitle; `who` line (`name · TRN`). Two-column grid of bordered section cards (title uppercase 11.5px; k/v rows 150px key column, hairline separators). Content from `profileData` (port from prototype).

### 11.9 Registration (`reg:trn:type`) — max-w 900 — same layout as Profile
Content rules (deterministic; `H(x) = 100000 + hash(trn+x)%900000`):
- **nameaddr** — tag `Verified`/success. Name: registered name, record type, previous names "None on record", language (Gaeilge if address/name is Irish, else English). Address: full addr, Eircode (regex from addr), county, *"Address verified 18 Feb 2025 · An Post GeoDirectory"*.
- **taxheads** — tag `N active`/info; row per registered head *"Registered <since> · active"*; company w/o VAT → "VAT — Not registered"; employer/PAYE row; RCT row (companies, `H('rct')%2===0` → principal contractor).
- **relationships** — tag Agent linked/info or No agent/neutral. Agent card (name, scope "All taxheads", since 12 Mar 2023) or none. Connected records: companies → directors linked (2+H%3), group VAT, associated companies; individuals → spouse/joint assessment (hash-dependent), related businesses, estate links.
- **stops** — rows: correspondence stop (None), refund stop (*Active — offset to arrears (s.1006A)* if any overdue period), DD stop (Active if any mandate paused), marked for review (pending status). Tag `N active`/warn or `No stops`/success.
- **properties** — companies: none/N.A.; individuals: Property ID (4000000000+H), address, valuation band 2–7 (€262+90·band), 2026 LPT status Paid/Deferred.
- **sites** — primary site (trading address, use, `ST-<H>`); companies may have a second site (hash), business-park address. Tag `N site(s)`.
Related chips per type: overview always; taxheads→Financial taxheads; nameaddr→CM-AD1; relationships→AGENT-1.

### 11.10 External (`ext:trn:id`) — max-w 1120
Icon square + H1 label, sub `name · TRN`. Body: bordered placeholder panel *"<Label> opens in an embedded view"* + hatched background. (Electron later: real `WebContentsView`; keep the frame + bounds contract in mind — the panel region must never be overlapped by DOM overlays.)

### 11.11 Advanced search (`search`) — max-w 1160
H1 + sub *"Search the customer register by any combination of fields. Results are kept in the sidebar to reopen."* Criteria card: inputs Name, Address, Tax reference; selects Type (Any/Individual/Company), Taxhead (Any/IT/VAT/CGT), Status (Any/active/pending). Buttons Search / Reset. Results table: TRN (mono), name, type, status Tag, address, taxheads, balance; row click opens customer. Applying a search saves `{id, crit, sig, label, count}` (dedupe by sig, max 12, persist).

### 11.12 Apps (`apps`) — max-w 1120
H1 "Apps" + sub tied to persona; "Manage" button → dialog with checkboxes per role-visible app. **Favourites grid** (persisted per persona, drag-reorder) of app cards: icon, name, desc, "Open" → 900ms launch overlay (*"Opening <name>…"* spinner) then external stub. Below: "All apps" list for the persona.

### 11.13 Revenue form (`form:trn:CODE`) — the two-brand screen
Centered 860px card **inside `.rev-scope`** (port `rev-scope.css` from the design project — Lato, Revenue palette: `--green-700:#0b5c3f`, `--green-900`, `--gold-500:#ffbf47`, greys). Structure:
- Header band: green-700 bg, 4px gold bottom border; left: "Revenue" 900-weight + italic *"Cáin agus Custaim na hÉireann · Irish Tax and Customs"*; right: mono code chip (green-900 bg, gold text).
- Body: category eyebrow (uppercase, brand green), H1 form name (26px), context strip (grey-050 box, 3 columns: Customer / Tax reference (mono) / Caseworker).
- Optional info Notice "Deadline" (for return forms, e.g. *"The deadline to pay and file … is 13 November 2026."*).
- Fields (representative): Select (period/reason), Amount input with € prefix (*"Enter 0.00 if no liability arises."*), Details input, declaration Checkbox (*"I declare that the information provided is true and complete"*). Buttons: **Submit** (green primary), Save draft (secondary), Cancel (ghost) — GDS-style yellow focus rings.
- Any field change → `dirty[key]=true` (tab dot). Submit → `submitted[key]=true`, replace fields with success Notice *"Submitted — reference <refNo('RV-', key)>"* + Close form button. Cancel/close → `closeTab`.
- Caption under card (workbench-muted): *"Embedded Revenue form — rendered in a WebContentsView (JSP parity). Prototype shows representative fields only."*
Implement Revenue-styled controls as small local components inside `revenue-form/` styled by `rev-scope.css` — do NOT let these styles leak (everything scoped under `.rev-scope`).

---

## 12. Modes & special states

### 12.1 Simple mode (`uiMode==='simple'`)
Segment in menu bar switches instantly. Differences (ALL must hold):
- Menus hidden; tab strip hidden (`showTabs=false`); ⌘K chip hidden; `zoom:1.08` on root.
- One screen at a time: every navigation is in-place with history; nav bar always shows Back pill; closing the active screen = Back (or to `work`).
- Activity rail forced comfortable (labels); Work rail item opens the work tab directly; pop-out buttons hidden.
- Command palette copy simplified (placeholder *"Type a customer name or number"*, footer *"Press Enter to open the first result"*); forms browsing goes through `›` palette.
- Sidebar no-customer hint: *"No customer open. Use the search box at the top, or pick a recent customer below."*

### 12.2 Density
`comfortable` (or simple) → rail 76px + labels; also used for the cog. Nothing else changes.

### 12.3 Standalone (floating-window content)
On boot read `?standalone=<view>` (view may be `key` or `key|drillPeriod`). If present: `standalone=key`, tabs=[that key], chrome hidden (no menu/rail/sidebar/status/tab strip), nav bar shown with breadcrumbs; all navigation in-place. Used by floating-window iframes.

---

## 13. Electron specifics (M9)

1. **Window:** single main BrowserWindow; custom in-DOM menu bar (native menu hidden). Keep native window frame (traffic lights / min-max-close) — the in-app menu bar sits below it. `backgroundColor` matches theme to avoid white flash.
2. **Preload API** (contextBridge, namespace `rwp2`): `platform`, `openExternal(url)` (Apps launch stub), later `openStandaloneWindow(view)` if floating windows are promoted to native windows. Keep IPC surface minimal; everything else stays in the renderer.
3. **Floating windows stay in-DOM (iframes)** for v1 — identical to prototype. Document the upgrade path: `rwp2.openStandaloneWindow(view)` → new BrowserWindow loading `index.html?standalone=view`, dock via IPC message.
4. **External/legacy panels:** v1 renders the DOM placeholder (§11.10). v2 (optional): `WebContentsView` attached to the main window; renderer sends the panel's `getBoundingClientRect()` on layout changes; main process syncs bounds. Constraint that motivates rule #1 (shell never scrolls).
5. Packaging: electron-builder targets win (nsis) + mac (dmg); appId `ie.revenue.rwp2` (placeholder).

---

## 14. Milestones & order of work

| # | Deliverable | Key acceptance checks |
|---|---|---|
| M0 | Scaffold boots in Electron | dark window, installer builds |
| M1 | Shell chrome static + tokens + theme/density toggles wired to store | band sizes exact; light/dark flip; no shell scroll |
| M2 | Seed data + derive fns + stores + persistence | unit tests: hash/eur/balances/paymentsFor; prefs survive reload |
| M3 | Tab engine + strip + nav bar + history + split + grouping + overflow | §8.3–8.7 tests green; ctrl-click works from any row |
| M4 | Sidebar panels: explorer tree, filter box + expand/collapse, recents, favs, saved searches, forms panel | tree defaults per §10.1; filter Enter opens top match |
| M5 | Screens: work, work item, customer, taxheads all/drill, bank, payments | numbers = Σ(charge−paid); overdue coloring; drill period chips |
| M6 | Screens: profiles, registrations, external, advanced search, apps | deterministic hash data stable across reloads |
| M7 | Forms: catalog, Forms menu, forms panel, ⌘K `›`, Revenue form screen, dirty/submitted lifecycle | dirty dot on tab; submit → success + tree/steps reflect it |
| M8 | Command center, menus, preferences, persona switcher, status bar | ⌘K/⌘B/Esc; persona reorders categories + filters queue |
| M9 | Guided actions, floating windows + standalone mode | steps navigate; window drag/dock; iframe standalone chrome-less |
| M10 | Simple mode, density polish, light-theme QA, packaging, parity pass vs prototype screenshots | §12.1 checklist all true |

---

## 15. Guardrails for the implementing agent

- Do not introduce Angular Router routes per screen — tabs are state, not URLs (only `?standalone=` is read from the URL).
- Screens never import `seed.ts` or mutate stores directly: domain reads via `CustomerRepository`, navigation via `NavigationService`, per-screen state via `ScreenStateStore`. New screens = one registry entry + one lazy component.
- All tab-key composition/parsing goes through `core/tab-key.ts`.
- `electron/**` ↔ `src/**` imports are forbidden in both directions; only `shared/ipc.ts` is common.
- Do not use PrimeNG Menubar/TabView/Tree for the chrome — hand-build to spec; PrimeNG only for Dialog/Select/Checkbox/ToggleSwitch/Tooltip.
- Never block streaming of the fixed bands behind data: mock data is synchronous.
- Keep every list row `display:flex` with `gap`, hit targets ≥ 26px in chrome, ≥ 34px in content.
- All colors via tokens; no hex literals outside `tokens.css`, `rev-scope.css`, and `groupColor` palette.
- Re-check §0 before every PR.

---

## Appendix A — Seed data

**The complete seed data is extracted verbatim into `plan-seed-data.ts` (sits next to this plan).** Copy that file to `src/app/data/seed.ts` unchanged — it contains `TODAY`, `HEADS`, `EXT`, `CUSTOMERS` (6 customers with full bank/mandate/taxhead/period data), `PERSONAS`, `WORK` (12 items), `APPS` (12), `DEFAULT_APP_FAVS`, `PROFILE_TYPES` (5), `REG_TYPES` (6), `CATALOG` (9 categories of forms), and `INTENTS` (11 guided actions). Names, dates, amounts and keywords are load-bearing test fixtures for every screen — do not edit them.

Key shapes for quick reference:

```ts
export const TODAY = new Date('03 Jul 2026');
export const HEADS = {
  IT:  { code:'IT',  name:'Income Tax',        form:'Form 11', icon:'pi pi-user',       cycle:'Annual self-assessment · Form 11' },
  VAT: { code:'VAT', name:'Value-Added Tax',   form:'VAT3',    icon:'pi pi-percentage', cycle:'Bi-monthly · VAT3' },
  CGT: { code:'CGT', name:'Capital Gains Tax', form:'CG1',     icon:'pi pi-chart-line', cycle:'Annual · CG1' },
};
export const EXT = [
  { id:'casemgmt', label:'Case Management', icon:'pi pi-folder-open' },
  { id:'debtmgmt', label:'Debt Management', icon:'pi pi-briefcase' },
  { id:'registrations', label:'Registrations', icon:'pi pi-id-card' },
  { id:'notes', label:'Notes', icon:'pi pi-pencil' },
  { id:'events', label:'Events', icon:'pi pi-calendar' },
];
export const REG_TYPES = [
  ['nameaddr','Name & Address','pi pi-id-card'], ['taxheads','Taxheads','pi pi-sitemap'],
  ['relationships','Relationships','pi pi-share-alt'], ['stops','Stops','pi pi-ban'],
  ['properties','Properties','pi pi-home'], ['sites','Sites','pi pi-map-marker'],
];
export const PROFILE_TYPES = [
  ['paye','PAYE','pi pi-id-card'], ['business','Business','pi pi-building'],
  ['customs','Customs','pi pi-truck'], ['vat','VAT','pi pi-percentage'], ['compliance','Compliance','pi pi-shield'],
];
```

*(The full `CUSTOMERS`, `WORK`, `APPS`, `CATALOG`, `INTENTS`, `PERSONAS` blocks follow the same copy-verbatim rule.)*

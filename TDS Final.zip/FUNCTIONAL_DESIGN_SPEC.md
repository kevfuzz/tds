# RWP2 — Tax Caseworker Workbench
## Functional Design Specification (FDS)

| | |
|---|---|
| Product | RWP2 — caseworker workbench for Irish Revenue customer operations |
| Version | 1.0 (matches design prototype `Tax Management System.dc.html`) |
| Related documents | `IMPLEMENTATION_PLAN.md` (technical design) · `plan-seed-data.ts` (reference data) |
| Requirement IDs | `FR-*` functional requirement · `BR-*` business rule · `NFR-*` non-functional |
| Convention | "shall" = mandatory. The design prototype is the binding reference for visuals, copy and micro-behavior. |

---

## 1. Purpose & scope

RWP2 is a desktop application used by Revenue caseworkers to view and maintain customer tax records, work task queues, and complete operational forms. It presents a VSCode-style workbench: one window, multiple tabs and panels, a customer-centric navigation tree, and embedded Revenue-branded forms.

**In scope:** application shell, customer search and records (registrations, profiles, financials), work queues and work items, forms catalog and lifecycle, guided multistep actions, app launcher, tab/window management, personalisation, offline mock data.
**Out of scope (v1):** real backend integration, authentication, printing, MyEnquiries messaging, document imaging, real external-system embeds, accessibility certification, localisation (Irish-language UI).

## 2. Users & roles

| Role | Persona key | Description | Default forms emphasis |
|---|---|---|---|
| Customer Support Agent | `csa` | Front-line service: registrations, record maintenance, payments, correspondence | Registrations, Customer maintenance, Payments & refunds, Correspondence |
| Compliance Officer | `compliance` | Interventions, audits, enforcement | Compliance & interventions, Collections & enforcement, IT/VAT/CGT |

- FR-001 The signed-in caseworker (name + ID) shall be displayed in the status bar and stamped on submitted forms. Default session: Sinéad Kelly, ID 4471.
- FR-002 The user shall be able to switch active persona from the status bar ("Working as" selector). Switching persists (BR-20), re-orders the forms catalog (FR-131) and resets work-queue filters.
- FR-003 Both personas see the same screens; persona affects only work-queue content (FR-090), forms ordering/relevance dots, suggested action chips, and default app favourites.

## 3. Information model (summary)

Customer (TRN, name, type Individual/Company, status active/pending, address, agent, bank + SEPA mandates) → registered taxheads (IT, VAT, CGT) → periods (label, due date, return status filed/outstanding/overdue, charge, paid, payment date/method). Work items reference a customer + taxhead. Forms belong to a catalog of 9 categories (88 forms). Guided actions ("intents") are ordered lists of steps, each step = a screen or a form. Reference data: `plan-seed-data.ts`.

**Business rules (data):**
- BR-01 Outstanding balance of a taxhead = Σ(charge − paid) over its periods; customer balance = Σ over taxheads. Positive balances display in the warning color.
- BR-02 A date is overdue when strictly before the fixed system date **03 Jul 2026**.
- BR-03 Return status severity: filed → success, outstanding → warning, overdue → danger.
- BR-04 IBANs display masked (`IE29 AIBK 9…•••• ••…78` pattern) until explicitly revealed per customer (FR-113).
- BR-05 All synthetic record values (profile numbers, property bands, site numbers) derive deterministically from `hash(trn + salt)` so they are stable across sessions.
- BR-06 Money formats as `€1,234.56` (en-IE); dates as `19 Jul 2026`; TRNs referenced as `#3287645T`.

## 4. Application shell

### 4.1 Layout
- FR-010 The shell shall be a fixed vertical stack — menu bar (36px), tab strip (36px), content row (activity rail 48/76px · sidebar 264px · editor), status bar (24px). The shell itself never scrolls; only sidebar body, editor content and overlay lists scroll.
- FR-011 The shell shall support dark (default) and light themes applied to every band simultaneously (FR-150).
- FR-012 The editor area shall always display the screen for the active tab key (§6 screen inventory).

### 4.2 Menu bar
- FR-020 Left: product brand ("⚡ RWP2"). Menus **File, View, Customer, Forms, Help** shall be available in Standard layout only (hidden in Simple, FR-161).
- FR-021 Menu contents: File (New advanced search, Close tab, Exit); View (Toggle sidebar ⌘B, Light/Dark, Comfortable density, Group tabs, Standard/Simple layout); Customer (Search ⌘K, Advanced search, Recent ▸, Favourites ▸); Forms (two-pane browser, FR-130); Help (About, Keyboard shortcuts).
- FR-022 Center: a command box opening the command center (FR-030); its placeholder reflects context ("Search customers · #TRN open · › forms & commands" when a customer is open).
- FR-023 Right: Standard/Simple segmented switch (FR-160) and a notifications bell (visual only, v1).
- FR-024 Menus open on click, move between menus on hover, and close on outside click or Esc.

### 4.3 Command center (⌘K)
- FR-030 ⌘K / Ctrl+K or clicking the command box shall open a centered overlay with a text input, grouped results, and a footer hint. Esc closes; Enter activates the first result.
- FR-031 Default mode searches **customers** by name, TRN or address substring; a result row opens `Customer overview` for that customer.
- FR-032 Prefixing the query with `›` switches to **commands & forms**: application commands (toggle sidebar, theme, layout, preferences, advanced search) plus the full forms catalog filtered by code/name. Selecting a form opens it against the context customer (BR-10).
- BR-10 Context customer = customer of the active tab; if none, the most recently used customer among open tabs; forms are unavailable with no context (FR-132).

### 4.4 Activity rail & sidebar
- FR-040 Rail items top→bottom: Explorer, Search, Task queues, Favourites, Forms, Apps, (spacer), Settings. Active item shows a 3px accent bar. Task queues shows a badge dot when the persona has open high-priority items.
- FR-041 Explorer/Favourites/Forms/Search select the corresponding sidebar panel (opening the sidebar if hidden). Apps opens the Apps tab; Search additionally opens the Advanced search tab; in Simple layout, Task queues opens My work directly.
- FR-042 ⌘B / Ctrl+B and View menu shall toggle sidebar visibility.
- FR-043 Sidebar panels: Explorer (§5), Search (saved searches list + "New search"), Favourites (starred customers), Forms (searchable catalog accordion; persona-relevant categories first).
- FR-044 Saved searches list shows label + result count; clicking re-applies the criteria in the Advanced search tab; × removes it.

### 4.5 Status bar
- FR-050 Emerald band showing: brand, caseworker name, persona selector (FR-002), and on the right the active customer (or "No customer"), open queue count, and "Ready".

## 5. Customer explorer (sidebar)

### 5.1 Navigation tree
- FR-060 With a customer in context, the explorer shall show a tree rooted at the customer: **Registrations** (Name & Address, Taxheads, Relationships, Stops, Properties, Sites) · **Profiles** (PAYE, Business, Customs, VAT, Compliance) · **Financials** (Taxheads — all + one node per registered head, Bank details, Payments) · **External** (Case Management, Debt Management, Registrations, Notes, Events) · **Open forms** (one node per open form tab of this customer, with draft/submitted suffix).
- FR-061 Default expansion: root, Financials, Taxheads and Open forms expanded; Registrations, Profiles, External collapsed. Expansion state persists per customer for the session.
- FR-062 Selecting a leaf opens/activates the corresponding screen; the row for the active screen is highlighted.
- FR-063 Below the tree: a RECENT section listing the last 6 customers (FR-101); with no context customer, the panel shows a hint plus that recents list.

### 5.2 Screen filter
- FR-070 A "Filter screens" box shall sit above the tree. Typing replaces the tree with a flat list of matching destinations (all leaves of FR-060 incl. open forms), each showing its location path (e.g. "Financials › Taxheads").
- FR-071 Matching is case-insensitive substring on label + path. Enter opens the top match; Esc or × clears; empty state: *No screens match "q"*.
- FR-072 An adjacent button shall expand all / collapse all tree groups; its icon and tooltip reflect current state.

### 5.3 "I want to…" guided actions
- FR-080 A section pinned to the sidebar bottom (own scroll, ≤46% height) shall let the user search **tasks** (11 intents; keyword-matched via label + hidden keywords).
- FR-081 With no query it lists **Pinned** intents then up to 4 **Recent** (used on any customer), else a hint.
- FR-082 Selecting an intent shows its numbered step list; each step opens a screen or form for the context customer. Step state reflects reality: current screen highlighted, submitted forms checked, open drafts flagged. Footer: "Steps open against <name> (#TRN)."
- FR-083 Intents can be pinned/unpinned via a star (list and steps views). Pins and recents persist (BR-20).
- BR-11 Recents exclude pinned intents; recents cap at 6.

## 6. Screens

| # | Screen | Tab key | Core content |
|---|---|---|---|
| S1 | My work | `work` | Persona queue grouped High/Medium/Low; filter dialog (Team/Assigned/Type/Priority with counts); rows: priority dot, title, desc, customer chip, head tag, due (danger when overdue), status, assignee |
| S2 | Work item | `wi:trn:i` | Title, tags, meta grid (customer, TRN, team, assignee, due, type), description, related-action chips |
| S3 | Customer overview | `cust:trn` | Avatar, name, status, fav star, TRN; address/agent; per-head balance cards; quick links + persona form chips |
| S4 | All taxheads | `heads:trn` | Per-head: since, cycle, latest period, status, balance |
| S5 | Taxhead detail | `head:trn:CODE` | Period chips (drill), periods table, transaction ledger with running balance, actions (file return, record payment, issue demand*) |
| S6 | Bank details | `bank:trn` | Refund account (masked IBAN + reveal), mandates table, maintenance form chips |
| S7 | Payments | `pay:trn` | Ledger across heads with head filter chips, totals, actions PAY-1/REF-1/PAY-2 |
| S8 | Profile ×5 | `profile:trn:t` | Two-column key-value section cards + related chips |
| S9 | Registration ×6 | `reg:trn:t` | Same layout; content per BR-05 rules (verified address, taxhead registrations, agent links, stops, LPT property, sites) |
| S10 | External ×5 | `ext:trn:id` | Embedded-system placeholder panel |
| S11 | Advanced search | `search` | Criteria (name/address/ref/type/taxhead/status), results table, auto-saved searches (max 12, deduped) |
| S12 | Apps | `apps` | Persona favourites grid (drag-reorder, persisted), all apps, manage dialog, launch overlay |
| S13 | Revenue form | `form:trn:CODE` | Revenue-branded embedded form (§7) |

\* Issue demand only relevant for compliance workflows; chip set follows the prototype.

- FR-090 My work shall show only items whose `personas` include the active persona; the filter dialog composes AND across groups, OR within a group; active filters render as removable chips and a count badge on the Filter button.
- FR-091 Opening a work item shall open the customer overview tab AND the work item tab (in that order).
- FR-092 Advanced search: Search applies criteria (AND across fields, substring for text) and saves `{criteria, label, count}` to saved searches (BR-12: max 12, newest first, deduplicated by criteria signature). Reset clears the form.
- FR-093 Taxhead detail shall remember the selected period per tab (drill state), including when detached to a window.

## 7. Forms

- FR-130 Forms are discoverable via: Forms menu (two-pane browser with persona-relevant categories flagged), sidebar Forms panel, command center `›`, in-screen action chips, and guided actions.
- FR-131 Category ordering: the active persona's categories first (its order), then remaining catalog order. Relevant categories carry an accent dot.
- FR-132 With no context customer, form entry points shall be disabled with the hint "Open a customer to start forms…".
- FR-140 A form opens as its own tab (always — BR-16) rendered as an embedded Revenue-branded panel: Revenue masthead, form code chip, category eyebrow, form name, context strip (customer / TRN / caseworker), representative fields (period/reason select, € amount, details, declaration checkbox), actions Submit / Save draft / Cancel.
- FR-141 Lifecycle: any field edit marks the tab **dirty** (● dot on tab, "draft open" suffixes in tree/steps). Submit marks **submitted** (success notice with reference `RV-…`, fields replaced, Close form button; check marks in tree/steps). Cancel/close closes the tab. Dirty state clears when its tab closes.
- FR-142 Return-type forms (e.g. VAT3, Form 11) show a deadline notice.

## 8. Tabs, windows & navigation

- BR-15 Tab identity = its key; opening an already-open key focuses the existing tab.
- BR-16 Navigation within the same customer replaces the current tab's screen (in-place, with per-tab back/forward history) — EXCEPT: forms always open a new tab; Ctrl/⌘+click always opens a new tab; the "Always open in a new tab" preference forces new tabs; drill-downs from `My work` or a different customer's tab open new tabs.
- FR-100 Per-tab history: Back/Forward operate on the active tab's own stacks; in-place navigation pushes history and clears forward.
- FR-101 Opening any customer screen updates the recents list (max 6, most recent first, persisted).
- FR-102 **Split:** when the active tab has history, the user can split the current screen into its own tab (breadcrumb-bar button); the original tab reverts to its previous screen.
- FR-103 **Detach:** any screen except My work can detach to a floating window (980×640, cascading position, draggable header, bring-to-front on click). Its source tab reverts to history or closes. Window actions: **Dock as tab** (returns it, preserving drill state) and Close.
- FR-104 Floating windows render the same screen chrome-less (no menus/rail/sidebar/status), with breadcrumb navigation in place.
- FR-105 **Grouping** (default on): consecutive same-customer tabs cluster behind a colored customer chip (deterministic color per TRN). Chip click collapses/expands the cluster (collapsed shows count). Tabs under a visible chip show short labels ("Bank"); ungrouped contexts show full labels ("Bank · Brennan").
- FR-106 When more than 9 tabs are open, the least-recently-used other customer's cluster (≥2 tabs) auto-collapses.
- FR-107 A tab-list button at the strip end lists all tabs (icon, full label, dirty dot, close) for overflow access; tabs can be drag-reordered in the strip.
- FR-108 My work is permanent (not closeable). Closing the active tab activates its left neighbour (fallback My work).
- FR-110 Breadcrumbs under the strip show `Customer › Section › Screen` with clickable ancestors; hidden for My work in Standard layout.
- FR-113 IBAN reveal toggles per customer and does not persist across sessions.

## 9. Personalisation & modes

- FR-150 **Theme:** dark default; Preferences toggle switches to light; whole workbench re-themes instantly.
- FR-151 **Density:** compact (48px rail) or comfortable (76px rail + labels).
- FR-152 **Group tabs by customer** toggle (FR-105 on/off — full labels when off).
- FR-153 **Always open screens in a new tab** toggle (BR-16).
- FR-154 Preferences dialog (from Settings cog) hosts FR-150–153 with the exact copy from the prototype.
- FR-160 **Standard layout:** full workbench — tabs, menus, shortcuts.
- FR-161 **Simple layout:** menus and tab strip hidden; one screen at a time (all navigation in-place with Back pill); ~8% zoom; rail forced comfortable; Task queues opens directly; simplified command-center copy; closing the active screen = Back. Switchable instantly from the menu-bar segment.
- BR-20 Persisted preferences: theme, layout mode, density, tab grouping, always-new-tab, persona, customer favourites, recents, saved searches, app favourites (per persona), intent pins/recents. All survive restart; corrupt values are ignored.

## 10. Keyboard shortcuts

| Keys | Action |
|---|---|
| ⌘K / Ctrl+K | Command center |
| ⌘B / Ctrl+B | Toggle sidebar |
| Esc | Close topmost overlay (command center, menu, dialog) |
| Enter | In command center / filter / actions search: open first result |
| Ctrl/⌘ + click | Open target in new tab (any navigable element) |

## 11. Empty, error & edge states

- FR-170 No customer context: explorer hint + recents; forms entry points disabled (FR-132); guided actions hidden.
- FR-171 Empty lists show quiet single-line hints (no mandates, no saved searches, no matching screens/actions/work items) — copy per prototype.
- FR-172 Unknown tab key (e.g. stale persisted state) shall fall back to My work without error.
- FR-173 localStorage unavailable: app runs with defaults; preferences simply don't persist (no user-facing error).

## 12. Non-functional requirements

- NFR-01 Interaction feedback < 100ms; theme/layout switches apply in a single frame; no layout shift in fixed chrome.
- NFR-02 All chrome interactions keyboard-reachable where specified; focus states visible (accent ring); WCAG AA contrast in both themes.
- NFR-03 Renderer runs fully offline; no network calls in v1.
- NFR-04 Electron: context isolation on, no node integration in renderer, single window ≥1100×640.
- NFR-05 State-engine logic (tabs/windows/history) covered by unit tests (see implementation plan §8/§14).

## 13. Traceability

Milestones in `IMPLEMENTATION_PLAN.md` §14 map to: M3 → §8 (FR-100–113, BR-15/16), M4 → §5 (FR-060–083), M5 → S1–S7, M6 → S8–S12, M7 → §7 (FR-130–142), M8 → §4 (FR-020–050), M9 → FR-103/104 + §5.3, M10 → §9. Acceptance testing = walking this FDS top to bottom against the running app, with the design prototype open for visual comparison.

// RWP2 seed data — extracted VERBATIM from the design prototype (Tax Management System.dc.html).
// Do not edit values: names, dates, amounts and keywords are load-bearing fixtures for every screen.
// See IMPLEMENTATION_PLAN.md sections 6 and Appendix A.

export const TODAY = new Date('03 Jul 2026');

export const HEADS = {
  IT:  { code: 'IT',  name: 'Income Tax',        form: 'Form 11', icon: 'pi pi-user',       cycle: 'Annual self-assessment · Form 11' },
  VAT: { code: 'VAT', name: 'Value-Added Tax',   form: 'VAT3',    icon: 'pi pi-percentage', cycle: 'Bi-monthly · VAT3' },
  CGT: { code: 'CGT', name: 'Capital Gains Tax', form: 'CG1',     icon: 'pi pi-chart-line', cycle: 'Annual · CG1' },
};

export const EXT = [
  { id: 'casemgmt', label: 'Case Management', icon: 'pi pi-folder-open' },
  { id: 'debtmgmt', label: 'Debt Management', icon: 'pi pi-briefcase' },
  { id: 'registrations', label: 'Registrations', icon: 'pi pi-id-card' },
  { id: 'notes', label: 'Notes', icon: 'pi pi-pencil' },
  { id: 'events', label: 'Events', icon: 'pi pi-calendar' },
];

export const CUSTOMERS = [
  { trn: '3287645T', name: 'Aoife Murphy', short: 'Murphy', type: 'Individual', status: 'active',
    addr: '14 Charleville Road, Rathmines, Dublin 6, D06 X2P4', agent: 'Agent: Ó Sé & Co Accountants (TAIN 71204B)',
    bank: { acctName: 'Aoife Murphy', iban: 'IE29 AIBK 9311 5212 3456 78', bic: 'AIBKIE2D', added: '12 Mar 2024',
      mandates: [{ ref: 'RVDD-0044127', head: 'IT', iban: 'IE29 AIBK 9311 52•• •••• 78', signed: '12 Mar 2024', status: 'active' }] },
    heads: {
      IT: { since: '06 Apr 2014', periods: [
        { label: '2025', due: '12 Nov 2026', retStatus: 'outstanding', charge: 24680, paid: 18000, payDate: '19 May 2026', method: 'ROS Debit Instruction' },
        { label: '2024', due: '13 Nov 2025', retStatus: 'filed', charge: 22140, paid: 22140, payDate: '11 Nov 2025' },
        { label: '2023', due: '15 Nov 2024', retStatus: 'filed', charge: 19855, paid: 19855, payDate: '14 Nov 2024' } ] },
      CGT: { since: '02 Jan 2021', periods: [
        { label: '2025 — initial period', due: '31 Oct 2026', retStatus: 'outstanding', charge: 8140, paid: 8140, payDate: '12 Dec 2025', method: 'SEPA direct debit' },
        { label: '2024', due: '31 Oct 2025', retStatus: 'filed', charge: 0, paid: 0 } ] },
    } },
  { trn: '9587421C', name: 'Brennan Joinery Ltd', short: 'Brennan', type: 'Company', status: 'active',
    addr: 'Unit 7, Ballymount Industrial Estate, Dublin 12, D12 XW61', agent: 'Agent: none on record',
    bank: { acctName: 'Brennan Joinery Ltd', iban: 'IE64 BOFI 9000 1712 3456 89', bic: 'BOFIIE2D', added: '03 Sep 2019',
      mandates: [{ ref: 'RVDD-0038812', head: 'VAT', iban: 'IE64 BOFI 9000 17•• •••• 89', signed: '03 Sep 2019', status: 'active' }] },
    heads: {
      VAT: { since: '01 Jul 2015', periods: [
        { label: 'May/Jun 2026', due: '19 Jul 2026', retStatus: 'outstanding', charge: 14230, paid: 0 },
        { label: 'Mar/Apr 2026', due: '19 May 2026', retStatus: 'overdue', charge: 12880, paid: 4000, payDate: '02 Jun 2026', method: 'ROS Debit Instruction' },
        { label: 'Jan/Feb 2026', due: '19 Mar 2026', retStatus: 'filed', charge: 11020, paid: 11020, payDate: '18 Mar 2026' },
        { label: 'Nov/Dec 2025', due: '19 Jan 2026', retStatus: 'filed', charge: 13475, paid: 13475, payDate: '17 Jan 2026' } ] },
      IT: { since: '01 Jul 2015', periods: [
        { label: '2025', due: '12 Nov 2026', retStatus: 'outstanding', charge: 31200, paid: 15000, payDate: '02 Apr 2026', method: 'ROS Debit Instruction' },
        { label: '2024', due: '13 Nov 2025', retStatus: 'filed', charge: 28950, paid: 28950, payDate: '10 Nov 2025' } ] },
    } },
  { trn: '5573082W', name: 'Cormac Ó Dálaigh', short: 'Ó Dálaigh', type: 'Individual', status: 'active',
    addr: 'An Spidéal, Co. na Gaillimhe, H91 X2R7', agent: 'Agent: MacSuibhne Accounting (TAIN 66410F)',
    bank: { acctName: 'Cormac Ó Dálaigh', iban: 'IE11 ULSB 9862 4412 7789 02', bic: 'ULSBIE2D', added: '21 Jan 2023', mandates: [] },
    heads: {
      IT: { since: '10 Oct 2018', periods: [
        { label: '2025', due: '12 Nov 2026', retStatus: 'outstanding', charge: 9480, paid: 6200, payDate: '30 Apr 2026', method: 'SEPA direct debit' },
        { label: '2024', due: '13 Nov 2025', retStatus: 'filed', charge: 8730, paid: 8730, payDate: '12 Nov 2025' } ] },
      VAT: { since: '01 Jan 2020', periods: [
        { label: 'May/Jun 2026', due: '19 Jul 2026', retStatus: 'outstanding', charge: 2140, paid: 0 },
        { label: 'Mar/Apr 2026', due: '19 May 2026', retStatus: 'filed', charge: 1980, paid: 1980, payDate: '15 May 2026' },
        { label: 'Jan/Feb 2026', due: '19 Mar 2026', retStatus: 'filed', charge: 2210, paid: 2210, payDate: '19 Mar 2026' } ] },
    } },
  { trn: '8841190H', name: 'Delaney Farm Supplies Ltd', short: 'Delaney', type: 'Company', status: 'pending',
    addr: 'Clonminch Road, Tullamore, Co. Offaly, R35 FK20', agent: 'Agent: Midland Tax Partners (TAIN 58821K)',
    bank: { acctName: 'Delaney Farm Supplies Ltd', iban: 'IE83 AIBK 9320 8823 4410 55', bic: 'AIBKIE2D', added: '15 Feb 2022',
      mandates: [{ ref: 'RVDD-0051230', head: 'VAT', iban: 'IE83 AIBK 9320 88•• •••• 55', signed: '15 Feb 2022', status: 'paused' }] },
    heads: {
      VAT: { since: '01 Mar 2017', periods: [
        { label: 'May/Jun 2026', due: '19 Jul 2026', retStatus: 'outstanding', charge: 7640, paid: 0 },
        { label: 'Mar/Apr 2026', due: '19 May 2026', retStatus: 'filed', charge: 8115, paid: 8115, payDate: '18 May 2026' } ] },
      IT: { since: '01 Mar 2017', periods: [
        { label: '2025', due: '12 Nov 2026', retStatus: 'outstanding', charge: 18400, paid: 9000, payDate: '20 Mar 2026', method: 'ROS Debit Instruction' },
        { label: '2024', due: '13 Nov 2025', retStatus: 'filed', charge: 17210, paid: 17210, payDate: '13 Nov 2025' } ] },
    } },
  { trn: '2209584K', name: 'Emer FitzGerald', short: 'FitzGerald', type: 'Individual', status: 'active',
    addr: '3 Wellington Road, Ballintemple, Cork, T12 Y8V4', agent: 'Agent: none on record',
    bank: { acctName: 'Emer FitzGerald', iban: 'IE47 PTSB 9906 2331 0087 61', bic: 'IPBSIE2D', added: '08 Jun 2025', mandates: [] },
    heads: {
      IT: { since: '01 Jan 2012', periods: [
        { label: '2025', due: '12 Nov 2026', retStatus: 'outstanding', charge: 15320, paid: 15320, payDate: '10 Jun 2026', method: 'ROS Debit Instruction' },
        { label: '2024', due: '13 Nov 2025', retStatus: 'filed', charge: 14100, paid: 14100, payDate: '11 Nov 2025' } ] },
      CGT: { since: '14 Aug 2023', periods: [
        { label: '2026 — initial period', due: '15 Dec 2026', retStatus: 'outstanding', charge: 21450, paid: 0 },
        { label: '2025 — later period', due: '31 Jan 2026', retStatus: 'filed', charge: 5210, paid: 5210, payDate: '28 Jan 2026' } ] },
    } },
  { trn: '7734516V', name: 'Glenveagh Consulting Ltd', short: 'Glenveagh', type: 'Company', status: 'active',
    addr: 'Pearse Road, Letterkenny, Co. Donegal, F92 T2P8', agent: 'Agent: Northwest Advisory (TAIN 70992A)',
    bank: { acctName: 'Glenveagh Consulting Ltd', iban: 'IE38 BOFI 9014 5560 2291 34', bic: 'BOFIIE2D', added: '27 Nov 2020',
      mandates: [{ ref: 'RVDD-0047765', head: 'VAT', iban: 'IE38 BOFI 9014 55•• •••• 34', signed: '27 Nov 2020', status: 'active' },
                 { ref: 'RVDD-0047766', head: 'IT', iban: 'IE38 BOFI 9014 55•• •••• 34', signed: '27 Nov 2020', status: 'active' }] },
    heads: {
      VAT: { since: '01 Feb 2016', periods: [
        { label: 'May/Jun 2026', due: '19 Jul 2026', retStatus: 'outstanding', charge: 9850, paid: 0 },
        { label: 'Mar/Apr 2026', due: '19 May 2026', retStatus: 'filed', charge: 10310, paid: 10310, payDate: '19 May 2026' } ] },
      IT: { since: '01 Feb 2016', periods: [
        { label: '2025', due: '12 Nov 2026', retStatus: 'outstanding', charge: 26700, paid: 13000, payDate: '05 May 2026', method: 'ROS Debit Instruction' } ] },
      CGT: { since: '19 Sep 2024', periods: [
        { label: '2025 — initial period', due: '31 Oct 2026', retStatus: 'outstanding', charge: 3480, paid: 3480, payDate: '11 Dec 2025' } ] },
    } },
];

export const PERSONAS = {
  csa: { key: 'csa', label: 'Customer Support Agent', short: 'Support Agent', icon: 'pi pi-comments',
    desc: 'Front-line service — registrations, record maintenance, payments, correspondence.',
    cats: ['Registrations', 'Customer maintenance', 'Payments & refunds', 'Correspondence & certificates', 'VAT', 'Income Tax'],
    chipCodes: ['CM-AD1', 'CC-SOA1', 'PAY-1', 'CC-TCC1'] },
  compliance: { key: 'compliance', label: 'Compliance Officer', short: 'Compliance', icon: 'pi pi-shield',
    desc: 'Interventions, audits and enforcement across the case base.',
    cats: ['Compliance & interventions', 'Collections & enforcement', 'Income Tax', 'VAT', 'Capital Gains Tax', 'Payments & refunds'],
    chipCodes: ['CI-AQ1', 'CI-AN1', 'CE-DEM1', 'CI-SET1'] },
};

export const WORK = [
  { pri: 'high', title: 'VAT3 overdue — issue final demand', desc: 'Mar/Apr 2026 not filed · 45 days past due', trn: '9587421C', head: 'VAT', due: '01 Jul 2026', status: 'open', team: 'Collections', user: 'me', type: 'Enforcement', personas: ['compliance'] },
  { pri: 'high', title: 'Aspect query response received', desc: 'Rental income 2024 — reply within 14 days', trn: '2209584K', head: 'IT', due: '08 Jul 2026', status: 'open', team: 'Compliance', user: 'me', type: 'Intervention', personas: ['compliance'] },
  { pri: 'high', title: 'Verify VAT58 repayment claim €3,412', desc: 'Supporting documentation received via MyEnquiries', trn: '5573082W', head: 'VAT', due: '07 Jul 2026', status: 'in progress', team: 'Compliance', user: 'Daniel Okoye', type: 'Repayment', personas: ['compliance'] },
  { pri: 'med', title: 'Review Form 11 2025 preliminary tax', desc: 'Preliminary payment €18,000 against est. €24,680', trn: '3287645T', head: 'IT', due: '17 Jul 2026', status: 'open', team: 'Assessing', user: 'me', type: 'Return review', personas: ['compliance'] },
  { pri: 'med', title: 'eCG50 clearance application', desc: 'Disposal of residential property — Cork', trn: '2209584K', head: 'CGT', due: '21 Jul 2026', status: 'open', team: 'Assessing', user: 'Niamh Doyle', type: 'Clearance', personas: ['compliance'] },
  { pri: 'med', title: 'PPA restructure review', desc: 'Phased Payment Arrangement — missed May instalment', trn: '8841190H', head: 'IT', due: '24 Jul 2026', status: 'in progress', team: 'Collections', user: 'me', type: 'Payment arrangement', personas: ['compliance', 'csa'] },
  { pri: 'low', title: 'Confirm bank mandate amendment', desc: 'SEPA DD mandate paused — customer instruction awaited', trn: '8841190H', head: 'VAT', due: '28 Jul 2026', status: 'open', team: 'Collections', user: 'Daniel Okoye', type: 'Maintenance', personas: ['csa'] },
  { pri: 'low', title: 'Agent link request (TAIN 66410F)', desc: 'MacSuibhne Accounting — extend link to VAT', trn: '5573082W', head: 'VAT', due: '31 Jul 2026', status: 'open', team: 'Registrations', user: 'Niamh Doyle', type: 'Registration', personas: ['csa'] },
  { pri: 'med', title: 'Change of address — verify and update', desc: 'New correspondence address — customer phoned', trn: '5573082W', head: 'IT', due: '09 Jul 2026', status: 'open', team: 'Customer Service', user: 'me', type: 'Maintenance', personas: ['csa'] },
  { pri: 'low', title: 'Statement of account requested', desc: 'Full SOA for 2024–2026 — issue via MyEnquiries', trn: '2209584K', head: 'IT', due: '06 Jul 2026', status: 'open', team: 'Customer Service', user: 'me', type: 'Correspondence', personas: ['csa'] },
  { pri: 'med', title: 'ROS access number reissue', desc: 'Identity verified — reissue digital certificate', trn: '7734516V', head: 'VAT', due: '05 Jul 2026', status: 'in progress', team: 'Customer Service', user: 'me', type: 'Maintenance', personas: ['csa'] },
  { pri: 'low', title: 'Duplicate Tax Clearance Certificate', desc: 'Customer needs TCC for grant application', trn: '3287645T', head: 'IT', due: '10 Jul 2026', status: 'open', team: 'Customer Service', user: 'Daniel Okoye', type: 'Correspondence', personas: ['csa'] },
];

export const APPS = [
  { id: 'ros', name: 'ROS', icon: 'pi pi-globe', desc: 'Revenue Online Service — filings, payments and registrations.', roles: ['csa', 'compliance'] },
  { id: 'itp', name: 'ITP', icon: 'pi pi-database', desc: 'Integrated Taxation Processing — core customer ledger.', roles: ['csa', 'compliance'] },
  { id: 'myenq', name: 'MyEnquiries', icon: 'pi pi-envelope', desc: 'Secure correspondence with customers and agents.', roles: ['csa', 'compliance'] },
  { id: 'crm', name: 'Contact History', icon: 'pi pi-phone', desc: 'Calls, visits and contact notes across all channels.', roles: ['csa'] },
  { id: 'lpt', name: 'LPT Online', icon: 'pi pi-home', desc: 'Local Property Tax valuations and payments.', roles: ['csa'] },
  { id: 'aep', name: 'Customs AEP', icon: 'pi pi-truck', desc: 'Automated Entry Processing — customs declarations.', roles: ['csa'] },
  { id: 'dms', name: 'Debt Management', icon: 'pi pi-briefcase', desc: 'Collections caseworking, PPAs and enforcement referrals.', roles: ['compliance'] },
  { id: 'ecg50', name: 'eCG50', icon: 'pi pi-verified', desc: 'CGT clearance applications and certificates.', roles: ['compliance'] },
  { id: 'caseselect', name: 'Case Select', icon: 'pi pi-filter', desc: 'Risk rules and compliance case selection.', roles: ['compliance'] },
  { id: 'infomart', name: 'InfoMart', icon: 'pi pi-chart-bar', desc: 'Reporting and analytics — yield, compliance and queue metrics.', roles: ['compliance'] },
  { id: 'docview', name: 'DocView', icon: 'pi pi-images', desc: 'Scanned post and document imaging archive.', roles: ['csa', 'compliance'] },
  { id: 'revnet', name: 'RevNet', icon: 'pi pi-book', desc: 'Staff intranet — tax manuals and operational guidance.', roles: ['csa', 'compliance'] },
];

export const DEFAULT_APP_FAVS = {
  csa: ['ros', 'itp', 'myenq', 'crm', 'lpt', 'docview'],
  compliance: ['itp', 'dms', 'ecg50', 'caseselect', 'infomart', 'myenq'],
};

export const PROFILE_TYPES = [
  ['paye', 'PAYE', 'pi pi-id-card'],
  ['business', 'Business', 'pi pi-building'],
  ['customs', 'Customs', 'pi pi-truck'],
  ['vat', 'VAT', 'pi pi-percentage'],
  ['compliance', 'Compliance', 'pi pi-shield'],
];

export const REG_TYPES = [
  ['nameaddr', 'Name & Address', 'pi pi-id-card'],
  ['taxheads', 'Taxheads', 'pi pi-sitemap'],
  ['relationships', 'Relationships', 'pi pi-share-alt'],
  ['stops', 'Stops', 'pi pi-ban'],
  ['properties', 'Properties', 'pi pi-home'],
  ['sites', 'Sites', 'pi pi-map-marker'],
];

export const CATALOG = [
  ['Registrations', 'pi pi-id-card', [
    ['TR1', 'Tax registration — individual / sole trader'], ['TR1 (FT)', 'Tax registration — non-resident individual'],
    ['TR2', 'Tax registration — company'], ['TR2 (FT)', 'Tax registration — non-resident company'],
    ['eREG-V1', 'Register for VAT'], ['eREG-V2', 'Cancel VAT registration'],
    ['eREG-I1', 'Register for Income Tax'], ['eREG-I2', 'Cease Income Tax registration'],
    ['eREG-C1', 'Register for CGT'], ['TR1 (A)', 'Amend registration details'],
    ['AGENT-1', 'Agent link set-up (TAIN)'], ['AGENT-2', 'Agent link removal'] ]],
  ['Income Tax', 'pi pi-user', [
    ['Form 11', 'Income Tax return — self-assessed'], ['Form 11S', 'Income Tax return — short version'],
    ['Form 12', 'Income Tax return — PAYE'], ['Form 12S', 'Income Tax return — PAYE short'],
    ['IT-AA1', 'Amend assessment'], ['IT-PT1', 'Preliminary tax computation'],
    ['IT-PT2', 'Reduce preliminary tax direct debit'], ['IT-EXT1', 'Filing extension request'],
    ['IT-NIL', 'Nil return declaration'], ['SW1', 'Surcharge waiver application'],
    ['LOSS-1', 'Loss relief claim (s.381)'], ['MED-1', 'Health expenses claim'],
    ['RENT-1', 'Rental income schedule'], ['EII-1', 'EII relief claim'] ]],
  ['VAT', 'pi pi-percentage', [
    ['VAT3', 'VAT return — periodic'], ['RTD', 'Return of Trading Details — annual'],
    ['VAT58', 'Repayment claim — unregistered persons'], ['VAT60A', 'Flat-rate farmer refund'],
    ['VAT13B', 'Zero-rating authorisation (56B)'], ['VAT-ADJ1', 'Adjust filing frequency'],
    ['VAT-G1', 'Group registration application'], ['VAT-G2', 'Group registration amendment'],
    ['OSS-1', 'OSS scheme registration'], ['OSS-Q1', 'OSS quarterly return'],
    ['VAT-UNP1', 'Unpaid consideration adjustment'], ['VAT-BD1', 'Bad debt relief claim'] ]],
  ['Capital Gains Tax', 'pi pi-chart-line', [
    ['CG1', 'Capital Gains Tax return'], ['CGT-A', 'CGT payslip A — initial period'],
    ['CGT-B', 'CGT payslip B — later period'], ['CG50A', 'Clearance application — asset disposal'],
    ['CG50B', 'Clearance certificate — deduction'], ['CGT-RR1', 'Retirement relief claim'],
    ['CGT-PPR1', 'Principal private residence relief'], ['CGT-L1', 'Loss carry-forward election'] ]],
  ['Payments & refunds', 'pi pi-money-bill', [
    ['PAY-1', 'Record payment received'], ['PAY-2', 'Reallocate payment between taxheads'],
    ['PAY-3', 'Offset instruction'], ['REF-1', 'Refund authorisation'],
    ['REF-2', 'Repayment supplement calculation'], ['SEPA-DD1', 'Direct debit mandate — set up'],
    ['SEPA-DD2', 'Direct debit mandate — amend'], ['SEPA-DD3', 'Direct debit mandate — cancel'],
    ['PPA-1', 'Phased Payment Arrangement — application'], ['PPA-2', 'Phased Payment Arrangement — restructure'],
    ['POA-1', 'Payment on account instruction'], ['UMP-1', 'Unmatched payment investigation'] ]],
  ['Compliance & interventions', 'pi pi-shield', [
    ['CI-AQ1', 'Aspect query — issue'], ['CI-AQ2', 'Aspect query — record response'],
    ['CI-PI1', 'Profile interview notification'], ['CI-AN1', 'Audit notification (Code of Practice)'],
    ['CI-EA1', 'e-Audit records request'], ['CI-QD1', 'Qualifying disclosure — record'],
    ['CI-PEN1', 'Penalty determination'], ['CI-PEN2', 'Penalty mitigation review'],
    ['CI-SV1', 'Site visit report'], ['CI-REF1', 'Referral to Investigations & Prosecutions'],
    ['CI-SET1', 'Settlement computation'], ['CI-PUB1', 'Publication determination (s.1086)'] ]],
  ['Collections & enforcement', 'pi pi-briefcase', [
    ['CE-DEM1', 'Final demand — issue'], ['CE-DEM2', '7-day warning letter'],
    ['CE-SHF1', 'Sheriff referral'], ['CE-ATT1', 'Attachment order (s.1002)'],
    ['CE-JUD1', 'Judgment process initiation'], ['CE-INT1', 'Interest charge computation'],
    ['CE-WO1', 'Write-out recommendation'], ['CE-INS1', 'Insolvency claim lodgement'],
    ['CE-TC1', 'Tax clearance review'], ['CE-TC2', 'Tax clearance rescission'] ]],
  ['Customer maintenance', 'pi pi-user-edit', [
    ['CM-AD1', 'Change of address'], ['CM-BA1', 'Bank account amendment'],
    ['CM-NM1', 'Name change'], ['CM-CS1', 'Civil status update'],
    ['CM-DOB1', 'Date of birth correction'], ['CM-CT1', 'Cessation of trade'],
    ['CM-DEC1', 'Deceased case — estate link'], ['CM-MRG1', 'Merge duplicate records'],
    ['CM-SUS1', 'Suspend correspondence'], ['CM-PPS1', 'PPS number verification'] ]],
  ['Correspondence & certificates', 'pi pi-envelope', [
    ['CC-TCC1', 'Tax Clearance Certificate — issue'], ['CC-LOR1', 'Letter of residence'],
    ['CC-SOA1', 'Statement of account'], ['CC-NOA1', 'Duplicate notice of assessment'],
    ['CC-P21', 'Statement of liability'], ['CC-LTR1', 'Standard letter — compose'],
    ['CC-SEC1', 'Secure MyEnquiries reply'], ['CC-CERT1', 'Certificate of tax paid'] ]],
];

export const INTENTS = [
  { id: 'bank', icon: 'pi pi-credit-card', label: 'Change bank account details', kw: 'bank iban bic sepa direct debit mandate amend account',
    steps: [
      { view: 'bank', label: 'Review current bank details and mandates', sub: 'Bank details' },
      { form: 'CM-BA1', label: 'Record the bank account amendment', sub: 'Form CM-BA1' },
      { form: 'SEPA-DD2', label: 'Re-point the direct debit mandate', sub: 'Form SEPA-DD2' } ] },
  { id: 'address', icon: 'pi pi-map-marker', label: 'Record a change of address', kw: 'address correspondence eircode move update',
    steps: [
      { view: 'cust', label: 'Verify identity against the record', sub: 'Customer overview' },
      { form: 'CM-AD1', label: 'Record the change of address', sub: 'Form CM-AD1' },
      { form: 'CC-LTR1', label: 'Issue written confirmation', sub: 'Form CC-LTR1' } ] },
  { id: 'ppa', icon: 'pi pi-calendar', label: 'Set up a phased payment arrangement', kw: 'ppa instalment installment debt arrangement warehouse pay over time',
    steps: [
      { view: 'pay', label: 'Review payment history and balance', sub: 'Payments' },
      { form: 'PPA-1', label: 'Complete the PPA application', sub: 'Form PPA-1' },
      { form: 'SEPA-DD1', label: 'Set up the direct debit mandate', sub: 'Form SEPA-DD1' } ] },
  { id: 'refund', icon: 'pi pi-money-bill', label: 'Process a refund', kw: 'refund repayment overpayment supplement',
    steps: [
      { view: 'pay', label: 'Confirm the overpayment on the ledger', sub: 'Payments' },
      { form: 'REF-1', label: 'Authorise the refund', sub: 'Form REF-1' },
      { form: 'REF-2', label: 'Calculate any repayment supplement', sub: 'Form REF-2' } ] },
  { id: 'tcc', icon: 'pi pi-verified', label: 'Issue a Tax Clearance Certificate', kw: 'tcc clearance certificate grant licence compliance',
    steps: [
      { view: 'heads', label: 'Check returns and balances across taxheads', sub: 'Taxheads' },
      { form: 'CE-TC1', label: 'Complete the tax clearance review', sub: 'Form CE-TC1' },
      { form: 'CC-TCC1', label: 'Issue the certificate', sub: 'Form CC-TCC1' } ] },
  { id: 'vatreg', icon: 'pi pi-percentage', label: 'Register the customer for VAT', kw: 'vat register registration threshold eregistration',
    steps: [
      { view: 'heads', label: 'Confirm existing registrations', sub: 'Taxheads' },
      { form: 'eREG-V1', label: 'Complete the VAT registration', sub: 'Form eREG-V1' },
      { form: 'VAT-ADJ1', label: 'Set the filing frequency', sub: 'Form VAT-ADJ1' } ] },
  { id: 'demand', icon: 'pi pi-exclamation-triangle', label: 'Issue a final demand', kw: 'demand enforcement arrears overdue collection interest warning',
    steps: [
      { view: 'heads', label: 'Confirm the outstanding balance', sub: 'Taxheads' },
      { form: 'CE-INT1', label: 'Compute interest on late payment', sub: 'Form CE-INT1' },
      { form: 'CE-DEM1', label: 'Issue the final demand', sub: 'Form CE-DEM1' } ] },
  { id: 'realloc', icon: 'pi pi-sync', label: 'Reallocate a payment', kw: 'reallocate unmatched misallocated offset transfer payment wrong taxhead',
    steps: [
      { view: 'pay', label: 'Locate the payment on the ledger', sub: 'Payments' },
      { form: 'UMP-1', label: 'Investigate the unmatched payment', sub: 'Form UMP-1' },
      { form: 'PAY-2', label: 'Reallocate between taxheads', sub: 'Form PAY-2' } ] },
  { id: 'agent', icon: 'pi pi-link', label: 'Link a new agent (TAIN)', kw: 'agent tain accountant advisor authorisation link',
    steps: [
      { view: 'cust', label: 'Confirm customer consent on record', sub: 'Customer overview' },
      { form: 'AGENT-1', label: 'Set up the agent link', sub: 'Form AGENT-1' } ] },
  { id: 'cease', icon: 'pi pi-power-off', label: 'Cease a trade or business', kw: 'cease cessation close business stop trading deregister cancel',
    steps: [
      { view: 'heads', label: 'Review open periods before cessation', sub: 'Taxheads' },
      { form: 'CM-CT1', label: 'Record the cessation of trade', sub: 'Form CM-CT1' },
      { form: 'eREG-V2', label: 'Cancel the VAT registration', sub: 'Form eREG-V2' },
      { form: 'eREG-I2', label: 'Cease the Income Tax registration', sub: 'Form eREG-I2' } ] },
  { id: 'deceased', icon: 'pi pi-user-minus', label: 'Record a deceased customer', kw: 'deceased death estate bereavement executor solicitor',
    steps: [
      { form: 'CM-DEC1', label: 'Link the estate to the record', sub: 'Form CM-DEC1' },
      { form: 'CM-SUS1', label: 'Suspend correspondence', sub: 'Form CM-SUS1' },
      { form: 'CC-SOA1', label: 'Issue a statement of account to the estate', sub: 'Form CC-SOA1' } ] },
];
